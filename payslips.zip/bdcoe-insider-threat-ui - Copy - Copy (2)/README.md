#Insider Threat Dashboard

##Enviroments
1. [development](http://dataexcellence.dev.att.com/insider-threat-server/#/)
1. [qa/test](http://dataexcellence.test.att.com/insider-threat-server/#/)
1. [stage](http://dataexcellence.stage.att.com/insider-threat-server/#/)
1. [development](http://dataexcellence.web.att.com/insider-threat-server/#/)

##Installation and build processes
[Design standards readme.md](https://codecloud.web.att.com/plugins/servlet/readmeparser/display/ST_HUB/bdcoe-insider-threat-server/atRef/refs/heads/develop/renderFile/Readme.md)

##Build Process for UI:

npm install    
bower install
grunt server
grunt build