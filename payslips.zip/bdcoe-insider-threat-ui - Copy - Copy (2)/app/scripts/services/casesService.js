'use strict';
angular.module('insiderApp')
.service('casesService', [ 
	function() {
		
        var mycaesSelected = false;
        
        this.isMyCasesSelected = function(){
            
            return mycaesSelected;
        }
        
        this.setMyCasesSelected = function(value){
            
            mycaesSelected = value;
        }

	}
]);