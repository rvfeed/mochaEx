'use strict';

angular.module('insiderApp')
.factory('topSummaryFactory', ['$state','$http', '$q', '$location', 'getServiceURI','$rootScope',function ($state,$http, $q, $location, getServiceURI,$rootScope) {
        
    var topSummaryFactory = {};  
    
    topSummaryFactory.getTopSummaryData= function(){
    
        var defer = $q.defer();
        var serviceURI = getServiceURI.build('insiderThreat', 'getTopSummaryProbData')+'/'+$rootScope.loggedAttId;
     
        if($location.host() === 'localhost'){
            if($location.port() === 9000){
              serviceURI = 'json/topSummary.json';
            }
        }
              
        $http({
            method: 'GET',
            url: serviceURI
        }).then(function(data){
            if(data.data.serviceResult && !data.data.serviceResult.success){
                $state.go('error',{'id':data.data.serviceResult.errorMessage});
            }
            defer.resolve(data.data);
        }, 
        function(failedReason){
            if(failedReason.status===-1)      
                defer.reject({'message':'not logged in'});
            else
                defer.reject(failedReason);
        });
                
        return defer.promise;
        
    };

    topSummaryFactory.getAllPriorityData= function(){
    
        var defer = $q.defer();
        var serviceURI = getServiceURI.build('insiderThreat', 'getPriorityData')+'/'+$rootScope.loggedAttId;
     
        if($location.host() === 'localhost'){
            if($location.port() === 9000){
              serviceURI = 'json/allPriorityData.json';
            }
        }
        
        $http({
            method: 'GET',
            url: serviceURI
           }).then(function(data){
                  if(data.data.serviceResult && !data.data.serviceResult.success){
                    
                   $state.go('error',{'id':data.data.serviceResult.errorMessage});
                }
                defer.resolve(data.data);
             }, 
        function(failedReason){
            if(failedReason.status===-1)      
                defer.reject({'message':'not logged in'});
            else
                defer.reject(failedReason);
            });
               
            return defer.promise;
        
    };

    topSummaryFactory.getMyCasesData= function(data,page,size){

        var defer = $q.defer();

        var serviceURI =getServiceURI.build('insiderThreat', 'allCasesData')+'?sort=lastUpdateDateTime&sortDirection=DESC';
         
        if($location.host() === 'localhost'){
            if($location.port() === 9000){
                serviceURI = 'json/allCases.json';
            }
        }
                
        $http({
            method: 'POST',  
            url: serviceURI,
            params:{
              'page' :  page,
              'size' : size
            },
            headers: {
                        'Content-Type': 'application/json'
                    },
            
            data: data
          }).then(function(data){
              defer.resolve(data.data);
         },

        function(failedReason){
            defer.reject(failedReason);
        });
               
        return defer.promise;
    };


    topSummaryFactory.checkUserInUPM= function(){
    
        var defer = $q.defer();
        var serviceURI = getServiceURI.build('insiderThreat', 'checkUserInUPM')+'/'+$rootScope.loggedAttId;
     
        if($location.host() === 'localhost'){
            if($location.port() === 9000){
              serviceURI = 'json/checkThreshold.json';
            }
        }
        
        $http({
            method: 'GET',
            url: serviceURI
           }).then(function(data){
                defer.resolve(data.data);
             }, 
        function(failedReason){
            defer.reject(failedReason);
        });
           
        return defer.promise;
        
    };
    topSummaryFactory.checkBasicUserInUPM= function(){
    
        var defer = $q.defer();
        var serviceURI = getServiceURI.build('insiderThreat', 'checkBasicUserInUPM')+'/'+$rootScope.loggedAttId;
     
        if($location.host() === 'localhost'){
            if($location.port() === 9000){
              serviceURI = 'json/checkThreshold.json';
            }
        }
        
        $http({
            method: 'GET',
            url: serviceURI
           }).then(function(data){
                defer.resolve(data.data);
             }, 
        function(failedReason){
            defer.reject(failedReason);
        });
           
        return defer.promise;
        
    };
    topSummaryFactory.getUserPermissions= function(){
    
        var defer = $q.defer();
        var serviceURI = getServiceURI.build('insiderThreat', 'getUserPermissions');
     
        if($location.host() === 'localhost'){
            if($location.port() === 9000){
              serviceURI = 'json/permissions.json';
            }
        }
        
        $http({
            method: 'GET',
            url: serviceURI
           }).then(function(data){
                defer.resolve(data.data);
             }, 
        function(failedReason){
            defer.reject(failedReason);
        });
           
        return defer.promise;
        
    };


    return topSummaryFactory;   

    }
                        
]);