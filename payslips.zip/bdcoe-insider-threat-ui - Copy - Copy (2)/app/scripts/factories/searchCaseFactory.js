'use strict';

angular.module('insiderApp')
.factory('searchCaseFactory', ['$http', '$q', '$location', 'getServiceURI','$rootScope',
    function ($http, $q, $location, getServiceURI,$rootScope) {
        
        var searchCaseFactory = {};  
    
        searchCaseFactory.getsearchcase= function(caseID,data,page,size){
            var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'checkCaseIdIsPresent');
                   
            serviceURI = serviceURI +'/'+ caseID;
        
            if($location.host() === 'localhost'){
                    if($location.port() === 9000){
                        serviceURI='json/employeeDetails.json';
                    }
            }
              
            $http({
                    method: 'GET',
				    data : data,
                    url: serviceURI

                }).then(function(data){
                    defer.resolve(data.data);
                }, 
                function(failedReason){
                    defer.reject(failedReason);
                 });
                
            return defer.promise;
            
        };

  

        return searchCaseFactory;     
        
    }
                        
]);

