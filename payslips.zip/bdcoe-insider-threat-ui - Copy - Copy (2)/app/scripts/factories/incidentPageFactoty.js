'use strict';

angular.module('insiderApp')
.factory('incidentFactory', ['$http', '$q', '$location', 'getServiceURI','$rootScope',
	function ($http, $q, $location, getServiceURI,$rootScope) {
        
        var incidentFactory = {};  
        
        console.log('loggedAttId'+$rootScope.loggedAttId);
        
       
    
		incidentFactory.getAdminContacts= function(){

            var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'getContact');
                       
            	
             
               if($location.host() === 'localhost'){
                    if($location.port() === 9000){
                        serviceURI = 'json/incident.json';
                    }
                }

            	  
            $http({
					method: 'GET',
					url: serviceURI
				}).then(function(data){
					defer.resolve(data.data);
				},
                        
                function(failedReason){
					defer.reject(failedReason);
			     });
				
            return defer.promise;
		}
		
		incidentFactory.addNewContact= function(dataObj){
      var defer = $q.defer();
      var serviceURI = getServiceURI.build('insiderThreat', 'addNewContact')+'/'+$rootScope.loggedusername;
            
      if($location.host() === 'localhost'){
        if($location.port() === 9000){
          serviceURI = 'json/createNewCase.json';
        }
      }
      $http({
				method: 'POST',
  			url: serviceURI,
				data : dataObj
				}).then(function(data){
					defer.resolve(data.data);
  			},
      function(failedReason){
				defer.reject(failedReason);
	    });
	      return defer.promise;
			}

      incidentFactory.checkThreshold= function(dataObj){
      var defer = $q.defer();
      var serviceURI = getServiceURI.build('insiderThreat', 'checkThreshold')+'/'+$rootScope.loggedusername;
            
      if($location.host() === 'localhost'){
        if($location.port() === 9000){
          serviceURI = 'json/checkThreshold.json';
        }
      }
      $http({
        method: 'POST',
        url: serviceURI,
        data : dataObj
        }).then(function(data){
          defer.resolve(data.data);
        },
      function(failedReason){
        defer.reject(failedReason);
      });
        return defer.promise;
      }


     
    incidentFactory.updateContact=function(dataObj){

            var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'updateIncidentContacts');
                       
                serviceURI=serviceURI+'/'+ $rootScope.invId ;
             
               if($location.host() === 'localhost'){
                     if($location.port() === 9000){
                         serviceURI = 'json/createNewCase.json';
                     }
                }

                  
            $http({
                    //method: 'POST',
                    method: 'PUT',
                    url: serviceURI,                
                    data : dataObj
                }).then(function(data){
                    defer.resolve(data.data);
                console.log(data.data);
                },
                        
                function(failedReason){
                    defer.reject(failedReason);
                 });
                
            return defer.promise;
       

         }
        
         incidentFactory.removeContact=function(contactId){

        
            var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'deleteIncidentContacts');
            serviceURI=serviceURI+'/'+ contactId;

          $http({
                    method: 'DELETE',
                    url: serviceURI,
                
                
                
                }).then(function(data){
                    defer.resolve(data.data);
                },
                        
                function(failedReason){
                    defer.reject(failedReason);
                 });
                
            return defer.promise;
 
         

      }  

      incidentFactory.getAllRuleId=function(){
     
      var defer = $q.defer();
      var serviceURI = getServiceURI.build('insiderThreat', 'getAllRuleId');
    
      
         if($location.host() === 'localhost'){
            if($location.port() === 9000){
              serviceURI = 'json/rules.json';
            }
          }
      
        $http({
          method: 'GET',
          url: serviceURI,
        }).then(function(data){
            defer.resolve(data.data);
        },
        function(failedReason){
          defer.reject(failedReason);
        });
   
       return defer.promise;
    }        
        
        
      
        return incidentFactory;	
}
                       
                            
]);