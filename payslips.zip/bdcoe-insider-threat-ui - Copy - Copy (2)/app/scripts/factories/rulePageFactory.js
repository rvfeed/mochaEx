'use strict';

angular.module('insiderApp')
.factory('rulePageFactory', ['$http', '$q', '$location', 'getServiceURI','$rootScope','SessionService',
	function ($http, $q, $location, getServiceURI,$rootScope,SessionService) {
        
        var rulePageFactory = {};  
    
		rulePageFactory.getRules= function(){

            var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'getRules');
                       
            	serviceURI=serviceURI+'/'+ $rootScope.loggedAttId ;
             
               if($location.host() === 'localhost'){
            if($location.port() === 9000){
                serviceURI = 'json/rules.json';
            }
       }

            	  
            $http({
					method: 'GET',
					url: serviceURI
				}).then(function(data){
					defer.resolve(data.data);
				},
                        
                function(failedReason){
					defer.reject(failedReason);
			     });
				
            return defer.promise;
			}
		
		rulePageFactory.editRules= function(dataObj){

            var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'updateByRuleId');
            
             $rootScope.loggedusername = SessionService.getLegacyUIDs('cingularCUID');
			
			//{ruleId}/{thresholdValue}/{timeFrameDaysValue}
           
            	//serviceURI=serviceURI+'/'+ $rootScope.loggedAttId + '/' + dataObj.ruleNumber + '/' + dataObj.treshold + '/' + dataObj.timeframe;

            	serviceURI=serviceURI+'/'+ $rootScope.loggedusername + '/' + dataObj.ruleNumber + '/' + dataObj.treshold + '/' + dataObj.timeframe+'/'+dataObj.recycleDays;
            
             	console.log(serviceURI);
               if($location.host() === 'localhost'){
          			  if($location.port() === 90001){
               			 serviceURI = 'json/createNewCase.json';
           			 }
      			 }

            	  
            $http({
					method: 'PUT',
					url: serviceURI,
				
				
				
				}).then(function(data){
					defer.resolve(data.data);
				},
                        
                function(failedReason){
          defer.reject(failedReason);
           });
        
            return defer.promise;
      }

      //get Activity Log data of employee
        rulePageFactory.getRuleHistorySummary= function(){
        
            var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'getRuleHistorySummary')
            
            
              if($location.host() === 'localhost'){
                    if($location.port() === 9000){
                       serviceURI='json/ruleDetailsActivityLog.json';
           
                    }
            }
                
            $http({
                    method: 'GET',
                    url: serviceURI
                  
                }).then(function(data){
                    defer.resolve(data.data);
                }, 
                function(failedReason){
                    defer.reject(failedReason);
                 });
                
            return defer.promise;
            
        };
        
        
      
        return rulePageFactory; 
}
                       
                            
]);