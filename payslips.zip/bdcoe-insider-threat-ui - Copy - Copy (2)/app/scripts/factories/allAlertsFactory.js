'use strict';

angular.module('insiderApp')
.factory('allAlertsFactory', ['$http', '$q', '$location', 'getServiceURI','$rootScope',
	function ($http, $q, $location, getServiceURI,$rootScope) {
        
        var allAlertsFactory = {};  
    
		allAlertsFactory.getEventDetailsData= function(suspectId,startDate,endDate){

            var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'exportAllAlertsPageData');
                       
            serviceURI=serviceURI+'/'+ $rootScope.loggedAttId+'/'+suspectId+'/'+ startDate+'/'+endDate;
            console.log("service URI is::::::::::::",serviceURI);
            if($location.host() === 'localhost'){
                if($location.port() === 9000){
                    serviceURI = 'json/eventDetails.json';
                }
            }
              
            $http({
                method: 'GET',
                url: serviceURI
            }).then(function(data){
                defer.resolve(data.data);
            },
                      
            function(failedReason){
                defer.reject(failedReason);
            });
            
            return defer.promise;
        }
        
         ///New code...
        allAlertsFactory.checkalertId=function(suspectId,AlertId){

           /* var x = new Date();
            var endDate = x.getFullYear().toString() + (x.getMonth()+1) + x.getDate();
            var y = new Date(x.getDate()-60);
            var startDate =  y.getFullYear().toString() + (y.getMonth()+1) + y.getDate();*/

           
           var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'checkAlertIdInSummary');                       
            serviceURI=serviceURI+'/'+suspectId+'/'+AlertId;
            console.log("service URI is::::::::::::",serviceURI);
            if($location.host() === 'localhost'){
                if($location.port() === 9000){                    
                            
                  serviceURI = 'json/checkalertId.json';
                }
            }              
            $http({
                method: 'GET',
                url: serviceURI
            }).then(function(data){
                defer.resolve(data.data);
                console.log(data.data)
            },
                      
            function(failedReason){
                defer.reject(failedReason);
            });
            
            return defer.promise;
      
        } 
           
        allAlertsFactory.creatNewCase= function(newCaseInfo,page,size){

            var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'allAlertsCaseCreation');
                       
            serviceURI=serviceURI+'/'+ $rootScope.loggedAttId;
            console.log("service URI is::::::::::::",serviceURI);
            if($location.host() === 'localhost'){
                if($location.port() === 9000){
                    serviceURI = 'json/newCase.json';
                }
            }
           	  
            $http({
				method: 'POST',
               // method: 'GET',
                data:newCaseInfo,
				url: serviceURI,
                params:{
                        'page' :  page,
                        'size' : size
                    },
                 headers: {
                'Content-Type': 'application/json'
            },
			}).then(function(data){
				defer.resolve(data.data);
			},
                      
            function(failedReason){
    			defer.reject(failedReason);
	        });
			
            return defer.promise;
		}

      allAlertsFactory.getAllAlertsByFilters= function(newCaseInfo,page,size){

            var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'getAllAlertsByFilters');
                       
            serviceURI=serviceURI+'/'+ $rootScope.loggedAttId;
            console.log("service URI is::::::::::::",serviceURI);
            if($location.host() === 'localhost'){
                if($location.port() === 9000){
                    serviceURI = 'json/newCase.json';
                }
            }
           	  
            $http({
				method: 'POST',
               // method: 'GET',
                data:newCaseInfo,
				url: serviceURI,
                params:{
                        'page' :  page,
                        'size' : size
                    },
                 headers: {
                'Content-Type': 'application/json'
            },
			}).then(function(data){
				defer.resolve(data.data);
			},
                      
            function(failedReason){
    			defer.reject(failedReason);
	        });
			
            return defer.promise;
		}
          allAlertsFactory.creatNewCaseWithSorting= function(newCaseInfo, page, size, sortingField, sortDirection){

            var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'getAllAlertsByFilters');
                       
            serviceURI=serviceURI+'/'+ $rootScope.loggedAttId;
            console.log("service URI is::::::::::::",serviceURI);
            if($location.host() === 'localhost'){
                if($location.port() === 9000){
                    serviceURI = 'json/newCase.json';
                }
            }
              
            $http({
                method: 'POST',
               // method: 'GET',
                data:newCaseInfo,
                  params: {
                'page': page,
                'size': size,
                'sort': sortingField,
                'sortDirection' : sortDirection
             },
             headers: {
                 'Content-Type': 'application/json'
                 
             },
                url: serviceURI
            }).then(function(data){
                defer.resolve(data.data);
            },
                      
            function(failedReason){
                defer.reject(failedReason);
            });
            
            return defer.promise;
        }
        
        return allAlertsFactory;	
    }
                       
                            
]);