'use strict';

angular.module('insiderApp')
.factory('allCasesFactory', ['$http', '$q', '$location', 'getServiceURI','$rootScope',
        function ($http, $q, $location, getServiceURI,$rootScope) {
        
                var allCasesDataFactory = {};  
    
                allCasesDataFactory.getAllCasesData= function(data,page,size){

                var defer = $q.defer();
                var serviceURI =getServiceURI.build('insiderThreat', 'allCasesData');
                               
                if($location.host() === 'localhost'){
                    if($location.port() === 9000){
                      serviceURI = 'json/allCases.json';
                        }
                }
                 

                $http({
  					//method : 'POST',
                   method: 'GET', 
  					url: serviceURI,

                params:{
                  'page' :  page,
                  'size' : size
                },
                headers: {
      	   					'Content-Type': 'application/json'
      	 				},
      			
    				    data: data
              }).then(function(data){
                  defer.resolve(data.data);
             },

           
                        
        function(failedReason){
            defer.reject(failedReason);
          });
                
            return defer.promise;
            };
        
        allCasesDataFactory.bulkCloseOfAllCasesInfo= function(bulkCloseData,removeCasesArray,caseDispostion){

            var defer = $q.defer();

            var serviceURI = getServiceURI.build('insiderThreat', 'deleteCaseIds')+'?caseIds='+removeCasesArray+'&CaseDisposition='+caseDispostion;


                 $http({
                  //  method: 'POST',
                     method: 'GET',
                    url: serviceURI,
                     data: bulkCloseData   
                     
                     }).then(function(data){
                        defer.resolve(data.data);
                     }, 
                    function(failedReason){
                        defer.reject(failedReason);
                     });
                    
                return defer.promise;
            };
		
		allCasesDataFactory.getCompanyDetails = function(){
			
		
			var defer = $q.defer();
			
			var serviceURI =getServiceURI.build('insiderThreat', 'allCompanyData');
                               
            if($location.host() === 'localhost'){
                if($location.port() === 9000){
                  serviceURI = 'json/allCompany.json';
             }
            }
			
			$http({
				
				method : 'GET',
				url : serviceURI,
				headers : {
					
					'Content-Type' : 'application/json'
				}
							
			}).then(function(data){
				defer.resolve(data);
				
				
			},
				   
				function(failedReason){
				defer.reject(failedReason);
			}
				   
				   );
			
			return defer.promise;
		
		};

    allCasesDataFactory.getLocationDetails = function(){
        var defer = $q.defer();
            
            var serviceURI =getServiceURI.build('insiderThreat', 'getLocationDetails');
                               
            if($location.host() === 'localhost'){
                if($location.port() === 9000){
                  serviceURI = 'json/locationDetails.json';
             }
            }
            
            $http({
                
                method : 'GET',
                url : serviceURI,
                 headers : {
                    
                     'Content-Type' : 'application/json'
                }
                            
            }).then(function(data){
                defer.resolve(data);
                
                
            },
                   
                function(failedReason){
                defer.reject(failedReason);
            }
                   
                   );
            
            return defer.promise;
    }
        
    allCasesDataFactory.getAllCasesDataWithSorting = function(data, page, size, sortingField, sortDirection) {

         var defer = $q.defer();
         var serviceURI =getServiceURI.build('insiderThreat', 'allCasesData');
        
         if($location.host() === 'localhost'){
            if($location.port() === 9000){
               serviceURI = 'json/allCases.json';
            }
         }

       
         $http({
             method: 'GET',
             //method : 'POST',
             url: serviceURI,
             params: {
                'page': page,
                'size': size,
                'sort': sortingField,
                'sortDirection' : sortDirection
             },
             headers: {
                 'Content-Type': 'application/json'
                 
             },

             data: data
         }).then(function(data) {
                 defer.resolve(data.data);
             },
             function(failedReason) {
                 defer.reject(failedReason);
             }
          );

         return defer.promise;
    }; 
        
           
        return allCasesDataFactory; 
}
                        
                            
]);