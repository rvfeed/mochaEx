'use strict';

angular.module('insiderApp')
    .factory('caseNotesFactory', ['$http', '$q', '$location', 'getServiceURI','$rootScope',
    	function ($http, $q, $location, getServiceURI,$rootScope) {
            
            var caseNotesFactory = {};
        
    		caseNotesFactory.getCaseNotesData = function(caseId){

                var defer = $q.defer();
                var serviceURI = getServiceURI.build('insiderThreat', 'caseNotesData');
                           
            	serviceURI=serviceURI+'/'+caseId;

                if($location.host() === 'localhost'){
                    if($location.port() === 9000){
                        serviceURI = 'json/caseNotes.json';
                    }
                }
                	  
                $http({
                    method: 'GET',
                    url: serviceURI
                }).then(function(data){
                    defer.resolve(data.data);
                },
                function(failedReason){
                    defer.reject(failedReason);
                });
    				
                return defer.promise;
            };





            caseNotesFactory.saveNotesData = function(caseId,data){
            
                var defer = $q.defer();
                var serviceURI = getServiceURI.build('insiderThreat', 'saveNotesDataDetails');
                      
                serviceURI=serviceURI+'/'+caseId;


                if($location.host() === 'localhost'){
                    if($location.port() === 9000){
                         serviceURI="json/updateCaseNotes.json";
                    }
                }

                $http({
                        method: 'POST',
                        url: serviceURI,
                        data: data                      
                    }).then(function(data){
                        defer.resolve(data.data);
                    }, 
                    function(failedReason){
                        defer.reject(failedReason);
                     });
                    
                return defer.promise;
                
            };

 caseNotesFactory.getNotesDetailsDataWithSorting = function(caseID,sortingField, sortDirection) {

         var defer = $q.defer();
         var serviceURI =getServiceURI.build('insiderThreat', 'caseNotesData');
          serviceURI = serviceURI +'/' + caseID;
       // serviceURI=serviceURI+'/'+caseId;

         if($location.host() === 'localhost'){
            if($location.port() === 9000){
               serviceURI = 'json/caseNotesWithSorting.json';
            }
         }

        
         $http({
            // method: 'POST',
             method : 'GET',
             url: serviceURI,
             params: {
                'sort': sortingField,
                'sortDirection' : sortDirection
             },
             headers: {
                 'Content-Type': 'application/json'
                 
             }

         
         }).then(function(data) {
                 defer.resolve(data.data);
             },
             function(failedReason) {
                 defer.reject(failedReason);
             }
          );

         return defer.promise;
    }; 



            return caseNotesFactory;
        }
                           
                                
    ]);