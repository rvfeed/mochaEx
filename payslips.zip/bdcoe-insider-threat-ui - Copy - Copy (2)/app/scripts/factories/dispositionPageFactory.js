'use strict';

angular.module('insiderApp')
.factory('dispositionPageFactory', ['$http', '$q', '$location', 'getServiceURI','$rootScope',
        function ($http, $q, $location, getServiceURI,$rootScope) {
        console.log($rootScope.invId+"---------------");
          
                var dispositionPageFactory = {};  
    
                dispositionPageFactory.getDisposition = function(page,size){

                var defer = $q.defer();
                var serviceURI =getServiceURI.build('insiderThreat', 'getDisposition')+'/'+$rootScope.loggedAttId;
                               
                if($location.host() === 'localhost'){
                    if($location.port() === 9000){
                      serviceURI = 'json/disposition.json';
                        }
                }
                 

                $http({
  				//	method : 'POST',
                    method: 'GET', 
  					url: serviceURI,

                params:{
                  'page' :  page,
                  'size' : size
                },
                headers: {
      	   					'Content-Type': 'application/json'
      	 				}      			
              }).then(function(data){
                  defer.resolve(data.data);
             },

           
                        
        function(failedReason){
            defer.reject(failedReason);
          });
                
            return defer.promise;
            };
      
            dispositionPageFactory.createDisposition= function(dataObj){
      var defer = $q.defer();
      var serviceURI = getServiceURI.build('insiderThreat', 'createDisposition')+'/'+$rootScope.loggedAttId;
            
      if($location.host() === 'localhost'){
        if($location.port() === 9000){
          serviceURI = 'json/createNewDisposition.json';
        }
      }
      $http({
				method: 'POST',
  			url: serviceURI,
				data : dataObj
				}).then(function(data){
					defer.resolve(data.data);
  			},
      function(failedReason){
				defer.reject(failedReason);
	    });
	      return defer.promise;
			}
                
                
                  dispositionPageFactory.updateDisposition=function(dataObj){

            var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'updateDisposition')+'/'+$rootScope.loggedAttId;
               if($location.host() === 'localhost'){
                     if($location.port() === 9000){
                         serviceURI = 'json/updateDisposition.json';
                     }
                }

                  
            $http({
                    method: 'POST',                    
                    url: serviceURI,                
                    data : dataObj
                }).then(function(data){
                    defer.resolve(data.data);
                console.log(data.data);
                },
                        
                function(failedReason){
                    defer.reject(failedReason);
                 });
                
            return defer.promise;
       

         }
        
         dispositionPageFactory.deleteDisposition=function(data){

        
            var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'removeDisposition')+'/'+$rootScope.loggedAttId;
            
          $http({
                    method: 'POST',
                    url: serviceURI,
                    data : data                
                }).then(function(data){
                    defer.resolve(data.data);
                },
                        
                function(failedReason){
                    defer.reject(failedReason);
                 });
                
            return defer.promise; 
         

      }  
      

      
      dispositionPageFactory.getDispositionLogDataWithSorting = function(page, size, sortingField, sortDirection) {

         var defer = $q.defer();
         var serviceURI =getServiceURI.build('insiderThreat', 'getSettingsHistory');
        var params = {
                'page': page,
                'size': size,
                'sort': sortingField,
                'sortDirection' : sortDirection
             };
         if($location.host() === 'localhost'){
            if($location.port() === 9000){
               serviceURI = 'json/dispositionLogHistory.json';
                params = {};               
            }
         }

       
         $http({           
             method : 'GET',
             url: serviceURI,
             params: params,
             headers: {
                 'Content-Type': 'application/json'
                 
             }
            
         }).then(function(data) {
                 defer.resolve(data.data);
             },
             function(failedReason) {
                 defer.reject(failedReason);
             }
          );

         return defer.promise;
    }; 
            
    dispositionPageFactory.getDispositionDataWithSorting = function(page, size, sortingField, sortDirection) {

         var defer = $q.defer();
         var serviceURI =getServiceURI.build('insiderThreat', 'getDisposition')+'/'+$rootScope.loggedAttId;
        var params = {
                'page': page,
                'size': size,
                'sort': sortingField,
                'sortDirection' : sortDirection
             };
      
         if($location.host() === 'localhost'){
            if($location.port() === 9000){
               serviceURI = 'json/disposition.json';
                params = {};               
            }
         }

       
         $http({
             method: "GET",           
             url: serviceURI,
             params: params,
             headers: {
                 'Content-Type': 'application/json'
                 
             }
            
         }).then(function(data) {
                 defer.resolve(data.data);
             },
             function(failedReason) {
                 defer.reject(failedReason);
             }
          );

         return defer.promise;
    }; 
        
  
        return dispositionPageFactory; 
}
                        
                            
]);