'use strict';

angular.module('insiderApp')
.factory('caseDetailFactory', ['$http', '$q', '$location', 'getServiceURI','$rootScope',
    function ($http, $q, $location, getServiceURI,$rootScope) {
        
        var caseDetailFactory = {};  
    
        caseDetailFactory.getCaseDetailData= function(caseID,data,page,size){
            var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'getCaseSummary');
                   
            serviceURI = serviceURI +'/'+$rootScope.loggedAttId+ '/'+ caseID;
        
            if($location.host() === 'localhost'){
                    if($location.port() === 9000){
                        serviceURI='json/employeeDetails.json';
                    }
            }
              
            $http({
                    method: 'GET',
				    data : data,
                    url: serviceURI

                }).then(function(data){
                    defer.resolve(data.data);
                }, 
                function(failedReason){
                    defer.reject(failedReason);
                 });
                
            return defer.promise;
            
        };

        caseDetailFactory.getGraphDetailData= function(attID){
            var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'getDailySummary');
           
            var x = new Date();
            var endDate = x.getFullYear().toString() + (x.getMonth()+1) + x.getDate();
            var y = new Date(x.getDate()-60);
            var startDate =  y.getFullYear().toString() + (y.getMonth()+1) + y.getDate();

            serviceURI = serviceURI + '/'+ $rootScope.loggedAttId + '/' + attID + '/' + startDate + '/' + endDate;
        //   serviceURI='json/graphData.json';
       // console.log("attID----", attID);
           if($location.host() === 'localhost'){
                    if($location.port() === 9000){
                        serviceURI='json/graphData.json';
                    }
            }
            
            $http({
                    method: 'GET',
                    url: serviceURI
                  
                }).then(function(data){
                    defer.resolve(data.data);
                }, 
                function(failedReason){
                    defer.reject(failedReason);
                 });
                
            return defer.promise;
            
        };

           caseDetailFactory.bulkCloseCaseInfo= function(removeCasesArray,caseId,dispositionValue){

            var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'closeCaseAlerts')+'/'+caseId + '/' + $rootScope.loggedAttId +'?alertIds='+removeCasesArray+'&alertDisposition='+dispositionValue;

             $http({
                method: 'DELETE',
                url: serviceURI
                 
                 }).then(function(data){
                    defer.resolve(data.data);
                 }, 
                function(failedReason){
                    defer.reject(failedReason);
                 });
                
            return defer.promise;
        };
        
            
    caseDetailFactory.getCaseOwners= function(){
        
            var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'getCaseManagers');
           
            serviceURI = serviceURI ; 
           if($location.host() === 'localhost'){
                    if($location.port() === 9000){
                        serviceURI='json/caseOwners.json';
                    }
            }
            
             $http({
                    method: 'GET',
                    url: serviceURI
                  
                }).then(function(data){
                    defer.resolve(data.data);
                }, 
                function(failedReason){
                    defer.reject(failedReason);
                 });
                
            return defer.promise;
            
        };
        
        //Update Visited or Bookmarked status for activity Log data
        
        caseDetailFactory.activitylogVisited= function(caseNumber){
        
            var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'activitylogVisited');
           
            serviceURI = serviceURI + '/' + caseNumber  + '/' + $rootScope.loggedAttId ; 
            
             $http({
                    method: 'GET',
                    url: serviceURI
                  
                }).then(function(data){
                    defer.resolve(data.data);
                }, 
                function(failedReason){
                    defer.reject(failedReason);
                 });
                
            return defer.promise;
            
        };
        
        caseDetailFactory.autoAssignCase= function(caseID){
        
            var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'autoAssignCase');
               
            serviceURI = serviceURI+ '/'+ caseID + '/' + $rootScope.loggedAttId ;
            
          
            $http({
                    method: 'PUT',
                    url: serviceURI
                  
                }).then(function(data){
                    defer.resolve(data.data);
                }, 
                function(failedReason){
                    defer.reject(failedReason);
                 });
                
            return defer.promise;
            
        };
        
        
         //get Activity Log data of employee
        caseDetailFactory.getCaseHistorySummary= function(caseID,page,size,sortingField, sortDirection){
        
            var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'getCaseHistorySummary')+'?caseNumber='+caseID;
            
            
              if($location.host() === 'localhost'){
                    if($location.port() === 9000){
                       serviceURI='json/employeeDetailsActivityLog.json';
           
                    }
            }
                
            $http({
                    method: 'GET',
                    url: serviceURI,
                   params: {
                'page': page,
                'size': size,
                'sort': sortingField,
                'sortDirection' : sortDirection
                }
                }).then(function(data){
                    defer.resolve(data.data);
                }, 
                function(failedReason){
                    defer.reject(failedReason);
                 });
                
            return defer.promise;
            
        };

        caseDetailFactory.changeCaseStatus= function(dropDownValue,caseId,dropDownType,caseOwnerAttID){
        
            var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'updateCaseDetails');
                  
            serviceURI = serviceURI+'/'+caseOwnerAttID+'/'+ caseId+'/'+dropDownType+'/'+dropDownValue;
            //console.log("data change value::::::::::::::",serviceURI);
              if($location.host() === 'localhost'){
                    if($location.port() === 9000){
                       serviceURI="json/searchResults.json";
           
                    }
            }
                
            $http({
                    /*method: 'PUT',*/
                    method: 'PUT',
                    url: serviceURI
                  
                }).then(function(data){
                    defer.resolve(data.data);
                }, 
                function(failedReason){
                    defer.reject(failedReason);
                 });
                
            return defer.promise;
            
        };

        caseDetailFactory.getCaseDetailsDataWithSorting = function(caseID,data, page, size, sortingField, sortDirection) {

         var defer = $q.defer();
         var serviceURI =getServiceURI.build('insiderThreat', 'getCaseSummary');
          serviceURI = serviceURI +'/'+$rootScope.loggedAttId+ '/'+ caseID;
        

         if($location.host() === 'localhost'){
            if($location.port() === 9000){
               serviceURI = 'json/caseDetailsWithSorting.json';
            }
         }

         //console.log('url is**********',serviceURI);
         $http({
             method: 'GET',
             //method : 'GET',
             url: serviceURI,
             params: {
               /* 'page': page,
                'size': size,*/
                'sort': sortingField,
                'sortDirection' : sortDirection
             },
             headers: {
                 'Content-Type': 'application/json'
                 
             },

             data: data
         }).then(function(data) {
                 defer.resolve(data.data);
             },
             function(failedReason) {
                 defer.reject(failedReason);
             }
          );

         return defer.promise;
    }; 
    
        
      caseDetailFactory.getActivityLogDataWithSorting= function(caseID,page,size,sortingField, sortDirection){
        
        var defer = $q.defer();
        var serviceURI = getServiceURI.build('insiderThreat', 'getCaseHistorySummary')+'?caseNumber='+caseID;
            
        if($location.host() === 'localhost'){
            if($location.port() === 9000){
                serviceURI='json/employeeDetailsActivityLog.json';
            }
        }
                
        $http({
            method: 'GET',
            url: serviceURI,
            params: {
                'page': page,
                'size': size,
                'sort': sortingField,
                'sortDirection' : sortDirection
             },
            headers: {
                'Content-Type': 'application/json'
            }
                  
        }).then(function(data){
            defer.resolve(data.data);
        }, 
        function(failedReason){
            defer.reject(failedReason);
        });
                
        return defer.promise;
            
        };

        return caseDetailFactory;     
        
    }
                        
]);


