'use strict';

angular.module('insiderApp')
.factory('dispositionFactory', ['$http', '$q', '$location', 'getServiceURI','$rootScope','SessionService',
	function ($http, $q, $location, getServiceURI,$rootScope,SessionService) {
        
        var dispositionFactory = {};  
    
		dispositionFactory.getAllDisposition= function(){

            var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'getAllDisposition');
                       
            	serviceURI=serviceURI+'/'+ $rootScope.loggedAttId ;
             
               if($location.host() === 'localhost'){
            if($location.port() === 9000){
                serviceURI = 'json/disposition.json';
            }
       }

            	  
            $http({
					method: 'GET',
					url: serviceURI
				}).then(function(data){
					defer.resolve(data.data);
				},
                        
                function(failedReason){
					defer.reject(failedReason);
			     });
				
            return defer.promise;
			}
        return dispositionFactory;
		
    }
                       
                            
]);