'use strict';

angular.module('insiderApp')
.factory('alertDetailsFactory', ['$http', '$q', '$location', 'getServiceURI','$rootScope',function ($http, $q, $location, getServiceURI,$rootScope) {
        
    var alertDetailsFactory = {};  
	
    
    alertDetailsFactory.getAlertDetailsEventsData= function(caseId,alertId,page,size,alertFilterdata){
    
        var defer = $q.defer();
        var serviceURI = getServiceURI.build('insiderThreat', 'getAlertDetailsEventsData')+'/'+$rootScope.loggedAttId+'/'+caseId+'/'+alertId;
      
        if($location.host() === 'localhost'){
            if($location.port() === 9000){
               serviceURI='json/alertDetails.json';
            }
       }

        $http({
            method: 'POST',
            url: serviceURI,
       			params:{
    						'page' :  page,
           				'size' : size
           			},
                 headers: {
                'Content-Type': 'application/json'
            },
            data: alertFilterdata
           }).then(function(data){
                defer.resolve(data.data);
             }, 
             function(failedReason){
                    defer.reject(failedReason);

             });                
            return defer.promise;        
        }; 
 
     alertDetailsFactory.getAlertDetailsEventsDataWithSorting = function(caseId,alertId,alertFilterdata, page, size, sortingField, sortDirection) {
        var defer = $q.defer();
         var serviceURI =getServiceURI.build('insiderThreat', 'getAlertDetailsEventsData')+'/'+$rootScope.loggedAttId+'/'+caseId+'/'+alertId;;
         if($location.host() === 'localhost'){
            if($location.port() === 9000){
               serviceURI = 'json/alertDetails.json';
            }
         }

         //console.log('url is**********',serviceURI);
         $http({
             method: 'POST',
             //method : 'POST',
             url: serviceURI,
             params: {
                'page': page,
                'size': size,
                'sort': sortingField,
                'sortDirection' : sortDirection
             },
             headers: {
                 'Content-Type': 'application/json'
                 
             },

             data: alertFilterdata
         }).then(function(data) {
                 defer.resolve(data.data);
             },
             function(failedReason) {
                 defer.reject(failedReason);
             }
          );

         return defer.promise;
    }; 
	
	
	alertDetailsFactory.getBanData = function(){
	
		var defer = $q.defer();
		
		  var serviceURI = getServiceURI.build('insiderThreat', 'getalertBanDetails');
      
        if($location.host() === 'localhost'){
            if($location.port() === 9000){
               serviceURI='json/banDetails.json';
            }
       }

        $http({
            method: 'GET',
            url: serviceURI,
          
           }).then(function(data){
                defer.resolve(data.data);
             }, 
             function(failedReason){
                    defer.reject(failedReason);

             });
		
		
		return defer.promise;
	};

        return alertDetailsFactory;	
    }
                        
]);