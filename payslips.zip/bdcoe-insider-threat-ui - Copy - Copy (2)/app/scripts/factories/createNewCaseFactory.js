'use strict';

angular.module('insiderApp')
.factory('createNewCaseFactory', ['$http', '$q', '$location', 'getServiceURI','$rootScope',
	function ($http, $q, $location, getServiceURI,$rootScope) {
        
        var createNewCaseFactory = {};  
    
		createNewCaseFactory.getEventDetailsData= function(suspectId,startDate,endDate){

            var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'getDailySummary');
                       
            serviceURI=serviceURI+'/'+ $rootScope.loggedAttId+'/'+suspectId+'/'+ startDate+'/'+endDate;
            console.log("service URI is::::::::::::",serviceURI);
            if($location.host() === 'localhost'){
                if($location.port() === 9000){
                    serviceURI = 'json/eventDetails.json';
                }
            }
              
            $http({
                method: 'GET',
                url: serviceURI
            }).then(function(data){
                defer.resolve(data.data);
            },
                      
            function(failedReason){
                defer.reject(failedReason);
            });
            
            return defer.promise;
        }
        
         ///New code...
        createNewCaseFactory.checkalertId=function(suspectId,AlertId){

           /* var x = new Date();
            var endDate = x.getFullYear().toString() + (x.getMonth()+1) + x.getDate();
            var y = new Date(x.getDate()-60);
            var startDate =  y.getFullYear().toString() + (y.getMonth()+1) + y.getDate();*/

           
           var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'checkAlertIdInSummary');                       
            serviceURI=serviceURI+'/'+suspectId+'/'+AlertId;
            console.log("service URI is::::::::::::",serviceURI);
            if($location.host() === 'localhost'){
                if($location.port() === 9000){                    
                            
                  serviceURI = 'json/checkalertId.json';
                }
            }              
            $http({
                method: 'GET',
                url: serviceURI
            }).then(function(data){
                defer.resolve(data.data);
                console.log(data.data)
            },
                      
            function(failedReason){
                defer.reject(failedReason);
            });
            
            return defer.promise;
      
        }        
       ///New code End...

        createNewCaseFactory.creatNewCase= function(newCaseInfo,page,size){

            var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'createManualCaseNew');
                       
            serviceURI=serviceURI+'/'+ $rootScope.loggedAttId;
            console.log("service URI is::::::::::::",serviceURI);
            if($location.host() === 'localhost'){
                if($location.port() === 9000){
                    serviceURI = 'json/newCase.json';
                }
            }
           	  
            $http({
				method: 'POST',
                data:newCaseInfo,
				url: serviceURI,
                params:{
                        'page' :  page,
                        'size' : size
                    },
                 headers: {
                'Content-Type': 'application/json'
            },
			}).then(function(data){
				defer.resolve(data.data);
			},
                      
            function(failedReason){
    			defer.reject(failedReason);
	        });
			
            return defer.promise;
		}


          createNewCaseFactory.creatNewCaseWithSorting= function(newCaseInfo, page, size, sortingField, sortDirection){

            var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'createManualCaseNew');
                       
            serviceURI=serviceURI+'/'+ $rootScope.loggedAttId;
            console.log("service URI is::::::::::::",serviceURI);
            if($location.host() === 'localhost'){
                if($location.port() === 9000){
                    serviceURI = 'json/newCase.json';
                }
            }
              
            $http({
                method: 'POST',
                data:newCaseInfo,
                  params: {
                'page': page,
                'size': size,
                'sort': sortingField,
                'sortDirection' : sortDirection
             },
             headers: {
                 'Content-Type': 'application/json'
                 
             },
                url: serviceURI
            }).then(function(data){
                defer.resolve(data.data);
            },
                      
            function(failedReason){
                defer.reject(failedReason);
            });
            
            return defer.promise;
        }
                createNewCaseFactory.addAlertToCaseFromCaseDetails= function(newCaseInfo){

            var defer = $q.defer();
            var serviceURI = getServiceURI.build('insiderThreat', 'addAlertToCaseFromCaseDetails');
                       
            serviceURI=serviceURI+'/'+ $rootScope.loggedAttId+"?caseId="+newCaseInfo.caseId+"&alertId="+newCaseInfo.alertId;
            console.log("service URI is::::::::::::",serviceURI);
            if($location.host() === 'localhost'){
                if($location.port() === 9000){
                    serviceURI = 'json/newCase.json';
                }
            }
           	  
            $http({
				method: 'PUT',                
				url: serviceURI,           
                 headers: {
                'Content-Type': 'application/json'
            },
			}).then(function(data){
				defer.resolve(data.data);
			},
                      
            function(failedReason){
    			defer.reject(failedReason);
	        });
			
            return defer.promise;
		}
        
        return createNewCaseFactory;	
    }
                       
                            
]);