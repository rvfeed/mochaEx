'use strict';

angular.module('insiderApp')
.factory('dateTimeFactory', ['$filter', '$rootScope', function($filter, $rootScope){

    var dateTimeFactory = {};

	dateTimeFactory.changeToLocalTime = function(cst){
		var localDate = $filter('date')(new Date(cst), 'MM/dd/yyyy');
		var localTime = $filter('date')(new Date(cst), 'HH:mm:ss');
        var createDateTime = (localDate + "  " + localTime);
        return createDateTime;
	}
    dateTimeFactory.changeToLocalDate = function(cst){
		var localDate = $filter('date')(new Date(cst), 'MM/dd/yyyy');
		return localDate;
	}
    dateTimeFactory.changeToLocalTimeFromDate = function(cst){
        var date = "";
		if(cst && cst.indexOf("-") > -1 && cst.indexOf(",") > -1){
            date = cst.split("-").join("/").split(",").join(" ");
        
        }
		return date;
	}
    dateTimeFactory.changeToLocalDateFromDate = function(cst){
        var date = "";
		if(cst  && cst.indexOf("-") > -1 ){
            date = cst.substring(0,10).split("-").join("/");
        
        }
		return date;
	}

	dateTimeFactory.getDateRanges=function(selectedDateRange){
    	var dateRangeArray=[];
	    if(selectedDateRange){
	    	dateRangeArray[0]=selectedDateRange.split('#')[0];
	        dateRangeArray[1]=selectedDateRange.split('#')[1];
	    }
	    else{
	    	dateRangeArray[0]='';
	        dateRangeArray[1]='';
	    }
      return dateRangeArray;
	}
    dateTimeFactory.getDateRangesFromRawDates=function(selectedDateRange){
    	var dateRangeArray=[];
	    if(selectedDateRange){
            if(selectedDateRange.indexOf('-')>-1){
                var splitArray = selectedDateRange.split('-')[0].split("/");
	    	   dateRangeArray[0]=splitArray[2]+""+splitArray[0]+""+splitArray[1];
                splitArray = selectedDateRange.split('-')[1].split("/");
	           dateRangeArray[1]=splitArray[2]+""+splitArray[0]+""+splitArray[1];
            }else{
                var splitArray = selectedDateRange.split("/");
                dateRangeArray[0]= dateRangeArray[1] = splitArray[2]+""+splitArray[0]+""+splitArray[1];
            }
	    }
	    else{
	    	dateRangeArray[0]='';
	        dateRangeArray[1]='';
	    }
      return dateRangeArray;
	}
	dateTimeFactory.getDateRangesFromRawDatesAsString=function(selectedDateRange){
    	var dateRangeArray=[];
	    if(selectedDateRange){
           if(selectedDateRange.indexOf('-')>-1){
                var splitArray = selectedDateRange.split('-')[0].split("/");
	    	   dateRangeArray[0]=splitArray[2]+"-"+splitArray[0]+"-"+splitArray[1];
                splitArray = selectedDateRange.split('-')[1].split("/");
	           dateRangeArray[1]=splitArray[2]+"-"+splitArray[0]+"-"+splitArray[1];
            }else{
                var splitArray = selectedDateRange.split("/");
                dateRangeArray[0]= dateRangeArray[1] = splitArray[2]+"-"+splitArray[0]+"-"+splitArray[1];
            }
	    }
	    else{
	    	dateRangeArray[0]='';
	        dateRangeArray[1]='';
	    }
      return dateRangeArray;
	}
    dateTimeFactory.lastPageLedger = function(page){
        if(!_.isEmpty($rootScope.lastPageLedger) && $rootScope.lastPageLedger !== undefined){                       
           $rootScope.lastPageLedger.lastPage = $rootScope.lastPageLedger.currentPage;
           $rootScope.lastPageLedger.currentPage = page;
         }else{
            $rootScope.lastPageLedger = { currentPage: page, lastPage: ""}
         }                    
    }
	
	return dateTimeFactory;
}]);



