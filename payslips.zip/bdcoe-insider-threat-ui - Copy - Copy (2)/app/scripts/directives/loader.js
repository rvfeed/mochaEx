'use strict';

/**
 * @ngdoc function
 * @name hubPeriodictableApp.directive:loader
 * @description
 * # loader
 * directive of the hubPeriodictableApp
 */

angular.module('insiderApp')
.controller('LoaderController', ['$scope',
	function ($scope) {

	}
])

.directive('loader', ['$http', '$filter',
	function ($http, $filter) {
		return {
			restrict:'EA',
			controller:'LoaderController',
			templateUrl: 'views/templates/loader.html'
		};
	}
]);