'use strict';
angular.module('insiderApp')
.directive("worldMap", ['$window','$rootScope',function($window,$rootScope) {
   return{
      restrict:'EA',
      scope: {
      		    mapData : '=',
             },
      template:"<div class='btn-group zoomsec' role='group' aria-label='aria-labelledby'><span class='zoomlable blue-60 omnesattII-medium'>Zoom</span><span class='zoombtnsec'><a  class='zoomBtn bg-blue-60' id='zoom_in'>+</a><a class='zoomBtn bg-blue-60' id='zoom_out'>-</a></span></div>",
       link: function(scope, elem, attrs){
           var data=scope.mapData;
           
             
          
           var width = $('.mapcontainer').width(),
               height = $('.mapcontainer').height(),
	           center = [width / 2, height / 2];
           
           var randomX = d3.random.normal(width / 2, 80),
               randomY = d3.random.normal(height / 2, 80);
           
           var projection = d3.geo.mercator()
	           .translate([width/ 2+94, height*0.5 / 2])
	           .center([0, 50])
	           .scale((width) / 2 / Math.PI);
  
            var svg = d3.select('.map').append('svg')
                .attr('width', width)
                .attr('height', height);
            
           var div = d3.select('.map').append('div')	
                .attr('class', 'tooltips');
           
           var path = d3.geo.path()
                .projection(projection);
           
           var g = svg.append('g').attr('width',width).attr('height',height);

            // load and display the World
           d3.json('json/worldMap.json', function(error, topology) {
                // load and display the cities
               
               renderOuterCircle(data,topology);
            });	
           
           function renderOuterCircle(data,topology){
                      
                $rootScope.loading = false;
                $rootScope.$apply();

                g.selectAll('path')
                .data(topojson.object(topology, topology.objects.countries)
                .geometries).enter().append('path').attr('d', path);
               
                   
            var circles = g.selectAll('circle').data(data).enter().append('g');
                       
            circles.append('circle')      

            .attr('cx', function(d) {
                    return (d.longitude === null||d.lattitude === null || d.longitude === " "||d.lattitude === " ")? ' ': projection([d.longitude, d.lattitude])[0];
                })
            .attr('cy', function(d) {
                    return (d.longitude === null||d.lattitude === null || d.longitude === " "||d.lattitude === " ")? ' ': projection([d.longitude, d.lattitude])[1];
                })
            .attr('r',function(d) { return (d.longitude === null || d.lattitude === null || d.longitude === " "||d.lattitude === " ")? ' ': d.probabilityScore+70; })
            .style('fill', function(d) {return (d.longitude === null||d.lattitude === null || d.longitude === " "||d.lattitude === " ")? ' ':'#fcd4d6';}).style('opacity','0.6');


            circles.append('circle')   
            .attr('cx', function(d) {
                    return (d.longitude === null||d.lattitude === null || d.longitude === " "||d.lattitude === " ")? ' ': projection([d.longitude, d.lattitude])[0];
                })
            .attr('cy', function(d) {
                    return  (d.longitude === null||d.lattitude === null || d.longitude === " "||d.lattitude === " " )? ' ': projection([d.longitude, d.lattitude])[1];
                })
            .attr('r',function(d) { return (d.longitude === null || d.lattitude === null || d.longitude === " "||d.lattitude === " ")? ' ': '13px' })
            .style('fill', function(d) {return '#ec000a';});



            var txt= g.selectAll('text')
            .data(data);
            txt.enter()      
            .append('text');
            txt.attr('x', function(d) {
                    return  (d.longitude === null||d.lattitude === null || d.longitude === " "||d.lattitude === " ")? ' ':(projection([d.longitude, d.lattitude])[0])-7;
                });
            txt.attr('y', function(d) {
                    return (d.longitude === null||d.lattitude === null|| d.longitude === " "||d.lattitude === " ")? ' ':(projection([d.longitude, d.lattitude])[1]+4);
                })
            .text( function (d) { return (d.longitude === null||d.lattitude === null || d.longitude === " "||d.lattitude === " ")? ' ':Math.round(d.probabilityScore*100); })
            .attr('font-size', '12px')
            .attr('text-align', 'center')
            .attr('font-family', 'omnesattII-medium')
            .attr('fill', '#fff')
            
            .on('mouseover', function(d) {

                div.attr('class', 'tooltips')	
                div.transition().style('opacity', .9);	
                
                div.html("<span class='maptooltip'><b>"+d.firstName+","+" " +d.lastName+"  "+"-"+" "+Math.round(d.probabilityScore*100)+"%"+"</b>"+ "<br/>" + d.callCenterCity+","+" "+d.callCenterState+"</span>")
                        
                .style('left', (d3.event.pageX-$('.maptooltip').width()/2) + 'px')		
                .style('top', d3.event.pageY-$(window).scrollTop()+18 + 'px');					
              
                localStorage.attID=d.attID;
                $rootScope.hoverMap(d.attID,'in');
            });
               
            

            $(window).scroll(function(){
                           div.attr('class', 'removeTooltip');
                  $rootScope.hoverMap( localStorage.attID,'out');
            });


           g.selectAll('circle').on('mouseover', function(d) {
              div.attr('class', 'removeTooltip');
              $rootScope.hoverMap( localStorage.attID,'out');

            });
           g.selectAll('path').on('mouseout', function(d) {
               div.attr('class', 'removeTooltip');
              $rootScope.hoverMap( localStorage.attID,'out');
            });
       
    }


    var zoom = d3.behavior.zoom()
        .scaleExtent([1, 5])
        .center([width / 2, height / 2])
        .size([width, height])
        .on('zoom', zoomed);
   svg
        .call(zoom)
       .call(zoom.event);

  
           
    function zoomed() {
        g.attr("transform", "translate(" + zoom.translate() + ")scale(" + zoom.scale() + ")");
    }       
    d3.select(self.frameElement).style('height', height + 'px');

    var intervalID;

    d3.selectAll('.zoomBtn').on('mousedown', function(){
    
        d3.event.preventDefault();
        var factor = (this.id === 'zoom_in') ? 1.1 : 1/1.1;
        intervalID = setInterval(zoomBy, 50, factor);
    }).on('mouseup', function(){
        d3.event.preventDefault();
        clearInterval(intervalID);
        intervalID = undefined;
    })

    function zoomBy(factor){
        var scale = zoom.scale(),
            extent = zoom.scaleExtent(),
            translate = zoom.translate(),
            x = translate[0], y = translate[1],
            target_scale = scale * factor;

        // If we're already at an extent, done
        if (target_scale === extent[0] || target_scale === extent[1]) { return false; }
        // If the factor is too much, scale it down to reach the extent exactly
        var clamped_target_scale = Math.max(extent[0], Math.min(extent[1], target_scale));
        if (clamped_target_scale != target_scale){
            target_scale = clamped_target_scale;
            factor = target_scale / scale;
        }

        // Center each vector, stretch, then put back
        x = (x - center[0]) * factor + center[0];
        y = (y - center[1]) * factor + center[1];

        // Enact the zoom immediately
        zoom.scale(target_scale)
            .translate([x,y]);
        zoomed();
    }

  }
  }

}]);