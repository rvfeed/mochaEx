'use strict';


angular.module('insiderApp')

.directive('autoData', [
	function () {
		return {
			restrict:'A',
			
            link: function(scope,ele,attr,controller,transcludeFn){
				
				
				
				
				  ele.autocomplete({
      source: scope.$eval(attr.company),
					  appendTo : '.companyNameGroup',
					  select : function(event,ui){
						  
						  scope.allcase.selectedCompany = ui.item.label;
						  
						  
						  
					  }
    });
				
				
				
			}
		};
	}
]);