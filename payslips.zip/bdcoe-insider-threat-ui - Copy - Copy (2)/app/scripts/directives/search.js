'use strict';

/**
 * @ngdoc function
 * @name kpiApp.controller:SearchCtrl
 * @description
 * # SearchCtrl
 * Controller of the kpiApp
 */
angular.module('insiderApp')
.controller('SearchCtrl', ['$rootScope', '$scope', 'searchFactory', '$routeParams', '$location', 'getUserPhoto', '$stateParams', '$sce',
	function ($rootScope, $scope, searchFactory, $routeParams, $location, getUserPhoto, $stateParams, $sce) {

		

        $('#search-result').addClass('ng-hide');
        
		$scope.searchParam = $stateParams.value;
                
        $scope.currentPage = 1;
        $scope.tableData = {};
        $scope.tableData.headers = {
            'ProfileImg':'',
            'owner' : 'OWNER',
            'uid' : 'UID',
            'title' : 'TITLE',
            'servers' : 'SERVERS'
        };
        
        $scope.perPageSelected = 20;

        $scope.update = function(){
            
            $rootScope.loading = true;
            
		searchFactory.getSearchResults($scope.searchParam, $scope.currentPage, $scope.perPageSelected).then(function(data){
			
            if(data.results && data.results.length > 0){
				$scope.totalRows = data.totalCount;
				$scope.userMLI = data.loggedInUserMLI;
				$scope.count = data.totalCount;

				$scope.results = data.results;
                                
                var rowData=[];
                for(var i=0; i < data.results.length; i++){
                    var person = data.results[i];
                    var listRowData = {};       
                    
                    if(person.totalServers > 0 && $scope.userMLI >= person.mgtLevelInd && !!person.mgtLevelInd){
                        listRowData.ProfileImg = 
                            $sce.trustAsHtml('<span class="default-user-pic"><img src='
                                             '+'getUserPhoto.webPhone(person.attId, 'large')
                                             +' height='30' width='30' alt=''></img></span>');
                        listRowData.owner = 
                            $sce.trustAsHtml("<a href='#/sublevel/"+person.attId
                                             +"' title='owner' class='anchorTag-color'> "
                                             +person.firstName+" "+person.lastName+"</a>");
                        listRowData.uid = person.attId;
                        listRowData.title = person.role;
                        listRowData.servers = person.totalServers;
                    }else{
                        listRowData.ProfileImg  = $sce.trustAsHtml("<span class='default-user-pic'><img src='"
                                                          +getUserPhoto.webPhone(person.attId, 'large')
                                                          +"' height='30' width='30' alt=''></img></span>");
                        listRowData.owner = person.firstName+' '+person.lastName;
                        listRowData.uid = person.attId;
                        listRowData.title = person.role;
                        listRowData.servers = person.totalServers;                                                
                    }
                   
                  rowData[i] = listRowData;
                }
                $scope.tableData.tbody = rowData;
                $scope.tableData.currentPage = $scope.currentPage;
			} else {
				$scope.count = 0;
			}
			
            $rootScope.loading = false;

		});
            
            
    };
		function split(data){
			if($.isArray(data.results)){
				return [ data.results.splice(0, 10), data.results ];
			} else {
				return false;
			}
		}


		$rootScope.updateBreadcrumbs = {
			search: {
				disableLink: true
			}
		};

		$scope.onPageChange = function(page){
		   	$scope.currentPage = page;
		    $scope.update();  
		};
        $scope.onPerPageChange = function(perPageSelected){
            $scope.perPageSelected = perPageSelected.name;
            $scope.currentPage = 1;
            $scope.update();
        };

		$scope.viewReport = function(){
           
		};

        $scope.update();
	}
]);
