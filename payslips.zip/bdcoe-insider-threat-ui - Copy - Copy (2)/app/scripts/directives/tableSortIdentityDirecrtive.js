'use strict';
angular.module('insiderApp')
    .directive('tableFilterCondition', ['$timeout', '$window', function($timeout, $window) {
        return {
            restrict: 'A',
            priority: 1,

            compile: function(element, attrs) {
                      console.log('compile element my-dirctive  is:',element);

                return {
                    pre: function(scope, element, attrs) {
                      console.log('scope in precompile of  my-dirctive is:',scope);
                      

                    },
                    post: function(scope, element, attrs) {
                      console.log('scope in postcompile of  my-dirctive is:',scope);
                        $timeout(function() {
                            console.log('inside timeout of the tableFilterCondition ');
                            var headerKeys = {
                                'allCasesPage': {
                                    'status': 'caseStatusType',
                                },
                                'alertDetailsPage': {
                                   // 'billingName': 'customerFirstNameOrBusinessName',
                                    'billingAddress': 'customerAddress1',
                                },
                                 'caseDetails': {},
                                 'Notes': {},
                                 'activityLogSort': {},
                                 'createNewCase': {},
                                 'allDispositionsTable': {
                                    'dispositionEnabledView': 'dispositionEnabled'
                                 },
                                 'allDispositionsLogTable': {}
                            };

                            var theadElement = angular.element(element[0].querySelectorAll('thead th'));
                            console.log('scope.tableData is:::::::', scope.tableData);
                            console.log('scope.csv is::', scope.csv);
                            console.log('theadElement  :::', theadElement);
                            console.log('attr is::::', attrs);
                            console.log('attrs.tableFilterCondition is::::', attrs.tableFilterCondition);
                            $window.$('thead th', element).addClass('sorting');
                            scope.orderReverse = false;
                            
                            var filterPage = attrs.tableFilterCondition;
                            theadElement.bind('click', function(e) {

                                console.log(' class name is:', e.currentTarget.classList);
                                var classList = e.currentTarget.classList;
                                var csvUrl='';
                                if(filterPage ==='Notes')
                                {
                                    csvUrl = scope.getCSVServiceLinkforNotes();
                                }
                                else if(filterPage ==='activityLogSort')
                                {
                                    csvUrl = scope.getCSVServiceLinkforActivityLog();                                    
                                }
                                else{
                                    if(!(filterPage == 'allDispositionsLogTable' || filterPage == 'allDispositionsTable'))
                                        csvUrl = scope.getCSVServiceLink();   
                                }
                               
                                                             
                               scope.orderReverse = classList.contains('desc');
                               console.log("orderReverse::::::::;",scope.orderReverse)
                                if (classList && (classList[0].indexOf('caseCheckBox') === -1 && classList[0].indexOf('row-number') === -1)) {
                                    var sortColumn = '';
                                    var sortDirection = '';
                                    if(classList.length == 2){
                                      
                                      sortDirection = 'DESC';
                                      scope.orderReverse = true;

                                    } else if(classList.length == 3){
                                       
                                        sortDirection = (classList[2].trim());
                                        //scope.orderReverse = classList[2].trim() === 'desc' ? true :false;
                                        scope.orderReverse = !scope.orderReverse;
                                        if (sortDirection === 'asc') {
                                            sortDirection = 'DESC';
                                        } else if (sortDirection === 'desc') {
                                            sortDirection = 'ASC';
                                        }
                                    }
                                    console.log('classList[0].substring(3):', classList[0].substring(3), ': uppercase :', angular.uppercase(classList[2]));
                                    
                                    
                                    console.log('classList[0].substring(3):', classList[0].substring(3), 'sort dirction from GUI:', classList[2], ' converted to :', sortDirection);
                                    console.log("filter Page isssssssssss",filterPage);
                                   /* if (filterPage) {
                                         console.log("*******************FilterPage True");
                                        sortColumn = headerKeys[filterPage][classList[0].substring(3)] ? headerKeys[filterPage][classList[0].substring(3)] : classList[0].substring(3);
                                    } else {*/
                                        console.log("****************FilterPage False");
                                        sortColumn = headerKeys[filterPage][classList[0].substring(3)] ? headerKeys[filterPage][classList[0].substring(3)] : classList[0].substring(3);
                                    //}
                                    var sortCondition = "&sort=" + sortColumn + "&sortDirection=" + sortDirection;
                                    csvUrl += sortCondition;                                      
                                    scope.csv = csvUrl;
                                   /* var ele = $('#downloadCSV');

                                    ele.attr('href', scope.csv);*/
                                    console.log('csv url is:', scope.csv);                              
                                    $window.$('thead th', element).removeClass('asc , desc');
                                    $window.$('thead i', element).removeClass('glyph-caret-up , glyph-caret-down');
                                   
                                    scope.orderReverse ? $window.$(e.currentTarget).addClass('desc') : $window.$(e.currentTarget).addClass('asc');
                                    scope.orderReverse ? $window.$('i', e.currentTarget).addClass('glyph-caret-down') : $window.$('i', e.currentTarget).addClass('glyph-caret-up');

                                      scope.sortField = sortColumn;
                                      scope.setCurrentPageWhenSorting(1, filterPage);                             

                                    scope.setSortConditions(sortColumn,sortDirection);
                                    scope.updateTableWithSorting(sortColumn,sortDirection,filterPage);
                              }

                            });
                        }, 5000);
                        
                    }
                }
            }

        }
    }]);