'use strict';
//TODO: Need to add in documention

angular.module('ui.hub.header', [])

.directive('dedHeader', ['$templateCache', '$log','$location', 'SessionService','searchCaseFactory','$rootScope',
	function ($templateCache, $log,$location, SessionService,searchCaseFactory,rootScope) {
		return {
			scope: {
				hubTitle: '=?',
				userName: '=?',
				homeLink: '=?',
				searchCallback: '&',
				hideSearch: '=?',
				lastUpdated: '=?',
				userPic: '=?',
				breadcrumbUpdates: '=?',
				breadcrumbHomeLink: '=?',
				breadcrumbHomeLinkText: '=?'
			},
            controller : 'insiderheaderCtrl' ,
			restrict:'EA',
			transclude: true,
            templateUrl: 'views/templates/header/ded-header.html',
			link: function(scope, element, attrs) {

				if(scope.userName || scope.userPic){
					$log.info('There is no need to pass userName or userPic unless you are wanting to override CSP hr cookie user name or tSpace\'s user image.');
				}

				scope.showUtilityBar = attrs.breadcrumbUpdates || attrs.lastUpdated ? true : false;
				scope.hideSearch = attrs.hideSearch === undefined ? true : false;
				scope.homeLink = scope.homeLink || '#/';
				scope.userName = scope.userName || SessionService.getUsername() || '';
				
				scope.userPic = scope.userPic || SessionService.getUserPhoto();
				scope.submitSearch = function(){
					if(this.searchValue){
						scope.searchCallback({
							value: this.searchValue || null 
						});
						scope.isShow = true;                        
						
					} else {
						$log.info('please enter a valid search term');
					}
				};

				
				scope.searchCase=function(){
                  
					if(this.searchValue){
						var searchVal=Number(this.searchValue)
                        
                        
                    
                        searchCaseFactory.getsearchcase(this.searchValue).then(function(data){
                          if(data.success==true)  {
							  rootScope.routedFromAllCases='yes';
                              $location.path('/caseDetails/'+searchVal);
                              
                          }else{
                              
                              $('#caseErrorDialog').modal('show');
                          }
                            
                        })
                        // $location.path('/caseDetails/'+searchVal);						
                          this.searchValue="";
						
						scope.searchCallback({
							
							value: this.searchValue || null 
						});
						scope.isShow = true;                        
						
					} else {
						$log.info('please enter a valid search term');
					}


				}
                scope.closePopup = function(){
                    scope.isShow = false;
                    document.getElementById('form-header-search').reset();
                    
                    scope.closebtn=false;
                };
				if(scope.showUtilityBar){
					angular.element('body').addClass('is-utility-bar');
				}
			}
		};
	}
]);
