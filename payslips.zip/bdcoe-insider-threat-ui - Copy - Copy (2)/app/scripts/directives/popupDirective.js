'use strict';


angular.module('insiderApp')

.directive('popupSavebtn', [
	function () {
		return {
			restrict:'A',
			
            link: function(scope,ele,attr,controller,transcludeFn){

				  ele.on('click', function(){
					 
				  });
				
			}
		};
	}
]);





