'use strict';


angular.module('insiderApp')

.directive('dateInput', ['componentService',
	function (componentService) {
		return {
			restrict:'A',
			
            link: function(scope,ele,attr,controller,transcludeFn){
			
				  ele.datepicker({

				  	 changeMonth: true,
               		 changeYear: true,
                	 yearRange: "1950:2020",
					  
					  onSelect : function(date){


					  	console.log("datae value issss::::::::::",date);

						  
						var dateSplit = date.split('/');
						  
						//  var dateVar = componentService.getMonth(dateSplit[0]) + ' ' + dateSplit[1]+', '+dateSplit[2];

						var dateVar=date;
						if(attr.objdata==='caseDetails'){
							scope[attr.objdata][attr.ngModel.split('.')[1]].name = dateVar;
						  // scope[attr.objdata][attr.ngModel.split('.')[1]].value =dateSplit[2]+ '' + dateSplit[0] + '' + dateSplit[1];  
						   scope[attr.objdata][attr.ngModel.split('.')[1]].value =dateSplit[2]+ '' + dateSplit[0] + '' + dateSplit[1];  
						   
							  
						}
						else {
								
							scope[attr.objdata][attr.ngModel.split('.')[1]].name = dateVar;
						   	scope[attr.objdata][attr.ngModel.split('.')[1]].value =dateSplit[2]+ '-' + dateSplit[0] + '-' + dateSplit[1] + ' 00:00:00';  
								  
					    }
					scope.$apply();
						  
			  }
					  
					  
				  });
				
				
				
				
				
			}
		};
	}
]);