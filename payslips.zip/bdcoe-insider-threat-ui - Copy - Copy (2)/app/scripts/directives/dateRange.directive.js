'use strict';
angular.module('insiderApp')
.directive('dateRange', ['componentService','$compile',
	function (componentService,$compile) {
		return {
			restrict:'A',
	      link: function(scope,ele,attr,controller,transcludeFn){
         
   		$.datepicker._defaults.onAfterUpdate = null;
         var datepicker__updateDatepicker = $.datepicker._updateDatepicker;
         $.datepicker._updateDatepicker = function( inst ) {
            datepicker__updateDatepicker.call( this, inst );
            var onAfterUpdate = this._get(inst, 'onAfterUpdate');
            if (onAfterUpdate)
            onAfterUpdate.apply((inst.input ? inst.input[0] : null),
               [(inst.input ? inst.input.val() : ''), inst]);

         }
         $(function() {
          
            var cur = -1, prv = -1;
             scope.showButton=true;
             
            $(ele.find('div')[0]).datepicker({
               changeMonth: true,
               changeYear: true,
               showButtonPanel: true,
            
               beforeShowDay: function ( date ) {
                     return [true, ( (date.getTime() >= Math.min(prv, cur) && date.getTime() <= Math.max(prv, cur)) ? 'date-range-selected' : '')];
                  },
            
               onSelect: function ( dateText, inst ) {
                  var d1, d2;
                  prv = cur;
                  scope[attr.objdata][attr.ngModel.split('.')[1]].name="";
                 
                  cur = (new Date(inst.selectedYear, inst.selectedMonth, inst.selectedDay)).getTime();
                  if ( prv == -1 || prv == cur ) {
                     prv = cur;
                     scope.showButton=true;
                     scope.$apply();
                     $(ele.find('input')[0]).val( dateText );
							var dateSplit = dateText.split('/');
				     		var dateVar=dateText;
				  
					      scope[attr.objdata][attr.ngModel.split('.')[1]].name = dateVar;
                      if(attr.objdata==='caseDetails' || attr.objdata==='newCase'){
                           scope[attr.objdata][attr.ngModel.split('.')[1]].value =dateSplit[2]+ '' + dateSplit[0] + '' + dateSplit[1] ;  
                      }else{
						   scope[attr.objdata][attr.ngModel.split('.')[1]].value =dateSplit[2]+ '-' + dateSplit[0] + '-' + dateSplit[1] ;  
                      }
						  /* scope.disabled=true;
*/
                  } else {
                      scope.showButton=false;
                      scope.$apply();

       
                     d1 = $.datepicker.formatDate( 'mm/dd/yy', new Date(Math.min(prv,cur)), {} );
                     d2 = $.datepicker.formatDate( 'mm/dd/yy', new Date(Math.max(prv,cur)), {} );
                     $(ele.find('input')[0]).val( d1+' - '+d2 );
					  				  
					      var dateSplit1 = d1.split('/');
						  	var dateVar1=d1;
   					   var dateSplit2 = d2.split('/');
   						var dateVar2=d2;
   					   
                     scope[attr.objdata][attr.ngModel.split('.')[1]].name = dateVar1;
                     scope[attr.objdata][attr.ngModel.split('.')[1]].name  =   scope[attr.objdata][attr.ngModel.split('.')[1]].name + '-' +  dateVar2;

                     if(attr.objdata==='allcase'){
                        scope[attr.objdata][attr.ngModel.split('.')[1]].value =dateSplit1[2]+ '-' + dateSplit1[0] + '-' + dateSplit1[1];  
                        scope[attr.objdata][attr.ngModel.split('.')[1]].value  =    scope[attr.objdata][attr.ngModel.split('.')[1]].value + '#' + dateSplit2[2]+ '-' + dateSplit2[0] + '-' + dateSplit2[1];  
                     }
                     else if(attr.objdata==='alertDetails')
                     {
                        scope[attr.objdata][attr.ngModel.split('.')[1]].value =dateSplit1[2]+ '-' + dateSplit1[0] + '-' + dateSplit1[1] ;  
                        scope[attr.objdata][attr.ngModel.split('.')[1]].value  =    scope[attr.objdata][attr.ngModel.split('.')[1]].value + '#' + dateSplit2[2]+ '-' + dateSplit2[0] + '-' + dateSplit2[1];  
                     }
                      else if(attr.objdata==='caseDetails')
                     {
                        scope[attr.objdata][attr.ngModel.split('.')[1]].value =dateSplit1[2]+''+dateSplit1[0]+''+dateSplit1[1];  
                        scope[attr.objdata][attr.ngModel.split('.')[1]].value  = scope[attr.objdata][attr.ngModel.split('.')[1]].value + '#' + dateSplit2[2]+ '' + dateSplit2[0] + '' + dateSplit2[1];  
                     }
                     else if(attr.objdata==='newCase')
                     {

                       scope[attr.objdata][attr.ngModel.split('.')[1]].value =dateSplit1[2]+''+dateSplit1[0]+''+dateSplit1[1];  
                       scope[attr.objdata][attr.ngModel.split('.')[1]].value  = scope[attr.objdata][attr.ngModel.split('.')[1]].value + '#' + dateSplit2[2]+ '' + dateSplit2[0] + '' + dateSplit2[1];  
                     
                     }
                    
                  }
               },
               
               onChangeMonthYear: function ( year, month, inst ) {
               },
               
               onAfterUpdate: function ( inst ) {
				      $(ele.find('div .ui-datepicker-buttonpane')[0]).empty();
                 /* $('<button type="button" class="btn btn-primary" data-handler="hide" data-event="click">Done</button>')
                  .appendTo($(ele.find('div .ui-datepicker-buttonpane')[0]))
                  */
                 var okButton =$compile('<button type="button" ng-disabled="showButton" class="btn btn-primary" data-handler="hide" data-event="click">Ok</button>');
                   var cancelButton = $compile('<button type="button" class="btn btn-default" data-handler="hide" data-event="click">Cancel</button>');
                $(ele.find('div .ui-datepicker-buttonpane')[0]).append(okButton(scope));
                 $(ele.find('div .ui-datepicker-buttonpane')[0]).append(cancelButton(scope));
                   
                   $(ele.find('div .ui-datepicker-buttonpane button')[0]).on('click', function () {  
                    $(ele.find('div')[0]).hide(); 
                });
               
                $(ele.find('div .ui-datepicker-buttonpane button')[1]).on('click', function () { 
                    scope[attr.objdata][attr.ngModel.split('.')[1]].name='';
                    scope[attr.objdata][attr.ngModel.split('.')[1]].value ='';
                    $(ele.find('input')[0]).val('');
                    $(ele.find('div')[0]).hide();
                });
               }
            })  
            .hide();
      
           /* $(ele.find('input')[0]).on('focus', function (e) {*/
              $(ele.find('input')[0]).on('focus keyup', function (e) {
               var v = this.value,d;
               try {
                   
                  if ( v.indexOf('-') > -1 ) {
                     d = v.split('-');
                     prv = $.datepicker.parseDate( 'mm/dd/yy', d[0] ).getTime();
                     cur = $.datepicker.parseDate( 'mm/dd/yy', d[1] ).getTime();
                  } else if ( v.length > 0 ) {
                     prv = cur = $.datepicker.parseDate( 'mm/dd/yy', v ).getTime();
                  }else{
                    cur = prv = -1;    
                  }
               } catch ( e ) {
                  cur = prv = -1;
               }
               if ( cur > -1 ){
                  $(ele.find('div')[0]).datepicker('setDate', new Date(cur));
               }else{
                   $(ele.find('div')[0]).datepicker('setDate', new Date());
               }
                  if(e.keyCode != 13){
                        $(ele.find('div')[0]).datepicker('refresh').show();
                  }
            });


         });
		}
	  };
   }
]);