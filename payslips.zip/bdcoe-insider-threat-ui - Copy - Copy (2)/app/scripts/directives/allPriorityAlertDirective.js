'use strict';
angular.module('insiderApp')
.directive("barChart", ['$window',function($window) {
   return{
      restrict:'EA',
      scope: {
      		chartDetails : '=',
                
          },
      template:"<svg id='visualisation' width='221' height='500'></svg>",
      link: function(scope, elem, attrs){
         
        var chartData1=scope.chartDetails;
       // console.log("chanert data iossss for",chartData1[0].misUseDate);
        var xRange, yRange, xAxis, yAxisGen, lineFun,area;
        var vis = d3.select('#visualisation');
        var  WIDTH = 500,
        HEIGHT = 430,
        MARGINS = {
            top: 20,
            right: 20,
            bottom: 20,
            left: 0
        },
        xRange = d3.scale.ordinal().rangeRoundBands([MARGINS.left, 220], 0.5).domain(chartData1.map(function (d) {
        var t1=d.misUseDay +" "+d.misUseDate;
        return t1;
        })),
    
        yRange = d3.scale.linear().range([HEIGHT - MARGINS.top, MARGINS.bottom]).domain([0,
        d3.max(chartData1, function (d) {
            return 100;
            })
        ]),

    xAxis = d3.svg.axis()
      .scale(xRange) ;
	
	vis.append('svg:g')
    .attr('class', 'x axis')
    .attr('transform', 'translate(0,' + (HEIGHT - MARGINS.bottom) + ')')
	 .call(xAxis)
	.selectAll('.tick text')
	 .call(wrap, xRange.rangeBand());

	
    vis.selectAll('rect')
    .data(chartData1)
    .enter()
    .append('rect')
    .attr('x', function (d) {
      return xRange(d.misUseDay+" "+d.misUseDate);
    })
    .attr('y', function (d) {
      return yRange(d.misUsePercentage)-10;
    })
    .attr('width', xRange.rangeBand()+7)
    .attr('height', function (d) {
      return (HEIGHT - MARGINS.bottom)-(yRange(d.misUsePercentage)-12);
    })
    .attr('fill', '#ec000a');
    
    
  
  	 vis.selectAll('.text')
      .data(chartData1)
      .enter().append('text')
	  .attr('x', function (d) {
            return xRange(d.misUseDay+" "+d.misUseDate)+6;
        })
      .attr('y', function (d) {
                return yRange(d.misUsePercentage);
        })
    .text(function(d) {
		var s=d.misUsePercentage+"%";
		 return s; })
		 .attr('dy', function (d) {
                if(d.misUsePercentage < 5 && d.misUsePercentage >1){
                return '9';
                    
                }else if(d.misUsePercentage == 0 || d.misUsePercentage == 1){
                    
                    return '3';
                }
                else{
                    
                    return '15';
                }
        })
        .attr('font-size', '18px')
		.attr('font-family', 'clvatt-bold')
		.attr('fill', '#ffffff')
     	.style('padding','5px')
    ;
	
	function wrap(text, width) {
  text.each(function() {
    var text = d3.select(this),
        words = text.text().split(/\s+/).reverse(),
        word,
        line = [],
        lineNumber = 0,
        lineHeight = 1.1, // ems
        y = text.attr('yRange'),
        dy = parseFloat(text.attr('dy')),
        tspan = text.text(null).append('tspan').attr('x', 0).attr('y', y).attr('dy', dy + 'em');
		var str="";
		
      while (word = words.pop()) {
       if(word == 'TODAY' || word == 'YESTERDAY'){
	   tspan = text.append('tspan').attr('x', 0).attr('y', 0)
       .attr('font-size', '16px')
       .attr('font-family', 'clvatt-bold')
       .attr("fill", "#666666")
       
     	.attr('dy', ++lineNumber * lineHeight + dy + 'em').text(word);
	   }
	  
	  else{
		line.push(word);
		str =str+" "+word;
		
		if(line.length ==3){
			tspan = text.append('tspan').attr('x', -3).attr('y', 10)		
            .attr('font-size', '13px')
		  .attr('font-family', 'clvatt-book')
		  .attr('fill', '#666666')	
            .attr('dy', ++lineNumber * lineHeight + dy + 'em').text(str);
		}
			  
	  }
    }  
      
  });
}
  

}
  
   
       }

}]);