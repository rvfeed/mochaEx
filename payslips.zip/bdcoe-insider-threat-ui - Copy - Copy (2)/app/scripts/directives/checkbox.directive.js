'use strict';


angular.module('insiderApp')

.directive('myCheckbox', [
	function () {
		return {
			restrict:'A',
            link: function(scope,ele,attr,controller,transcludeFn){
				
				
				ele.on('click',function(){
					
					
					if(scope.status){
						
						
						scope.allcase.statusType.push(attr.value);
						
					}
					else
						{
							scope.allcase.statusType.splice(scope.allcase.statusType.indexOf(attr.value),1);
							
						}
					
					
				});
				
				
				
				
			}
		};
	}
])
.directive('myCheckbox1', [
	function () {
		return {
			restrict:'A',
            link: function(scope,ele,attr,controller,transcludeFn){
				
				
				ele.on('click',function(){
					
					
					if(scope.status){
						
						
						scope.alertDetails.statusType.push(attr.value);
						
					}
					else
						{
							scope.alertDetails.statusType.splice(scope.alertDetails.statusType.indexOf(attr.value),1);
							
						}
					
					
				});
				
				
				
				
			}
		};
	}
])

.directive('myCheckbox2', [
	function () {
		return {
			restrict:'A',
            link: function(scope,ele,attr,controller,transcludeFn){
				
				
				ele.on('click',function(){
					
					
					if(scope.status2){
						
						
						scope.alertDetails.statusType2.push(attr.value);
						
					}
					else
						{
							scope.alertDetails.statusType2.splice(scope.alertDetails.statusType2.indexOf(attr.value),1);
							
						}
					
					
				});
				
				
				
				
			}
		};
	}
])

.directive('directiveLoad',['$rootScope','topSummaryFactory',function($rootScope,topSummaryFactory) {
		return {
			restrict:'A',
			priority : '-1000',
			
            link: function(scope,ele,attr,controller,transcludeFn){
				$('body').on('click',function(event){
				if($(event.target).hasClass('allCaseCheckbox')){
					if($(event.target).prop('checked')){
						scope.bulkCloseArrayDuplicate.push($(this).val());
					}
					else
					{
						scope.bulkCloseArrayDuplicate.pop();
					}
					
					if(scope.bulkCloseArrayDuplicate.length===0){
						
						$('#bulkCloseBtn').attr('disabled','disabled');
					}
					else
					{
						$('#bulkCloseBtn').removeAttr('disabled');
					}
							
				}else if($(event.target).hasClass('createCaseCheckBox')){
					if($(event.target).prop('checked')){
						scope.bulkCloseArrayDuplicate.push($(this).val());
					}
					else
					{
						scope.bulkCloseArrayDuplicate.pop();
					}
					
					if(scope.bulkCloseArrayDuplicate.length===0){
						
						$('#bulkCloseBtn').attr('disabled','disabled');
					}
					else
					{
						$('#bulkCloseBtn').removeAttr('disabled');
					}
							
				}
				
			scope.$apply();
		});
	
		}
	
		};
	}
])

.directive('casedetailsDirectiveload',['$rootScope','topSummaryFactory',function($rootScope,topSummaryFactory) {
		return {
			restrict:'A',
			priority : '-1000',
			
			
            link: function(scope,ele,attr,controller,transcludeFn){
            	var caseOwner=scope.$eval(attr.caseOwner);
				$('body').on('click',function(event){

				 if($(event.target).hasClass('caseDetailsCheckbox')){

					if($(event.target).prop('checked')){

				            scope.bulkCloseArrayDuplicate.push($(event.target).val());
					}
					else
					{
						scope.bulkCloseArrayDuplicate.pop();
					}
					
					if(scope.bulkCloseArrayDuplicate.length===0){
						$('#bulkCloseBtn').attr('disabled','disabled');
					}
					else
					{
						console.log("case owner*************",caseOwner);
						console.log("loggedAttId*************",$rootScope.loggedAttId);
						if($rootScope.loggedAttId === caseOwner)
						{
							$('#bulkCloseBtn').removeAttr('disabled');
						}else{
							$('#bulkCloseBtn').attr('disabled','disabled');
							topSummaryFactory.checkUserInUPM().then(function(data){
			             		if(data.upmCheck == "true" && ($('.caseDetailsCheckbox:checked').length !=0)){                                
			                         $('#bulkCloseBtn').removeAttr('disabled');
                                    
			               		}else{
                                    $('#bulkCloseBtn').attr('disabled','disabled');
                                }
			               	});
							
						}
						
					}
							
				}
			scope.$apply();
		});
	       
		}
	
		};
	}
]);
