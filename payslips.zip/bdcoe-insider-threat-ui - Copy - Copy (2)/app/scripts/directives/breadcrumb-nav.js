'use strict';
//TODO: Need to add in documention

angular.module('insiderApp')

.directive('breadcrumbNav', [
	function () {
		return {
			restrict:'E',
            templateUrl: 'views/templates/breadcrumbNav.html'
		};
	}
]);
