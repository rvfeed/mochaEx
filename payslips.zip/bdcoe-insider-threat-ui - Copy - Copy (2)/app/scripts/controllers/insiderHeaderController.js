 'use strict';

 angular.module('insiderApp')
.controller('insiderheaderCtrl', ['$scope','$rootScope','$http','$state','topSummaryFactory',
  function ($scope,$rootScope, $http,$state,topSummaryFactory) {

  	 topSummaryFactory.checkUserInUPM().then(function(data){
  		
  		if(data.upmCheck == "true")
  			$scope.isAdminUser=true;
  		else
  			$scope.isAdminUser=false;
  	});

      topSummaryFactory.getUserPermissions().then(function(data){
           $scope.permissions = data.componentPermissionMap;
            $scope.viewIncidentResponse = $scope.permissions.IT_INCIDENCE_RESPONSE.view;
            $scope.viewRules = $scope.permissions.IT_RULES.view;
            $scope.viewCases = $scope.permissions.IT_CASE_MGT.view;
            $scope.viewAdmin = $scope.permissions.IT_ADMIN.view;          
                           
        });

  
  }]);