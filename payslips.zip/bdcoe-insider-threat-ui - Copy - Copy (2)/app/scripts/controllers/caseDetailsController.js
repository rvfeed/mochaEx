'use strict';

angular.module('insiderApp')

.controller('caseDetailCtrl', ['$scope','$rootScope','$state','caseDetailFactory','$stateParams','getUserPhoto','getServiceURI','$sce','$filter','componentService','$compile','caseNotesFactory','dateTimeFactory','$window','$document','topSummaryFactory','$timeout','dispositionFactory','createNewCaseFactory', function($scope,$rootScope,$state,caseDetailFactory,$stateParams,getUserPhoto,getServiceURI,$sce,$filter,componentService,$compile, caseNotesFactory, dateTimeFactory,$window,$document,topSummaryFactory,$timeout,dispositionFactory, createNewCaseFactory){

// .controller('caseDetailCtrl', ['$scope','$rootScope','$state','caseDetailFactory','$stateParams','getUserPhoto','getServiceURI','$sce','$filter','componentService','$compile','caseNotesFactory','dateTimeFactory','$window','$document',function($scope,$rootScope,$state,caseDetailFactory,$stateParams,getUserPhoto,getServiceURI,$sce,$filter,componentService,$compile, caseNotesFactory, dateTimeFactory,$window,$document){

    $rootScope.loading = true;
    $rootScope.isAdmin = false;
    $rootScope.showMoreContent  = false;
    $scope.assigneeAdded = false;
    $scope.isShow = false;

    $scope.showme = false;

    $scope.bookmark = true;

    $rootScope.routedFromCaseDetails = "yes";

    $scope.showGraph = false;

    $scope.attID = ($stateParams.caseId===undefined)? localStorage.caseId : $stateParams.caseId;

    $scope.empDetailsData = {};

    $scope.probabilityscore = 0.1;

    $scope.bmFlag = "no" ;

    $scope.showForm = false;
   
    var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

   // $rootScope.bulkCloseArrayDuplicate=[];

    $scope.showTableHeader = true;

    $scope.hideRowNumbers  = false;

     $scope.telegenceId ="";

     $scope.closeInfoWindow = function(){

         $('.infowindow').attr('style','display:none')

     }

 

    $scope.tableData = {};

    $scope.selectCase={};

    $rootScope.alertDetailsFilterSelected = "no";
    $scope.getCSVServiceLink = function(){

 

      //var selectedDateOfAccess =($scope.caseDetails.selectedDateOfAccess.name==='')? '' :$scope.caseDetails.selectedDateOfAccess.value;

      //+'&startAccountDateEstablished='+accntEstDate[0]+'&endAccountDateEstablished='+accntEstDate[1]

       var selectedDateOfAccess=[];

        if($scope.caseDetails.selectedDateOfAccess.name.length){

            selectedDateOfAccess = dateTimeFactory.getDateRangesFromRawDates($scope.caseDetails.selectedDateOfAccess.name);

        }else{

            selectedDateOfAccess = dateTimeFactory.getDateRanges($scope.caseDetails.selectedDateOfAccess.value);

        }

         if($scope.caseDetails.selectedDateOfAccess.name.length == 0){

            selectedDateOfAccess = ["",""];

        }

          if(selectedDateOfAccess[0] !== "" &&(selectedDateOfAccess[1] === undefined ||selectedDateOfAccess[1] === "") )

        {

          selectedDateOfAccess[1]=selectedDateOfAccess[0];

        }

      

  

      var selectedAccountsAccessed = ($scope.caseDetails.selectedAccountsAccessed.name===undefined)? '' :($scope.caseDetails.selectedAccountsAccessed.name.search('Select')===-1)?$scope.caseDetails.selectedAccountsAccessed.name : '';

      var selectedNoOfCtns = ($scope.caseDetails.selectedNoOfCtns.name===undefined)? '' :($scope.caseDetails.selectedNoOfCtns.name.search('Select')===-1)?$scope.caseDetails.selectedNoOfCtns.name : '';

      var selectedAccountsNoted = ($scope.caseDetails.selectedAccountsNoted.name===undefined)? '' :($scope.caseDetails.selectedAccountsNoted.name.search('Select')===-1)?$scope.caseDetails.selectedAccountsNoted.name : '';

      var selectedPercentageNoted = ($scope.caseDetails.selectedPercentageNoted.name===undefined)? '' :($scope.caseDetails.selectedPercentageNoted.name.search('Select')===-1)?$scope.caseDetails.selectedPercentageNoted.name : '';

    

      /*var selectedFilterAlertDisp = ($scope.caseDetails.selectedFilterAlertDisp.name===undefined)? '' :($scope.caseDetails.selectedFilterAlertDisp.name.search('Select')===-1)?$scope.caseDetails.selectedFilterAlertDisp.value : ''; */

        var selectedFilterAlertDisp = $scope.caseDetails.selectedFilterAlertDisp.length == 0? '' :_.pluck($scope.caseDetails.selectedFilterAlertDisp, 'id');

                    var minProbability=($scope.caseDetails.alertMin=== null)?'':$scope.caseDetails.alertMin;

      var maxProbability=($scope.caseDetails.alertMax=== null)?'':$scope.caseDetails.alertMax;

     

      var minmumaverageOfBan=($scope.caseDetails.banMin=== null)?'':$scope.caseDetails.banMin;

      var maximumaverageOfBan=($scope.caseDetails.banMax=== null)?'':$scope.caseDetails.banMax;

      var minaverageOfCtns=($scope.caseDetails.ctnMin=== null)?'':$scope.caseDetails.ctnMin;

      var maxaverageOfCtns=($scope.caseDetails.ctnMax=== null)?'':$scope.caseDetails.ctnMax;

       

      var clarifyNoMemoCount=($scope.caseDetails.clarifyNoMemoCount=== null)?'':$scope.caseDetails.clarifyNoMemoCount;

      var telegenceNoMemoCount=($scope.caseDetails.telegenceNoMemoCount=== null)?'':$scope.caseDetails.telegenceNoMemoCount;

 

                                var alertIds = $("#selectedAlertsList").val();

        console.log("alertIds....."+alertIds)

        if(alertIds==undefined){

            alertIds="";

           

        }

 

      var link = getServiceURI.build('insiderThreat', 'exportCaseDetails')+ '/' +$rootScope.loggedAttId+'/'+  $scope.attID+'?alertId='+$scope.caseDetails.alertID+'&minimumProbability='+

      minProbability+'&maximumProbability='+maxProbability+'&fromDateOfAccess='+selectedDateOfAccess[0]+'&toDateOfAccess='+selectedDateOfAccess[1]+'&accountsAccessed='+selectedAccountsAccessed+'&accessedOfCtns='+selectedNoOfCtns+'&accountsNoted='+

      selectedAccountsNoted+'&percentageNoted='+selectedPercentageNoted+'&minimumAverageOfBan='+minmumaverageOfBan+'&maximumAverageOfBan='+maximumaverageOfBan+'&minimumAverageOfCTNs='+minaverageOfCtns+'&maximumAverageOfCTNs='+

      maxaverageOfCtns+'&status='+$scope.allcase.statusType+'&alertDisposition='+selectedFilterAlertDisp+'&mobility='+$scope.caseDetails.mobility+'&clarifyNoMemoCount='+clarifyNoMemoCount+'&telegenceNoMemoCount='+telegenceNoMemoCount+"&selectedAlerts="+alertIds;

 

     // console.log("****",link);

      return link;

    };

 

     $scope.getCSVServiceLinkforNotes = function(){

      // var selectedDateOfAccess =($scope.caseDetails.selectedDateOfAccess.name==='')? '' :$scope.caseDetails.selectedDateOfAccess.value;

       var selectedDateOfAccess=[];

       if($scope.caseDetails.selectedDateOfAccess.value.length == 0 && $scope.caseDetails.selectedDateOfAccess.name.length){

            selectedDateOfAccess = dateTimeFactory.getDateRangesFromRawDates($scope.caseDetails.selectedDateOfAccess.name);

        }else{

            selectedDateOfAccess = dateTimeFactory.getDateRanges($scope.caseDetails.selectedDateOfAccess.value);

        }

         if($scope.caseDetails.selectedDateOfAccess.name.length == 0){

            selectedDateOfAccess = ["",""];

        }

          if(selectedDateOfAccess[0] !== "" &&(selectedDateOfAccess[1] === undefined ||selectedDateOfAccess[1] === "") )

        {

          selectedDateOfAccess[1]=selectedDateOfAccess[0];

        }

 

      var selectedAccountsAccessed = ($scope.caseDetails.selectedAccountsAccessed.name===undefined)? '' :($scope.caseDetails.selectedAccountsAccessed.name.search('Select')===-1)?$scope.caseDetails.selectedAccountsAccessed.name : '';

      var selectedNoOfCtns = ($scope.caseDetails.selectedNoOfCtns.name===undefined)? '' :($scope.caseDetails.selectedNoOfCtns.name.search('Select')===-1)?$scope.caseDetails.selectedNoOfCtns.name : '';

      var selectedAccountsNoted = ($scope.caseDetails.selectedAccountsNoted.name===undefined)? '' :($scope.caseDetails.selectedAccountsNoted.name.search('Select')===-1)?$scope.caseDetails.selectedAccountsNoted.name : '';

      var selectedPercentageNoted = ($scope.caseDetails.selectedPercentageNoted.name===undefined)? '' :($scope.caseDetails.selectedPercentageNoted.name.search('Select')===-1)?$scope.caseDetails.selectedPercentageNoted.name : '';

      /*var selectedFilterAlertDisp = ($scope.caseDetails.selectedFilterAlertDisp.name===undefined)? '' :($scope.caseDetails.selectedFilterAlertDisp.name.search('Select')===-1)?$scope.caseDetails.selectedFilterAlertDisp.value : '';

                  var minProbability=($scope.caseDetails.alertMin=== null)?'':$scope.caseDetails.alertMin;*/

          var selectedFilterAlertDisp = $scope.caseDetails.selectedFilterAlertDisp.length == 0? '' :_.pluck($scope.caseDetails.selectedFilterAlertDisp, 'id');

                    var minProbability=($scope.caseDetails.alertMin=== null)?'':$scope.caseDetails.alertMin;

      var maxProbability=($scope.caseDetails.alertMax=== null)?'':$scope.caseDetails.alertMax;

     

      var minmumaverageOfBan=($scope.caseDetails.banMin=== null)?'':$scope.caseDetails.banMin;

      var maximumaverageOfBan=($scope.caseDetails.banMax=== null)?'':$scope.caseDetails.banMax;

      var minaverageOfCtns=($scope.caseDetails.ctnMin=== null)?'':$scope.caseDetails.ctnMin;

      var maxaverageOfCtns=($scope.caseDetails.ctnMax=== null)?'':$scope.caseDetails.ctnMax;

       

      var clarifyNoMemoCount=($scope.caseDetails.clarifyNoMemoCount=== null)?'':$scope.caseDetails.clarifyNoMemoCount;

      var telegenceNoMemoCount=($scope.caseDetails.telegenceNoMemoCount=== null)?'':$scope.caseDetails.telegenceNoMemoCount;

               

 

   

      var linkforNotes = getServiceURI.build('insiderThreat', 'exportNotesDetails')+ '/' +$rootScope.loggedAttId+'/'+  $scope.attID+'?alertId='+$scope.caseDetails.alertID+'&minimumProbability='+

      minProbability+'&maximumProbability='+maxProbability+'&fromDateOfAccess='+selectedDateOfAccess[0]+'&toDateOfAccess='+selectedDateOfAccess[1]+'&accountsAccessed='+selectedAccountsAccessed+'&accessedOfCtns='+selectedNoOfCtns+'&accountsNoted='+

      selectedAccountsNoted+'&percentageNoted='+selectedPercentageNoted+'&minimumAverageOfBan='+minmumaverageOfBan+'&maximumAverageOfBan='+maximumaverageOfBan+'&minimumAverageOfCTNs='+minaverageOfCtns+'&maximumAverageOfCTNs='+

      maxaverageOfCtns+'&status='+$scope.allcase.statusType+'&alertDisposition='+selectedFilterAlertDisp+'&mobility='+$scope.caseDetails.mobility+'&clarifyNoMemoCount='+clarifyNoMemoCount+'&telegenceNoMemoCount='+telegenceNoMemoCount;

 

     // console.log("notesssssssssss",linkforNotes);

      return linkforNotes;

    };

 

    $scope.getCSVServiceLinkforActivityLog = function(){

      // var selectedDateOfAccess =($scope.caseDetails.selectedDateOfAccess.name==='')? '' :$scope.caseDetails.selectedDateOfAccess.value;

       var selectedDateOfAccess=[];

       if($scope.caseDetails.selectedDateOfAccess.value.length == 0 && $scope.caseDetails.selectedDateOfAccess.name.length){

            selectedDateOfAccess = dateTimeFactory.getDateRangesFromRawDates($scope.caseDetails.selectedDateOfAccess.name);

        }else{

            selectedDateOfAccess = dateTimeFactory.getDateRanges($scope.caseDetails.selectedDateOfAccess.value);

        }

         if($scope.caseDetails.selectedDateOfAccess.name.length == 0){

            selectedDateOfAccess = ["",""];

        }

          if(selectedDateOfAccess[0] !== "" &&(selectedDateOfAccess[1] === undefined ||selectedDateOfAccess[1] === "") )

        {

          selectedDateOfAccess[1]=selectedDateOfAccess[0];

        }

 

      var selectedAccountsAccessed = ($scope.caseDetails.selectedAccountsAccessed.name===undefined)? '' :($scope.caseDetails.selectedAccountsAccessed.name.search('Select')===-1)?$scope.caseDetails.selectedAccountsAccessed.name : '';

      var selectedNoOfCtns = ($scope.caseDetails.selectedNoOfCtns.name===undefined)? '' :($scope.caseDetails.selectedNoOfCtns.name.search('Select')===-1)?$scope.caseDetails.selectedNoOfCtns.name : '';

      var selectedAccountsNoted = ($scope.caseDetails.selectedAccountsNoted.name===undefined)? '' :($scope.caseDetails.selectedAccountsNoted.name.search('Select')===-1)?$scope.caseDetails.selectedAccountsNoted.name : '';

      var selectedPercentageNoted = ($scope.caseDetails.selectedPercentageNoted.name===undefined)? '' :($scope.caseDetails.selectedPercentageNoted.name.search('Select')===-1)?$scope.caseDetails.selectedPercentageNoted.name : '';

      /*var selectedFilterAlertDisp = ($scope.caseDetails.selectedFilterAlertDisp.name===undefined)? '' :($scope.caseDetails.selectedFilterAlertDisp.name.search('Select')===-1)?$scope.caseDetails.selectedFilterAlertDisp.value : ''; */

         var selectedFilterAlertDisp = $scope.caseDetails.selectedFilterAlertDisp.length == 0? '' :_.pluck($scope.caseDetails.selectedFilterAlertDisp, 'id');

      var minProbability=($scope.caseDetails.alertMin=== null)?'':$scope.caseDetails.alertMin;

      var maxProbability=($scope.caseDetails.alertMax=== null)?'':$scope.caseDetails.alertMax;

     

      var minmumaverageOfBan=($scope.caseDetails.banMin=== null)?'':$scope.caseDetails.banMin;

      var maximumaverageOfBan=($scope.caseDetails.banMax=== null)?'':$scope.caseDetails.banMax;

      var minaverageOfCtns=($scope.caseDetails.ctnMin=== null)?'':$scope.caseDetails.ctnMin;

      var maxaverageOfCtns=($scope.caseDetails.ctnMax=== null)?'':$scope.caseDetails.ctnMax;

       

      var clarifyNoMemoCount=($scope.caseDetails.clarifyNoMemoCount=== null)?'':$scope.caseDetails.clarifyNoMemoCount;

      var telegenceNoMemoCount=($scope.caseDetails.telegenceNoMemoCount=== null)?'':$scope.caseDetails.telegenceNoMemoCount;

 

 

   

      var linkforNotes = getServiceURI.build('insiderThreat', 'exportActivityLog')+ '/' +$rootScope.loggedAttId+'/'+  $scope.attID+'?alertId='+$scope.caseDetails.alertID+'&minimumProbability='+

      minProbability+'&maximumProbability='+maxProbability+'&fromDateOfAccess='+selectedDateOfAccess[0]+'&toDateOfAccess='+selectedDateOfAccess[1]+'&accountsAccessed='+selectedAccountsAccessed+'&accessedOfCtns='+selectedNoOfCtns+'&accountsNoted='+

      selectedAccountsNoted+'&percentageNoted='+selectedPercentageNoted+'&minimumAverageOfBan='+minmumaverageOfBan+'&maximumAverageOfBan='+maximumaverageOfBan+'&minimumAverageOfCTNs='+minaverageOfCtns+'&maximumAverageOfCTNs='+

      maxaverageOfCtns+'&status='+$scope.allcase.statusType+'&alertDisposition='+selectedFilterAlertDisp+'&mobility='+$scope.caseDetails.mobility+'&clarifyNoMemoCount='+clarifyNoMemoCount+'&telegenceNoMemoCount='+telegenceNoMemoCount;

 

     // console.log("notesssssssssss",linkforNotes);

      return linkforNotes;

    };

 

 $(document).ready(function(){
     $("#myModal2").draggable({
              handle: ".modal-header"
        });
 });

   $scope.bulkCloseArrayDuplicate=[];

   $('#bulkCloseBtn').attr('disabled','disabled');

    $scope.allcase = {

 

    };

  $scope.allcase.statusType = [];

 

  $scope.caseDetails = {

   

    'alertID' : '',

    'alertMin' : '',

    'alertMax' : '',

    'selectedDateOfAccess' :{

     

      'name' : '',

      'value' : ''

     

    },

    'selectedAccountsAccessed' : '',

    'selectedNoOfCtns' : '',

    'selectedAccountsNoted' : '',

    'selectedPercentageNoted' : '',

    'banMin' : '',

    'banMax' : '',

    'ctnMin' : '',

    'ctnMax' : '',

    'selectedFilterAlertDisp': [],

    'mobility':'',

    'clarifyNoMemoCount':'',

    'telegenceNoMemoCount':''

   

    

  },

   

  $scope.statusArray = [];

  var params = {

    "alertId":"",

    "minProbability":"",

    "maxProbability":"",

    //

    "fromDateOfAccess":"",

    "toDateOfAccess":"",

    //"dateOfAccess":"",

    "acctsAccessed":"",

    "ctnsAccessed":"",

    "acctsNotedBySuspect":"",

    "percentageNotedBySuspect":"",

    "minmumaverageOfBan":"",

    "maximumaverageOfBan":"",

    "minaverageOfCtns":"",

    "maxaverageOfCtns":"",

    "accountStatusList":[],

   "alertDispositionTypes":_.pluck($scope.caseDetails.selectedFilterAlertDisp, 'id'),

    "mobility":"",

    "clarifyNoMemoCount":"",

    "telegenceNoMemoCount":""

    };

$scope.updateCaseDetailsParams = function(){
     var dateOfAccess=[];

   

    if($scope.caseDetails.selectedDateOfAccess.name.length){

            dateOfAccess = dateTimeFactory.getDateRangesFromRawDates($scope.caseDetails.selectedDateOfAccess.name);

        }else{

            dateOfAccess = dateTimeFactory.getDateRanges($scope.caseDetails.selectedDateOfAccess.value);

        }

         if($scope.caseDetails.selectedDateOfAccess.name.length == 0 ){

            dateOfAccess = ["",""];

        }

        if(dateOfAccess[0] !== "" &&(dateOfAccess[1] === undefined ||dateOfAccess[1] === "") )

        {

          dateOfAccess[1]=dateOfAccess[0];

        }
    $rootScope.caseDetailsFromFilters = [];
//        if($rootScope.caseDetailsFilterSelected !== "yes"){
//            $rootScope.caseDetailsFromFilters = [];
//        }
//  
    
//    var params = {     
//
//      "alertId":$scope.caseDetails.alertID,
//
//      "minProbability":($scope.caseDetails.alertMin=== null)?'':$scope.caseDetails.alertMin,
//
//      "maxProbability":($scope.caseDetails.alertMax=== null)?'':$scope.caseDetails.alertMax,
//
//     // "dateOfAccess":($scope.caseDetails.selectedDateOfAccess.name==='')? '' :$scope.caseDetails.selectedDateOfAccess.value,
//
//      "fromDateOfAccess":dateOfAccess[0],
//
//      "toDateOfAccess":dateOfAccess[1],
//
// 
//
//      "acctsAccessed":($scope.caseDetails.selectedAccountsAccessed.name===undefined)? '' :($scope.caseDetails.selectedAccountsAccessed.name.search('Select')===-1)?$scope.caseDetails.selectedAccountsAccessed.name : '',
//
//      "ctnsAccessed":($scope.caseDetails.selectedNoOfCtns.name===undefined)? '' :($scope.caseDetails.selectedNoOfCtns.name.search('Select')===-1)?$scope.caseDetails.selectedNoOfCtns.name : '',
//
//      "acctsNotedBySuspect":($scope.caseDetails.selectedAccountsNoted.name===undefined)? '' :($scope.caseDetails.selectedAccountsNoted.name.search('Select')===-1)?$scope.caseDetails.selectedAccountsNoted.name : '',
//
//      "percentageNotedBySuspect":($scope.caseDetails.selectedPercentageNoted.name===undefined)? '' :($scope.caseDetails.selectedPercentageNoted.name.search('Select')===-1)?$scope.caseDetails.selectedPercentageNoted.name : '',
//
//      "minmumaverageOfBan":($scope.caseDetails.banMin=== null)?'':$scope.caseDetails.banMin,
//
//      "maximumaverageOfBan":($scope.caseDetails.banMax=== null)?'':$scope.caseDetails.banMax,
//
//      "minaverageOfCtns":($scope.caseDetails.ctnMin=== null)?'':$scope.caseDetails.ctnMin,
//
//      "maxaverageOfCtns":($scope.caseDetails.ctnMax=== null)?'':$scope.caseDetails.ctnMax,
//
//      "accountStatusList":$scope.allcase.statusType,
//
//      /*"alertDispositionTypes": ($scope.caseDetails.selectedFilterAlertDisp.name===undefined)? '' :($scope.caseDetails.selectedFilterAlertDisp.name.search('Select')===-1)?$scope.caseDetails.selectedFilterAlertDisp.value : '',*/
//
//        "alertDispositionTypes": _.pluck($scope.caseDetails.selectedFilterAlertDisp , 'id'),
//
//      "mobility":$scope.caseDetails.mobility,
//
//      "clarifyNoMemoCount":($scope.caseDetails.clarifyNoMemoCount=== null)?'':$scope.caseDetails.clarifyNoMemoCount,
//
//      "telegenceNoMemoCount":($scope.caseDetails.telegenceNoMemoCount=== null)?'':$scope.caseDetails.telegenceNoMemoCount
//
// 
//
// 
//
//    };
    var params = {     

      "alertId":($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].alertId :$scope.caseDetails.alertID,
      "minProbability":($scope.caseDetails.alertMin=== null)?'':($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].minProbability : $scope.caseDetails.alertMin,
	  "maxProbability":($scope.caseDetails.alertMax=== null)?'':($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].maxProbability : $scope.caseDetails.alertMax,

     

      "fromDateOfAccess":($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].fromDateOfAccess : dateOfAccess[0],

      "toDateOfAccess":($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].toDateOfAccess : dateOfAccess[1],

 
//      "acctsAccessed":($scope.caseDetails.selectedAccountsAccessed.name===undefined)? '' :($scope.caseDetails.selectedAccountsAccessed.name.search('Select')===-1)?$scope.caseDetails.selectedAccountsAccessed.name : '',
//
//      "ctnsAccessed":($scope.caseDetails.selectedNoOfCtns.name===undefined)? '' :($scope.caseDetails.selectedNoOfCtns.name.search('Select')===-1)?$scope.caseDetails.selectedNoOfCtns.name : '',
//
//      "acctsNotedBySuspect":($scope.caseDetails.selectedAccountsNoted.name===undefined)? '' :($scope.caseDetails.selectedAccountsNoted.name.search('Select')===-1)?$scope.caseDetails.selectedAccountsNoted.name : '',
//
//      "percentageNotedBySuspect":($scope.caseDetails.selectedPercentageNoted.name===undefined)? '' :($scope.caseDetails.selectedPercentageNoted.name.search('Select')===-1)?$scope.caseDetails.selectedPercentageNoted.name : '',
        
       "acctsAccessed":($scope.caseDetails.selectedAccountsAccessed.name===undefined)? '' :($scope.caseDetails.selectedAccountsAccessed.name.search('Select')===-1)? (($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].acctsAccessed : $scope.caseDetails.selectedAccountsAccessed.name) : '',

      "ctnsAccessed":($scope.caseDetails.selectedNoOfCtns.name===undefined)? '' :($scope.caseDetails.selectedNoOfCtns.name.search('Select')===-1)?(($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].ctnsAccessed : $scope.caseDetails.selectedNoOfCtns.name) : '',

      "acctsNotedBySuspect":($scope.caseDetails.selectedAccountsNoted.name===undefined)? '' :($scope.caseDetails.selectedAccountsNoted.name.search('Select')===-1)?(($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].acctsNotedBySuspect :$scope.caseDetails.selectedAccountsNoted.name) : '',

      "percentageNotedBySuspect":($scope.caseDetails.selectedPercentageNoted.name===undefined)? '' :($scope.caseDetails.selectedPercentageNoted.name.search('Select')===-1)?(($rootScope.caseDetailsFromFilters.length !== 0)?  $rootScope.caseDetailsFromFilters[0].percentageNotedBySuspect : $scope.caseDetails.selectedPercentageNoted.name) : '',

      "minmumaverageOfBan":($scope.caseDetails.banMin=== null)?'':($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].minmumaverageOfBan : $scope.caseDetails.banMin,

      "maximumaverageOfBan":($scope.caseDetails.banMax=== null)?'':($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].maximumaverageOfBan : $scope.caseDetails.banMax,

      "minaverageOfCtns":($scope.caseDetails.ctnMin=== null)?'':($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].minaverageOfCtns : $scope.caseDetails.ctnMin,

      "maxaverageOfCtns":($scope.caseDetails.ctnMax=== null)?'':($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].maxaverageOfCtns : $scope.caseDetails.ctnMax,

      "accountStatusList":($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].accountStatusList : $scope.allcase.statusType,
   
      "alertDispositionTypes": ($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].alertDispositionTypes : _.pluck($scope.caseDetails.selectedFilterAlertDisp , 'id'),

      "mobility":($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].mobility :$scope.caseDetails.mobility,

      "clarifyNoMemoCount":($scope.caseDetails.clarifyNoMemoCount=== null)?'':($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].clarifyNoMemoCount : $scope.caseDetails.clarifyNoMemoCount,

      "telegenceNoMemoCount":($scope.caseDetails.telegenceNoMemoCount=== null)?'':($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].telegenceNoMemoCount : $scope.caseDetails.telegenceNoMemoCount

    };
    console.log(params)
    $scope.fromDateOfAccess = dateOfAccess[0];
	$scope.toDateOfAccess = dateOfAccess[1];
	
	$rootScope.caseDetailsFromFilters.push(
		{ 'alertId' : $scope.caseDetails.alertID,
		  'minProbability' : $scope.caseDetails.alertMin,
          'maxProbability' : $scope.caseDetails.alertMax,
          'fromDateOfAccess' : dateOfAccess[0],
          'toDateOfAccess' : dateOfAccess[1],
          'acctsAccessed' : ($scope.caseDetails.selectedAccountsAccessed.name===undefined)? '' :($scope.caseDetails.selectedAccountsAccessed.name.search('Select')===-1)?$scope.caseDetails.selectedAccountsAccessed.name : '',
          'ctnsAccessed' : ($scope.caseDetails.selectedNoOfCtns.name===undefined)? '' :($scope.caseDetails.selectedNoOfCtns.name.search('Select')===-1)?$scope.caseDetails.selectedNoOfCtns.name : '',
          'acctsNotedBySuspect' : ($scope.caseDetails.selectedAccountsNoted.name===undefined)? '' :($scope.caseDetails.selectedAccountsNoted.name.search('Select')===-1)?$scope.caseDetails.selectedAccountsNoted.name : '',
          'percentageNotedBySuspect' : ($scope.caseDetails.selectedPercentageNoted.name===undefined)? '' :($scope.caseDetails.selectedPercentageNoted.name.search('Select')===-1)?$scope.caseDetails.selectedPercentageNoted.name : '',
          'minmumaverageOfBan' : ($scope.caseDetails.banMin=== null)?'':$scope.caseDetails.banMin,
          'maximumaverageOfBan' : ($scope.caseDetails.banMax=== null)?'':$scope.caseDetails.banMax,
          'minaverageOfCtns' : ($scope.caseDetails.ctnMin=== null)?'':$scope.caseDetails.ctnMin,
          'maxaverageOfCtns' : ($scope.caseDetails.ctnMin=== null)?'':$scope.caseDetails.ctnMax,
          'accountStatusList' : $scope.allcase.statusType,
          'alertDispositionTypes' : _.pluck($scope.caseDetails.selectedFilterAlertDisp , 'id'),
          'mobility' : $scope.caseDetails.mobility,
          'clarifyNoMemoCount' : ($scope.caseDetails.clarifyNoMemoCount=== null)?'':$scope.caseDetails.clarifyNoMemoCount,
          'telegenceNoMemoCount' : ($scope.caseDetails.telegenceNoMemoCount=== null)?'':$scope.caseDetails.telegenceNoMemoCount
		});
    console.log($rootScope.caseDetailsFromFilters)

    return params;
}; 

 

 

  $scope.invokeUpdateAllCases = function(){

       

        $scope.currentPage = 1;

        $scope.rowsPerPage = 25;

        $scope.itemsPerPage = $scope.itemsPerPageOptions[0];

              

        $scope.updateAllCases();

  }

 

  //filter data

 

 

 

  $scope.updateAllCases = function(){

   // $(".caseDetailsCheckbox")..prop('checked', false);         

    $("#selectedAlertsList").val("");

    $(".hasDatepicker").hide();

    $scope.changeView('caseDetails'); 

    $scope.currentPage = 1;

    $scope.rowsPerPage = 25;

    $rootScope.loading = true;
    
   var params = $scope.updateCaseDetailsParams();
 

    $rootScope.caseDetailsFilterSelected = "yes";

  caseDetailFactory.getCaseDetailData($scope.attID,params,$scope.currentPage-1,$scope.rowsPerPage).then(function(data){
    $scope.alertsDataLength=0;

    $scope.csv = $scope.getCSVServiceLink();

    $scope.caseDetailsData = data;

    var caseDetailsTableData = data.dataList;
    if($scope.caseDetailsData.location){

      $scope.street = $scope.caseDetailsData.location.address;

    }

    var city='',state='',country='';

    if($scope.caseDetailsData.location){

       city = $scope.caseDetailsData.location.city;

    } if($scope.caseDetailsData.location){

     state = $scope.caseDetailsData.location.state;

    }if($scope.caseDetailsData.location){

      country = $scope.caseDetailsData.location.country;

    }

    $scope.location=city+' '+state+' '+country;
    if(data.dataList){

      $scope.eventsListLength=caseDetailsTableData.length;

      $scope.alertsDataLength=caseDetailsTableData.length;

    } else {

      $scope.eventsListLength=0;

      $scope.alertsDataLength=0;

    }

     $scope.prepareAlertsTableData(data);

    

      $scope.showForm = true;

      if(data.dataList){

       $scope.alertsDataLength=caseDetailsTableData.length;

      }else{   

          $scope.alertsDataLength = 0;   

      }

      $(".rows-per-page label").text("Results per page");

       

      $scope.bulkCloseArrayDuplicate=[];

      $('#bulkCloseBtn').attr('disabled','disabled');
                                                   

      });

  };

   

 

 

    $scope.mouseenter=function(){

          this.bookmarkHoveShow = true;

    };

    $scope.mouseleave=function(){

      this.bookmarkHoveShow = false;

    };

      

    if($rootScope.loggedUserName == undefined){

        $rootScope.loggedUserName='PRASOONA GOLI';

    }

 

    $scope.loggedFirstName=$rootScope.loggedUserName.split(' ')[0];

    $scope.loggedLastName =$rootScope.loggedUserName.split(' ')[1];

 

    $scope.statusChange=function(statusValue){
            if($scope.caseStatus == "New"){
                if($("#statusOptions .dropdown-menu li:nth-child(1) a").html() == "New"){
                    $("#statusOptions .dropdown-menu li:nth-child(1)").remove();
                }
            }
      if($scope.investigatorId == '' || $scope.investigatorId == null || $scope.investigatorId == 'null')

      {

        $scope.caseOwnerSelectedOption.name =$scope.loggedFirstName + ' ' + $scope.loggedLastName;
        $scope.caseOwnerPosition=false;
        if(statusValue.name !=='Closed')

        {

           $('#addColorToDisp').removeClass('customRequired');

           $scope.caseDispositonPosition=true;

          caseDetailFactory.changeCaseStatus(statusValue.name,$scope.attID,'caseStatusType',$rootScope.loggedAttId).then(function(data){
            $scope.lastUpdatedDate = dateTimeFactory.changeToLocalTimeFromDate(data.lastUpdateDateTime);     
         });
          $scope.caseOwnerPosition=false;

        }

        else if(statusValue.name ==='Closed')

        {
          $scope.caseDispositonPosition=false;

          $scope.caseOwnerPosition=true;

          $('#addColorToDisp').addClass('customRequired');

        }

      }

     else if($scope.investigatorId  === $rootScope.loggedAttId)

      {

         if(statusValue.name !=='Closed')

        {

           $scope.caseDispositonPosition=true;
            if($rootScope.isAdmin){
            $scope.caseOwnerPosition=false;
            }
            caseDetailFactory.changeCaseStatus(statusValue.name,$scope.attID,'caseStatusType',$scope.caseOwnerSelectedOption.value).then(function(data){

 

             $scope.lastUpdatedDate = dateTimeFactory.changeToLocalTimeFromDate(data.lastUpdateDateTime);

            $state.reload();

 

          });

       }

         else if(statusValue.name ==='Closed')

        {

          if( $scope.caseDispositionSelectedOption.value === 'Select upon case Closure')

          {

            $('#addColorToDisp').addClass('customRequired');

 

          }else{

           // console.log("disposition not empty");

            caseDetailFactory.changeCaseStatus(statusValue.name,$scope.attID,'caseStatusType',$rootScope.loggedAttId).then(function(data){

 

             $scope.lastUpdatedDate = dateTimeFactory.changeToLocalTimeFromDate(data.lastUpdateDateTime);

            $state.reload();

 

          });

 

          }

           $scope.caseDispositonPosition=false;
            if($rootScope.isAdmin){
            $scope.caseOwnerPosition=false;
            }
        }

 

       

      }

      else {

 

       

          $scope.caseOwnerSelectedOption.name =$scope.loggedFirstName + ' ' + $scope.loggedLastName;

       

          if(statusValue.name !=='Closed')

          {

             $scope.caseDispositonPosition=true;
              if($rootScope.isAdmin){
              $scope.caseOwnerPosition=false;
              }
              caseDetailFactory.changeCaseStatus(statusValue.name,$scope.attID,'caseStatusType',$rootScope.loggedAttId).then(function(data){

 

                 $scope.lastUpdatedDate = dateTimeFactory.changeToLocalTimeFromDate(data.lastUpdateDateTime);

                   $state.reload();

 

            });

            

          }

         else if(statusValue.name ==='Closed')

        {

 

          if( $scope.caseDispositionSelectedOption.value === 'Select upon case Closure')

          {

            $('#addColorToDisp').addClass('customRequired');

          }else{

           // console.log("disposition not empty");

            caseDetailFactory.changeCaseStatus(statusValue.name,$scope.attID,'caseStatusType',$rootScope.loggedAttId).then(function(data){

 

             $scope.lastUpdatedDate = dateTimeFactory.changeToLocalTimeFromDate(data.lastUpdateDateTime);

            $state.reload();

 

          });

 

          }

           $scope.caseDispositonPosition=false;
            if($rootScope.isAdmin){
            $scope.caseOwnerPosition=false;
            }
        }

 

      }

   

    };

 

  

    $scope.closeCasePopupClose = function(){

      $scope.closeCasePopup = false;  

      $state.reload();

  

    }

    $scope.closeCasePopupOpen = function(){

      $scope.closeCasePopup = true;

      $state.reload();

 

    }   

 

      $scope.closeDispPopupClose = function(){

      $scope.closeDispositionPopup = false;  

      

   

    }

   

 

     $scope.filterAlertDisp = [ ];
     $scope.CaseDispositionOptions = [
      { name:'Select upon case Closure',value:'Select upon case Closure'}
     ];
    $scope.caseDispositionSelectedOption = $scope.CaseDispositionOptions[0];  
    $scope.bulkCloseCaseDispOptions = [

     { name:'Select upon alert Closure',value:'Select upon alert Closure'},

    

    ];
    $scope.selectCase.bulkcloseCaseDispSelectedOption = $scope.bulkCloseCaseDispOptions[0];
   
    dispositionFactory.getAllDisposition().then(function(data){
        $.each(data.dispositionTypeList,function(i,v)
        {
            var dorpdown ={}
            dorpdown.name = data.dispositionTypeList[i].dispositionName;
            dorpdown.value = data.dispositionTypeList[i].dispositionName;
            $scope.filterAlertDisp.push(dorpdown);
            dorpdown.disabled = data.dispositionTypeList[i].dispositionEnabled ? false : true; 
            $scope.CaseDispositionOptions.push(dorpdown);
            $scope.bulkCloseCaseDispOptions.push(dorpdown);
        });
             
        $scope.selectedFilterAlertDisp = $scope.filterAlertDisp[0];
        
        $scope.$watch('caseDispositionSelectedOption', function(newValue){});
        $scope.$watch('selectedFilterAlertDisp', function(newValue){});
        $scope.$watch('selectCase.bulkcloseCaseDispSelectedOption', function(newValue){});
    });

   

    
    $scope.dispositionChange=function(dispositionValue){
        if(dispositionValue.value === "Select upon case Closure"){
            return;
        }
       caseDetailFactory.changeCaseStatus(dispositionValue.value,$scope.attID,'caseDisposition',$rootScope.loggedAttId).then(function(data){

 

          if(data.alertvalue === 'false')

          {

             $scope.closeCasePopup = true;

            

             return false;

          }

           $state.reload();

           $('#addColorToDisp').removeClass('customRequired');

          $scope.CaseStatusPosition=false;

          $scope.caseDispositonPosition=false;
           if($rootScope.isAdmin){
          $scope.caseOwnerPosition=false;
           }
 

         $scope.lastUpdatedDate = dateTimeFactory.changeToLocalTimeFromDate(data.lastUpdateDateTime);
         });

 

   

     }

    

 

    $scope.caseOwnsers = [

      {name: 'Select'}

    ];

     $scope.caseOwnerSelectedOption = $scope.caseOwnsers[0];

     $scope.OwnerChange=function(caseOwnerValue){

     // console.log("caseOwnerValue ID isss::::::",caseOwnerValue.value);

        if( caseOwnerValue.value !== undefined){

          caseDetailFactory.changeCaseStatus(caseOwnerValue.value,$scope.attID,'manager',$rootScope.loggedAttId).then(function(data){

            $scope.lastUpdatedDate = dateTimeFactory.changeToLocalTimeFromDate(data.lastUpdateDateTime);

        });

        $state.reload();

      }

    }

 

 

   $scope.caseOwnersArray=[];

 

  $scope.currentPage = 1;

  $scope.rowsPerPage = 25;

  //$scope.tableData = {};

  $scope.tableData.headers = {

    'caseId' : '',

    'id' : 'ALERT ID',

    'anomalyProbability' : 'ALERT PROBABILITY',

    'date' : 'DATE OF ACCESS',

    'alertStatusType' : 'STATUS',

    'alertDisposition': 'DISPOSITION',

    'accountsAccessed' : 'ACCOUNTS ACCESSED',

    'countOfCTNAccessed' : '# OF CTNS ACCESSED',

    'accountsNotedBySuspectId' : 'ACCOUNTS NOTED BY SUSPECT',

    'percentageNotedBySuspectId' : 'PERCENTAGE NOTED BY SUSPECT',

    'averageNumberOfBAN' : 'AVERAGE # OF BAN',

    'averageNumberOfCTN' : 'AVERAGE # OF CTNS',

    'mobility' : 'MOBILITY',

    'clarifyNoMemoCount' : 'CLARIFY NO MEMO COUNT',

    'telegenceNoMemoCount' : 'TELEGENCE NO MEMO COUNT'

 

  };

 

            //Added below to fields related to sort

    $scope.sortField = "";

    $scope.sortDirec = "";

 

    $scope.setSortConditions = function(sortField,sortDirection){

     // console.log('setting the sort conditions in allCasesController to :',sortField,'::',sortDirection);

      $scope.sortField = sortField;

      $scope.sortDirec = sortDirection;

 

    }

 

    $scope.setCurrentPageWhenSorting = function(pageNumber){
        $window.appendAlertIds();

      //console.log('setting current page to bcoz unequla sorting columns',pageNumber);

      $scope.currentPage =pageNumber;

    }

      $scope.onPageChange = function(page){

      //$scope.currentPage = page;

      $scope.currentPageActivity = page;

      $scope.loadActivityDataWithPagination();

    }

     $scope.getRowCount = function(i){

            var total = $scope.rowsPerPageActivity,

            currentPage = $scope.currentPage;

            i += currentPage > 1 ? (currentPage * total) - total + 1 : 1;

            i = i>$scope.totalRows?$scope.totalRows:i;

            return i;

    };

 

    $scope.onRowsPerPageChange = function (page) {

      //alert('1232424'+ page);

        $scope.currentPageActivity =1;

       

        $scope.rowsPerPageActivity = page.name;

        console.log("$scope.rowsPerPageActivity***********",$scope.rowsPerPageActivity);

        if($scope.rowsPerPageActivity == 40){

          $scope.tableOptionsActivity = [{ name:"10"},{ name:"40" , selected: true },{ name:"60" }]; 

        }

        if($scope.rowsPerPageActivity == 60){

          $scope.tableOptionsActivity = [{ name:"10"},{ name:"40"},{ name:"60"  , selected: true}]; 

        }

        if($scope.rowsPerPageActivity == 10){

          $scope.tableOptionsActivity = [{ name:"10", selected: true},{ name:"40" },{ name:"60" }]; 

        }      

        $scope.loadActivityData();

 

      }

 

   

      $scope.CaseStatusOptions = [];  

 

      $scope.$watch('caseStatusSelectedOption', function(newValue){

         });

   

    $scope.init = function(){
        
        if($rootScope.caseDetailsFilterSelected==="yes"){
            $scope.caseDetailsFilterData();
            $scope.updateAllCases();
        }
            
     topSummaryFactory.checkBasicUserInUPM().then(function(data){

        if(data.upmCheck == "false")

        {

            $state.go('error',{'id':""});

        }

        });
topSummaryFactory.checkUserInUPM().then(function(data){
    if(data.upmCheck == "true"){
        $rootScope.isAdmin = true;
    }else{
        $rootScope.isAdmin = false;
    }
});
topSummaryFactory.getUserPermissions().then(function(data){
           $scope.permissions = data.componentPermissionMap;
            if(!$scope.permissions.IT_CASE_MGT.view){
                $state.go('error',{'id':""});
            }
            $scope.userCanEdit = $scope.permissions.IT_CASE_MGT.edit;
            $scope.userCanAdd = $scope.permissions.IT_CASE_MGT.add;
});
   
    console.log("Assigning the case------???"+$rootScope.routedFromMycasesHomePage);
    if($rootScope.routedFromAllCases === 'no' && $rootScope.routedFromMycasesHomePage =='no'){

        caseDetailFactory.autoAssignCase($scope.attID).then(function(data){

  

     });

    }

  

            
 var params = $scope.updateCaseDetailsParams();
    caseDetailFactory.getCaseOwners().then(function(caseOwnersData){ 

   

      for(var i=0;i<caseOwnersData.caseManagerList.length;i++){

        $scope.caseOwnersArray.push({'name':caseOwnersData.caseManagerList[i].name,'value':caseOwnersData.caseManagerList[i].attUserId}) ;

      }

      for( var j=0;j<$scope.caseOwnersArray.length;j++){

        $scope.caseOwnsers.push({name:$scope.caseOwnersArray[j].name,

          value:$scope.caseOwnersArray[j].value });

      };

             

      caseDetailFactory.getCaseDetailData($scope.attID,params,$scope.currentPage-1,$scope.rowsPerPage).then(function(data){

 
        
        //$rootScope.loading = false;

         $scope.CaseStatusOptions.push(

              { name:'New' }, 

              { name:'Open'},

              { name:'Referred' },

              { name:'Recycled', disabled: true },

              { name:'InProgress' },

              { name:'Closed' }

            );

  
           $scope.caseIdNotNull=true;
        if($stateParams.caseId === "null" || $stateParams.caseId === null)

        {

          
            $scope.caseIdNotNull=false;
          $scope.CaseStatusPosition=true;

          $scope.caseDispositonPosition=true;

          $scope.caseOwnerPosition=true;

           $scope.caseStatusSelectedOption = $scope.CaseStatusOptions[0];

        }

        else if($stateParams.alertId != undefined){
            var suspectId = $stateParams.alertId.split("_")[0];
                 createNewCaseFactory.checkalertId(suspectId, $stateParams.alertId).then(function(data){
                     $rootScope.loading = false;
                     
                     if(data.status=="true"){
                       $scope.caseIdNotNull=true;

                     } else{

                      $scope.caseIdNotNull=false;
                     }                                       
                    console.log("data.status..."+data.status)                                         
                     
                     
             });
        }else{
           $scope.caseIdNotNull=true;
        }
          if($scope.caseIdNotNull){
      caseDetailFactory.activitylogVisited($scope.attID).then(function(data){

 

        console.log('visited Status: ' + data.status);

 

      });
          }

    
        var _dateOfAccess= [],_accountsAccessed = [],_noOfCtns = [],_accountsNoted = [],_percentageNoted = [];

      

        $scope.caseDetailsData = data;

        var caseDetailsTableData = data.dataList;

            

          if($scope.caseDetailsData.location){

            $scope.street = $scope.caseDetailsData.location.address;

          }

          var city='',state='',country='';

          if($scope.caseDetailsData.location){

             city = $scope.caseDetailsData.location.city;

          } if($scope.caseDetailsData.location){

             state = $scope.caseDetailsData.location.state;

          }if($scope.caseDetailsData.location){

             country = $scope.caseDetailsData.location.country;

          }

          $scope.location=city+' '+state+' '+country;

          if(data.dataList){

            $scope.eventsListLength=caseDetailsTableData.length;

            $scope.alertsDataLength=caseDetailsTableData.length;

          } else {

            $scope.eventsListLength=0;

            $scope.alertsDataLength=0;

          }

          $scope.csv = $scope.getCSVServiceLink();

                   

         var caseDetailsUpdatedDate=data.lastUpdateDateTime;

         var lastUpdateDateandTime='';

         if(caseDetailsUpdatedDate === null || caseDetailsUpdatedDate === 'null' || caseDetailsUpdatedDate === ''){

            lastUpdateDateandTime=data.createdDateTime;

         } else {

          lastUpdateDateandTime=data.lastUpdateDateTime;

         }

 

        $scope.lastUpdatedDate = dateTimeFactory.changeToLocalTimeFromDate(lastUpdateDateandTime);

         

        var caseStatus= data.caseStatusType ? data.caseStatusType.name : "";
          $scope.caseStatus = caseStatus;
        var caseDispositionValue=data.caseDisposition;

        

          $scope.caseDisposition='';

          if(caseDispositionValue === null || caseDispositionValue === 'null' || caseDispositionValue === '' )

          {

            $scope.caseDispositionSelectedOption = $scope.CaseDispositionOptions[0];

 

          }

          else{

              $scope.caseDisposition=data.caseDisposition;

 

          }

     

          $scope.investigatorId=data.investigatorId;

           var investigatorId=data.investigatorId;

          

 

            for(var i=0;i<$scope.caseOwnsers.length;i++){

 

              var caseOwnerAttId=$scope.caseOwnsers[i].value;

              if(caseOwnerAttId === investigatorId)

              {

              

                $scope.caseOwnerSelectedOption=$scope.caseOwnsers[i];

                 break;

              }

           }

           for(var i=0;i<$scope.CaseDispositionOptions.length;i++){

 

              var caseDispositionValue=$scope.CaseDispositionOptions[i].value;

              if(caseDispositionValue === $scope.caseDisposition)

              {

              

                 $scope.caseDispositionSelectedOption = $scope.CaseDispositionOptions[i];

                //$scope.caseOwnerSelectedOption=caseDispositionValue;

                 break;

              }

           }

      

          for(var i=0; i < $scope.CaseStatusOptions.length; i++ ){

              if($scope.CaseStatusOptions[i].name === caseStatus){

                $scope.caseStatusSelectedOption = $scope.CaseStatusOptions[i];

                break;

              };

          };

         

          if(investigatorId == '' || investigatorId == null || investigatorId == 'null')

          {

            //console.log("this is unassigned case::::::::::",investigatorId);

           // $scope.caseStatusSelectedOption.name =caseStatus;

 

            $scope.CaseStatusPosition=false;

            $scope.caseDispositonPosition=true;

            $scope.caseOwnerPosition=true;

 

          }else if(investigatorId === $rootScope.loggedAttId)

          {

            //console.log("this is assigned case::::::::::",investigatorId);

            

            

            $scope.CaseStatusPosition=false;

            $scope.caseDispositonPosition=true;
              if($rootScope.isAdmin){
            $scope.caseOwnerPosition=false;
              }
        

          }else {

           // console.log("this is assigned to diif usercase::::::::::",investigatorId);

          //  $scope.caseStatusSelectedOption.name =caseStatus;

            topSummaryFactory.checkUserInUPM().then(function(data){
                $rootScope.isAdmin = true;
              if(data.upmCheck == "true"){

                $scope.CaseStatusPosition=false;
                if(caseStatus === 'Closed') {      
                    $scope.caseDispositonPosition=false;
                }else{
                    $scope.caseDispositonPosition=true;
                }
                $scope.caseOwnerPosition=false;

              }

              else{
                $rootScope.isAdmin = false;  
 

                $scope.CaseStatusPosition=true;

                $scope.caseDispositonPosition=true;

                //$scope.caseOwnerPosition=true;

              }

            });

          }

          if(caseStatus === 'Closed')

          {

             $scope.CaseStatusPosition=false;

            $scope.caseDispositonPosition=false;

            $scope.caseOwnerPosition=false;

 

          }

         

       

         
     

      //drop down data

      

      //dateOfAccess

      _dateOfAccess=componentService.getUniqueArray(_dateOfAccess);

    $scope.dateOfAccess =  [

      { name:'Select' }

    ];

 

    $.each(_dateOfAccess,function(i,v){

      $scope.dateOfAccess.push({

        name:v

      });

    });

     

      //accountsAccessed

     

        _accountsAccessed=componentService.getUniqueArray(_accountsAccessed);

    $scope.accountsAccessed =  [

      { name:'Select' }

    ];

 

    $.each(_accountsAccessed,function(i,v){

      $scope.accountsAccessed.push({

        name:v

      });

    });

     

      //noOfCtns

       _noOfCtns=componentService.getUniqueArray(_noOfCtns);

    $scope.noOfCtns =  [

      { name:'Select' }

    ];

 

    $.each(_noOfCtns,function(i,v){

      $scope.noOfCtns.push({

        name:v

      });

    });

     

      //accountsNoted

     

       _accountsNoted=componentService.getUniqueArray(_accountsNoted);

    $scope.accountsNoted =  [

      { name:'Select' }

    ];

 

    $.each(_accountsNoted,function(i,v){

      $scope.accountsNoted.push({

        name:v

      });

    });

     

      //percentageNoted

           _percentageNoted=componentService.getUniqueArray(_percentageNoted);

    $scope.percentageNoted =  [

      { name:'Select' }

    ];

 

    $.each(_percentageNoted,function(i,v){

      $scope.percentageNoted.push({

        name:v

      });

    });

     

      

      $scope.statusArray = ['New','Open','Referred','Recycled','InProgress','Closed'];

      $scope.showForm = true;

      $scope.alertsDataLength=caseDetailsTableData ? caseDetailsTableData.length : 0;

      $(".rows-per-page label").text("Results per page");

      $scope.bulkCloseArrayDuplicate=[];

      $('#bulkCloseBtn').attr('disabled','disabled');   

             

      if($rootScope.routedFromAllCases==='yes')

        {

          $rootScope.route = [

            {

                "url" : "home",

                "name" : "Home"

            },

              {

                "url" : "allCases",

                "name" : "All Cases"                                          

            },

            {

                "url" : "caseDetails({'caseId' : '"+$stateParams.caseId+"'})",

                "name" : "Case Detail"                                          

            }

            ];

         

          }else if($rootScope.routedFromAllAlerts === 'yes'){
           $rootScope.route = [
            {
                "url" : "home",
                "name" : "Home"
            },{
                "url" : "alerts",
                "name" : "All Alerts" 
            },{
                "url" : "caseDetails",
                "name" : "Case Detail"  
            }
          
            ];
    }
          

      else{

       $rootScope.route = [

            {

                "url" : "home",

                "name" : "Home"

            },

               {

                "url" : "caseDetails({'caseId' : '"+$stateParams.caseId+"'})",

                "name" : "Case Detail"                                          

            }

            ];

      }

           

 
           $scope.prepareAlertsTableData(data);
                                                                 

          });

       

         $timeout(function() {
          $("input.disableRow").parents("tr.ng-scope").find("td").css("background","#f2f2f2");
          if($scope.caseStatus != "New"){
            $("#statusOptions .dropdown-menu li:nth-child(1)").remove(); 
            
          }
             if($scope.permissions.IT_CASE_MGT.edit){
         if($rootScope.isAdmin){
             if($scope.caseStatus != "New"){
                $scope.caseOwnerPosition=false;
             }else{
                $scope.caseOwnerPosition=true;    
             }
                 
         }else if( $scope.investigatorId == $rootScope.loggedAttId){
             $scope.caseOwnerPosition=false;
         }else{
             
             $scope.caseOwnerPosition=true;
         }
             }else{
                 $scope.caseOwnerPosition=true;
                 $scope.CaseStatusPosition=true;
                 $scope.caseDispositonPosition=true ;
             }
         $.each($scope.allcase.statusType,function(i,v){
                $("#sts"+v).prop('checked', true);
            });
             $.each($scope.caseDetails.selectedFilterAlertDisp,function(i,v){
            $("a:contains('"+v+"') span").addClass("glyphicon glyphicon-ok");
           });
             $rootScope.loading = false;
         },1000);

         });

 

}
//$scope.updateCaseDetailsParams = function(){
//     var dateOfAccess=[];
//
//   
//
//    if($scope.caseDetails.selectedDateOfAccess.name.length){
//
//            dateOfAccess = dateTimeFactory.getDateRangesFromRawDates($scope.caseDetails.selectedDateOfAccess.name);
//
//        }else{
//
//            dateOfAccess = dateTimeFactory.getDateRanges($scope.caseDetails.selectedDateOfAccess.value);
//
//        }
//
//         if($scope.caseDetails.selectedDateOfAccess.name.length == 0 ){
//
//            dateOfAccess = ["",""];
//
//        }
//
//        if(dateOfAccess[0] !== "" &&(dateOfAccess[1] === undefined ||dateOfAccess[1] === "") )
//
//        {
//
//          dateOfAccess[1]=dateOfAccess[0];
//
//        }
////        if($rootScope.caseDetailsFilterSelected !== "yes"){
////            $rootScope.caseDetailsFromFilters = [];
////        }
////  
//    
////    var params = {     
////
////      "alertId":$scope.caseDetails.alertID,
////
////      "minProbability":($scope.caseDetails.alertMin=== null)?'':$scope.caseDetails.alertMin,
////
////      "maxProbability":($scope.caseDetails.alertMax=== null)?'':$scope.caseDetails.alertMax,
////
////     // "dateOfAccess":($scope.caseDetails.selectedDateOfAccess.name==='')? '' :$scope.caseDetails.selectedDateOfAccess.value,
////
////      "fromDateOfAccess":dateOfAccess[0],
////
////      "toDateOfAccess":dateOfAccess[1],
////
//// 
////
////      "acctsAccessed":($scope.caseDetails.selectedAccountsAccessed.name===undefined)? '' :($scope.caseDetails.selectedAccountsAccessed.name.search('Select')===-1)?$scope.caseDetails.selectedAccountsAccessed.name : '',
////
////      "ctnsAccessed":($scope.caseDetails.selectedNoOfCtns.name===undefined)? '' :($scope.caseDetails.selectedNoOfCtns.name.search('Select')===-1)?$scope.caseDetails.selectedNoOfCtns.name : '',
////
////      "acctsNotedBySuspect":($scope.caseDetails.selectedAccountsNoted.name===undefined)? '' :($scope.caseDetails.selectedAccountsNoted.name.search('Select')===-1)?$scope.caseDetails.selectedAccountsNoted.name : '',
////
////      "percentageNotedBySuspect":($scope.caseDetails.selectedPercentageNoted.name===undefined)? '' :($scope.caseDetails.selectedPercentageNoted.name.search('Select')===-1)?$scope.caseDetails.selectedPercentageNoted.name : '',
////
////      "minmumaverageOfBan":($scope.caseDetails.banMin=== null)?'':$scope.caseDetails.banMin,
////
////      "maximumaverageOfBan":($scope.caseDetails.banMax=== null)?'':$scope.caseDetails.banMax,
////
////      "minaverageOfCtns":($scope.caseDetails.ctnMin=== null)?'':$scope.caseDetails.ctnMin,
////
////      "maxaverageOfCtns":($scope.caseDetails.ctnMax=== null)?'':$scope.caseDetails.ctnMax,
////
////      "accountStatusList":$scope.allcase.statusType,
////
////      /*"alertDispositionTypes": ($scope.caseDetails.selectedFilterAlertDisp.name===undefined)? '' :($scope.caseDetails.selectedFilterAlertDisp.name.search('Select')===-1)?$scope.caseDetails.selectedFilterAlertDisp.value : '',*/
////
////        "alertDispositionTypes": _.pluck($scope.caseDetails.selectedFilterAlertDisp , 'id'),
////
////      "mobility":$scope.caseDetails.mobility,
////
////      "clarifyNoMemoCount":($scope.caseDetails.clarifyNoMemoCount=== null)?'':$scope.caseDetails.clarifyNoMemoCount,
////
////      "telegenceNoMemoCount":($scope.caseDetails.telegenceNoMemoCount=== null)?'':$scope.caseDetails.telegenceNoMemoCount
////
//// 
////
//// 
////
////    };
//    var params = {     
//
//      "alertId":($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].alertId :$scope.caseDetails.alertID,
//      "minProbability":($scope.caseDetails.alertMin=== null)?'':($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].minProbability : $scope.caseDetails.alertMin,
//	  "maxProbability":($scope.caseDetails.alertMax=== null)?'':($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].maxProbability : $scope.caseDetails.alertMax,
//
//     
//
//      "fromDateOfAccess":($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].fromDateOfAccess : dateOfAccess[0],
//
//      "toDateOfAccess":($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].toDateOfAccess : dateOfAccess[1],
//
// 
////      "acctsAccessed":($scope.caseDetails.selectedAccountsAccessed.name===undefined)? '' :($scope.caseDetails.selectedAccountsAccessed.name.search('Select')===-1)?$scope.caseDetails.selectedAccountsAccessed.name : '',
////
////      "ctnsAccessed":($scope.caseDetails.selectedNoOfCtns.name===undefined)? '' :($scope.caseDetails.selectedNoOfCtns.name.search('Select')===-1)?$scope.caseDetails.selectedNoOfCtns.name : '',
////
////      "acctsNotedBySuspect":($scope.caseDetails.selectedAccountsNoted.name===undefined)? '' :($scope.caseDetails.selectedAccountsNoted.name.search('Select')===-1)?$scope.caseDetails.selectedAccountsNoted.name : '',
////
////      "percentageNotedBySuspect":($scope.caseDetails.selectedPercentageNoted.name===undefined)? '' :($scope.caseDetails.selectedPercentageNoted.name.search('Select')===-1)?$scope.caseDetails.selectedPercentageNoted.name : '',
//        
//       "acctsAccessed":($scope.caseDetails.selectedAccountsAccessed.name===undefined)? '' :($scope.caseDetails.selectedAccountsAccessed.name.search('Select')===-1)? (($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].acctsAccessed : $scope.caseDetails.selectedAccountsAccessed.name) : '',
//
//      "ctnsAccessed":($scope.caseDetails.selectedNoOfCtns.name===undefined)? '' :($scope.caseDetails.selectedNoOfCtns.name.search('Select')===-1)?(($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].ctnsAccessed : $scope.caseDetails.selectedNoOfCtns.name) : '',
//
//      "acctsNotedBySuspect":($scope.caseDetails.selectedAccountsNoted.name===undefined)? '' :($scope.caseDetails.selectedAccountsNoted.name.search('Select')===-1)?(($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].acctsNotedBySuspect :$scope.caseDetails.selectedAccountsNoted.name) : '',
//
//      "percentageNotedBySuspect":($scope.caseDetails.selectedPercentageNoted.name===undefined)? '' :($scope.caseDetails.selectedPercentageNoted.name.search('Select')===-1)?(($rootScope.caseDetailsFromFilters.length !== 0)?  $rootScope.caseDetailsFromFilters[0].percentageNotedBySuspect : $scope.caseDetails.selectedPercentageNoted.name) : '',
//
//      "minmumaverageOfBan":($scope.caseDetails.banMin=== null)?'':($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].minmumaverageOfBan : $scope.caseDetails.banMin,
//
//      "maximumaverageOfBan":($scope.caseDetails.banMax=== null)?'':($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].maximumaverageOfBan : $scope.caseDetails.banMax,
//
//      "minaverageOfCtns":($scope.caseDetails.ctnMin=== null)?'':($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].minaverageOfCtns : $scope.caseDetails.ctnMin,
//
//      "maxaverageOfCtns":($scope.caseDetails.ctnMax=== null)?'':($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].maxaverageOfCtns : $scope.caseDetails.ctnMax,
//
//      "accountStatusList":($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].accountStatusList : $scope.allcase.statusType,
//   
//      "alertDispositionTypes": ($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].alertDispositionTypes : _.pluck($scope.caseDetails.selectedFilterAlertDisp , 'id'),
//
//      "mobility":($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].mobility :$scope.caseDetails.mobility,
//
//      "clarifyNoMemoCount":($scope.caseDetails.clarifyNoMemoCount=== null)?'':($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].clarifyNoMemoCount : $scope.caseDetails.clarifyNoMemoCount,
//
//      "telegenceNoMemoCount":($scope.caseDetails.telegenceNoMemoCount=== null)?'':($rootScope.caseDetailsFromFilters.length !== 0)? $rootScope.caseDetailsFromFilters[0].telegenceNoMemoCount : $scope.caseDetails.telegenceNoMemoCount
//
//    };
//    $scope.fromDateOfAccess = dateOfAccess[0];
//	$scope.toDateOfAccess = dateOfAccess[1];
//	$rootScope.caseDetailsFromFilters = [];
//	$rootScope.caseDetailsFromFilters.push(
//		{ 'alertId' : $scope.caseDetails.alertID,
//		  'minProbability' : $scope.caseDetails.alertMin,
//          'maxProbability' : $scope.caseDetails.alertMax,
//          'fromDateOfAccess' : dateOfAccess[0],
//          'toDateOfAccess' : dateOfAccess[1],
//          'acctsAccessed' : ($scope.caseDetails.selectedAccountsAccessed.name===undefined)? '' :($scope.caseDetails.selectedAccountsAccessed.name.search('Select')===-1)?$scope.caseDetails.selectedAccountsAccessed.name : '',
//          'ctnsAccessed' : ($scope.caseDetails.selectedNoOfCtns.name===undefined)? '' :($scope.caseDetails.selectedNoOfCtns.name.search('Select')===-1)?$scope.caseDetails.selectedNoOfCtns.name : '',
//          'acctsNotedBySuspect' : ($scope.caseDetails.selectedAccountsNoted.name===undefined)? '' :($scope.caseDetails.selectedAccountsNoted.name.search('Select')===-1)?$scope.caseDetails.selectedAccountsNoted.name : '',
//          'percentageNotedBySuspect' : ($scope.caseDetails.selectedPercentageNoted.name===undefined)? '' :($scope.caseDetails.selectedPercentageNoted.name.search('Select')===-1)?$scope.caseDetails.selectedPercentageNoted.name : '',
//          'minmumaverageOfBan' : ($scope.caseDetails.banMin=== null)?'':$scope.caseDetails.banMin,
//          'maximumaverageOfBan' : ($scope.caseDetails.banMax=== null)?'':$scope.caseDetails.banMax,
//          'minaverageOfCtns' : ($scope.caseDetails.ctnMin=== null)?'':$scope.caseDetails.ctnMin,
//          'maxaverageOfCtns' : ($scope.caseDetails.ctnMin=== null)?'':$scope.caseDetails.ctnMax,
//          'accountStatusList' : $scope.allcase.statusType,
//          'alertDispositionTypes' : _.pluck($scope.caseDetails.selectedFilterAlertDisp , 'id'),
//          'mobility' : $scope.caseDetails.mobility,
//          'clarifyNoMemoCount' : ($scope.caseDetails.clarifyNoMemoCount=== null)?'':$scope.caseDetails.clarifyNoMemoCount,
//          'telegenceNoMemoCount' : ($scope.caseDetails.telegenceNoMemoCount=== null)?'':$scope.caseDetails.telegenceNoMemoCount
//		});
//
//    return params;
//};
 
 $scope.caseDetailsFilterData = function(){
     $scope.caseDetails.alertID = $rootScope.caseDetailsFromFilters[0].alertId;
     $scope.caseDetails.alertMin = $rootScope.caseDetailsFromFilters[0].minProbability;
     $scope.caseDetails.alertMax = $rootScope.caseDetailsFromFilters[0].maxProbability;
     $scope.fromDateOfAccess = $rootScope.caseDetailsFromFilters[0].fromDateOfAccess;
     $scope.toDateOfAccess = $rootScope.caseDetailsFromFilters[0].toDateOfAccess;
     $scope.caseDetails.selectedAccountsAccessed= $rootScope.caseDetailsFromFilters[0].acctsAccessed;
     $scope.caseDetails.selectedNoOfCtns = $rootScope.caseDetailsFromFilters[0].ctnsAccessed;
     $scope.caseDetails.selectedAccountsNoted= $rootScope.caseDetailsFromFilters[0].acctsNotedBySuspect;
     $scope.caseDetails.selectedPercentageNoted = $rootScope.caseDetailsFromFilters[0].percentageNotedBySuspect;
     $scope.caseDetails.banMin = $rootScope.caseDetailsFromFilters[0].minmumaverageOfBan;
     $scope.caseDetails.banMax = $rootScope.caseDetailsFromFilters[0].maximumaverageOfBan;
     $scope.caseDetails.ctnMin = $rootScope.caseDetailsFromFilters[0].minaverageOfCtns;
     $scope.caseDetails.ctnMax = $rootScope.caseDetailsFromFilters[0].maxaverageOfCtns;
     $scope.allcase.statusType = $rootScope.caseDetailsFromFilters[0].accountStatusList;
     //$scope.caseDetails.selectedFilterAlertDisp = $rootScope.caseDetailsFromFilters[0].alertDispositionTypes;
     $scope.caseDetails.mobility = $rootScope.caseDetailsFromFilters[0].mobility;
     $scope.caseDetails.clarifyNoMemoCount = $rootScope.caseDetailsFromFilters[0].clarifyNoMemoCount;
     $scope.caseDetails.telegenceNoMemoCount = $rootScope.caseDetailsFromFilters[0].telegenceNoMemoCount;
     var date1 = $scope.fromDateOfAccess ? $scope.fromDateOfAccess.substring(4,6)+'/'+$scope.fromDateOfAccess.substring(6,8)+'/'+$scope.fromDateOfAccess.substring(0,4) : "";
     var date2 = $scope.toDateOfAccess ? $scope.toDateOfAccess.substring(4,6)+'/'+$scope.toDateOfAccess.substring(6,8)+'/'+$scope.toDateOfAccess.substring(0,4) : "";
     $scope.caseDetails.selectedDateOfAccess.name = $scope.fromDateOfAccess ? date1 +"-"+ date2 : "";
     $.each($rootScope.caseDetailsFromFilters[0].alertDispositionTypes,function(i,v){
            $scope.caseDetails.selectedFilterAlertDisp.push({id:v});
    });
     
 }
   

     $scope.caseDispSettings = {

      displayProp: 'name',

      idProp: 'value',

      scrollableHeight: '200px',

      scrollable: true,

      showCheckAll : true,

      showUncheckAll : true,

      enableSearch : true,
     
      smartButtonMaxItems : 5

    }

    $scope.caseDispCustomText = {buttonDefaultText: 'Select upon case Closure'};
    $scope.caseDetailSettings = {
      displayProp: 'name', 
      idProp: 'name', 
      scrollableHeight: '200px',
      scrollable: true,
      showCheckAll : true,
      showUncheckAll : true,
      enableSearch : true,
      smartButtonMaxItems : 5
    }
    $scope.caseDetailCustomText = {buttonDefaultText: 'Select'};
 

    $scope.bulkClose = function(){

      //  alert("remove Employee");

      $scope.bulkCloseArray = [];

 

      for(var i=0;i<$scope.eventsListLength;i++){

        if($('#caseCheckbox'+i).prop('checked')){

          $scope.bulkCloseArray.push($('#caseCheckbox'+i).val());

        }

      };

 

      if($scope.selectCase.bulkcloseCaseDispSelectedOption.value === "Select upon alert Closure"){

        $scope.closeDispositionPopup = true;  

        return false;

      };

 

      caseDetailFactory.bulkCloseCaseInfo($scope.bulkCloseArray,$scope.attID,$scope.selectCase.bulkcloseCaseDispSelectedOption.value).then(function(data){

          var msg=data.status;

          $('#myModal').modal('hide');

          $('#myModal2').modal('hide');

         // console.log("cases are closed :::::::::::");

    var params = $scope.updateCaseDetailsParams();
     
      caseDetailFactory.getCaseDetailData($scope.attID,params,$scope.currentPage-1,$scope.rowsPerPage).then(function(data){

       

          
            $scope.caseDetailsData = data;

     

           var caseDetailsTableData = data.dataList;

             if($scope.caseDetailsData.location){

            $scope.street = $scope.caseDetailsData.location.address;

          }

            if(data.dataList){

              $scope.eventsListLength=caseDetailsTableData.length;

              $scope.alertsDataLength=caseDetailsTableData.length;

            } else {

              $scope.eventsListLength=0;

              $scope.alertsDataLength=0;

            }

   

          var caseDetailsUpdatedDate=data.lastUpdateDateTime;

           var lastUpdateDateandTime='';

         if(caseDetailsUpdatedDate === null || caseDetailsUpdatedDate === 'null' || caseDetailsUpdatedDate === ''){

            lastUpdateDateandTime=data.createdDateTime;

         } else {

          lastUpdateDateandTime=data.lastUpdateDateTime;

         }

 

           $scope.lastUpdatedDate = dateTimeFactory.changeToLocalTimeFromDate(lastUpdateDateandTime);

         

          var caseStatus= data.caseStatusType.name;

          var caseDispositionValue=data.caseDisposition;

        

          var caseDisposition='';

          if(caseDispositionValue === null || caseDispositionValue === 'null' || caseDispositionValue === '' )

          {

            $scope.caseDispositionSelectedOption = $scope.CaseDispositionOptions[0];

 

          }

          else{

              caseDisposition=data.caseDisposition;

 

          }

     

          $scope.investigatorId=data.investigatorId;

           var investigatorId=data.investigatorId;

          

 

            for(var i=0;i<$scope.caseOwnsers.length;i++){

 

              var caseOwnerAttId=$scope.caseOwnsers[i].value;

              if(caseOwnerAttId === investigatorId)

              {

              

                $scope.caseOwnerSelectedOption=$scope.caseOwnsers[i];

                 break;

              }

           }

           for(var i=0;i<$scope.CaseDispositionOptions.length;i++){

 

              var caseDispositionValue=$scope.CaseDispositionOptions[i].value;

              if(caseDispositionValue === caseDisposition)

              {

              

                 $scope.caseDispositionSelectedOption = $scope.CaseDispositionOptions[i];

                //$scope.caseOwnerSelectedOption=caseDispositionValue;

                 break;

              }

           }

            for(var i=0; i < $scope.CaseStatusOptions.length; i++ ){

              if($scope.CaseStatusOptions[i].name === caseStatus){

                $scope.caseStatusSelectedOption = $scope.CaseStatusOptions[i];

                break;

              };

          };

              

          

          if(investigatorId == '' || investigatorId == null || investigatorId == 'null')

          {

           // console.log("this is unassigned case::::::::::",investigatorId);

           // $scope.caseStatusSelectedOption.name =caseStatus;

 

            $scope.CaseStatusPosition=false;

            $scope.caseDispositonPosition=true;

            $scope.caseOwnerPosition=true;

 

          }else if(investigatorId === $rootScope.loggedAttId)

          {

           // console.log("this is assigned case::::::::::",investigatorId);

            

            

            $scope.CaseStatusPosition=false;

            $scope.caseDispositonPosition=true;
            $scope.caseOwnerPosition=false;
            
 

          }else {


             topSummaryFactory.checkUserInUPM().then(function(data){

              if(data.upmCheck == "true"){
                  $rootScope.isAdmin = true;
                $scope.CaseStatusPosition=false;

                if(caseStatus === 'Closed') {      
                    $scope.caseDispositonPosition=false;
                }else{
                    $scope.caseDispositonPosition=true;
                }

                $scope.caseOwnerPosition=false;

              }

              else{

 
                  $rootScope.isAdmin = false;
                $scope.CaseStatusPosition=true;

                $scope.caseDispositonPosition=true;

                //$scope.caseOwnerPosition=true;

              }

            });

          }

          if(caseStatus === 'Closed')

          {

             $scope.CaseStatusPosition=false;

            $scope.caseDispositonPosition=false;

            $scope.caseOwnerPosition=false;

 

          }

 

      
            $scope.prepareAlertsTableData(data);
            $scope.alertsDataLength=caseDetailsTableData.length;
          $scope.bulkCloseArrayDuplicate=[];
          $('#bulkCloseBtn').attr('disabled','disabled');
            $(".rows-per-page label").text("Results per page");

          });

 

          

          
         

         });

       

    };

 

    $scope.cancelAddNote = function(){

      $scope.selectCase.bulkcloseCaseDispSelectedOption=$scope.bulkCloseCaseDispOptions[0];

      $scope.bulkCloseDispChange($scope.bulkCloseCaseDispOptions[0]);

    };

 

  /*    $('#myModal2').on('hidden.bs.modal', function () {

        

        angular.element(this).find("div[data-toggle='dropdown']>button").text($scope.caseDispositionSelectedOption.name);

                 

    }); */



    

 

      $scope.bulkCloseDispChange=function(bulkcloseDispValue){

        //  $scope.caseDispos = dispositionValue;

          $scope.selectCase.bulkcloseCaseDispSelectedOption=bulkcloseDispValue;

       //   console.log("changed value isss::::::::::", dispositionValue);

    }

 

 

 

    $scope.resetFilter = function(){

      $scope.caseDetails.alertID = '';

      $scope.caseDetails.alertMin = '';

      $scope.caseDetails.alertMax = '';

      $scope.caseDetails.resetField = '';

      $scope.caseDetails.mobility = '';

      $scope.caseDetails.clarifyNoMemoCount = '';

      $scope.caseDetails.telegenceNoMemoCount = '';

     

      $scope.caseDetails.selectedDateOfAccess = {

        'name' : '',

        'value' : ''

      };

   

      //      $scope.caseDetails.selectedAccountsAccessed = {
//
//        'name' : 'Select'
//
//      };
//
//      $scope.caseDetails.selectedNoOfCtns = {
//
//        'name' : 'Select'
//
//       };
//
//      $scope.caseDetails.selectedAccountsNoted = {
//
//        'name' : 'Select'
//
//       };
//
//      $scope.caseDetails.selectedPercentageNoted  = {
//
//       'name' : 'Select'
//
//       };
    
      $scope.caseDetails.selectedAccountsAccessed = [];
      $scope.caseDetails.selectedNoOfCtns = [];
      $scope.caseDetails.selectedAccountsNoted = [];
      $scope.caseDetails.selectedPercentageNoted = [];

      $scope.caseDetails.banMin = '';

      $scope.caseDetails.banMax = '';

      $scope.caseDetails.ctnMin = '';

      $scope.caseDetails.ctnMax = '';

      $scope.allcase.statusType = [];

 

      $('#caseDetailsStatus').empty();

      $('#caseDetailsStatus').append($compile(' <div ng-repeat = "data in statusArray">'+

      '<div class="checkbox"><input type="checkbox" value="{{data}}" id="{{data}}" ng-model="status" my-checkbox />'+

      '<label for = "{{data}}" >{{data}}</label> </div></div>    ')($scope));

   

     /* $scope.caseDetails.selectedFilterAlertDisp = {

        'name' : 'Select upon alert Closure'

      };*/

         $scope.caseDetails.selectedFilterAlertDisp =[];
        $rootScope.caseDetailsFromFilters =[];
   
        $scope.updateAllCases();
    }

  

    $scope.activeInfo = 'caseDetails';

 

       $scope.getCaseNotesTableData=function(){

 

           $scope.currentPageforNotes = 1;

             $scope.notesTableData = {};

             $scope.rowsPerPageNotes = 10;

             $scope.notesTableData.headers = {

              'attUserId' : 'UID',

              'name' : 'NAME',

              'createDateTime' : 'DATE',

              'content' : 'NOTE'

            };

 

 

            caseNotesFactory.getCaseNotesData($scope.attID).then(function(data){

 

              $scope.tableOptions = [{ name:"10", selected: true },{ name:"40" },{ name:"60" }];

              $('.notesDynmicTable  dynamic-table').remove();

              $('.notesDynmicTable').append($compile('<dynamic-table  filter-by="tableFilter" table-content="notesTableData"  show-table-header="true"show-table-footer="hide" selectable-table-rows="false" per-page-options="tableOptions" current-page="currentPageforNotes"  sorting="false"  items-per-page="rowsPerPageNotes" table-filter-condition="Notes"></dynamic-table>')($scope));

              if($scope.isSaveNotes)

              {

               

                  if(data[0].createDateTime)

                  {

                    var time = data[0].createDateTime.split(',').join(' ').split('-').join('/');
                      /*
                    $scope.fileTime = time[0].split('-')[2]+'-'+time[0].split('-')[0]+'-'+time[0].split('-')[1]+'T'+time[1]+'Z';
                        console.log($scope.fileTime);
 

                    $scope.locatTime = ($filter('date')(new Date($scope.fileTime), 'HH:mm:ss'));

                    $scope.locatDate = ($filter('date')(new Date($scope.fileTime), 'MM/dd/yyyy'));

                        */

                    $scope.lastUpdatedDate = (time);

                  }

                }

                $.each(data,function(index,value){

 

                  var time = value.createDateTime.split(',').join(' ').split('-').join('/');
                 /*   console.log(time);
                  $scope.fileTime = time[0].split('-')[2]+'/'+time[0].split('/')[0]+'/'+time[0].split('-')[1]+' '+time[1];

                    

                  $scope.locatTime = ($filter('date')(new Date($scope.fileTime), 'HH:mm:ss'));

                  $scope.locatDate = ($filter('date')(new Date($scope.fileTime), 'MM/dd/yyyy'));
                    */      

                  $scope.createDateTime =  time; // ($scope.locatDate + " " + $scope.locatTime);

                  value.createDateTime =   time; //($scope.locatDate + " " + $scope.locatTime);

                    value.content = value.content.split("\n").join("<br>");

              })

 

                $scope.notesTableData.tbody = data;

                $('.rows-per-page label').text('Results per page');

 

               $scope.noOfCaseNotes =data.length;

            });

 

        }

 

       $scope.getNotesDetailsDataWithSorting = function(sortField,sortDirection) {

                  

              $rootScope.loading = true;

              caseNotesFactory.getNotesDetailsDataWithSorting($scope.attID,sortField,sortDirection).then(function(data){

              $scope.tableOptions = [{ name:"10", selected: true },{ name:"40" },{ name:"60" }];

              $.each(data,function(index,value){

                  /*var time = value.createDateTime.split(',');

                  $scope.fileTime = time[0].split('-')[2]+'-'+time[0].split('-')[0]+'-'+time[0].split('-')[1]+'T'+time[1]+'Z';

                  $scope.locatTime = ($filter('date')(new Date($scope.fileTime), 'hh:mm:ss'));

                  $scope.locatDate = ($filter('date')(new Date($scope.fileTime), 'MM/dd/yyyy'));

                  $scope.createDateTime = ($scope.locatDate + " " + $scope.locatTime);

                  value.createDateTime =  ($scope.locatDate + " " + $scope.locatTime);*/
                  
                  var time = value.createDateTime.split(',').join(' ').split('-').join('/');
             
                  $scope.createDateTime =  time; // ($scope.locatDate + " " + $scope.locatTime);

                  value.createDateTime =   time; //($scope.locatDate + " " + $scope.locatTime);

                  value.content = value.content.split("\n").join("<br>");

              })

 

              $scope.notesTableData.tbody = data;

              $('.rows-per-page label').text('Results per page');

              $scope.noOfCaseNotes =data.length;

              $rootScope.loading = false;

          });

                   

       }

 

 

  

      $scope.getActivityLogDataWithSorting = function(sortField,sortDirection) {

       $rootScope.loading = true;
        $scope.sortField = sortField;
         $scope.sortDirec = sortDirection ;

       caseDetailFactory.getActivityLogDataWithSorting($scope.attID,0, $scope.rowsPerPageActivity,sortField,sortDirection).then(function(data){

          $scope.activityData=data.caseHistoryList;

          for(var i=0;i<$scope.activityData.length;i++)

          {

            $scope.activityData[i].caseUpdatedTime = dateTimeFactory.changeToLocalTimeFromDate($scope.activityData[i].caseUpdatedTime);

            $scope.activityData[i].status =  $scope.activityData[i].status.name;

            if($scope.activityData[i].change){

              var str =  ($scope.activityData[i].change).split('|').join('<br>');

              $scope.activityData[i].change=str.split(' ').join('&nbsp;&nbsp;')

            }

          }

          $scope.AcitivityLogtableData.tbody = $scope.activityData;

          $scope.currentPageActivity =1;

          $('.rows-per-page label').text('Results per page');

          $rootScope.loading = false;

        });

       

    };

    $scope.rowsPerPageActivity = 10;

    $scope.tableOptionsActivity = [{ name:"10", selected: true },{ name:"40" },{ name:"60" }];

      $scope.changeView = function(value){

      $scope.activeInfo = value;

      if($scope.activeInfo === 'notes'){

          $scope.csv = $scope.getCSVServiceLinkforNotes();

          $scope.isSaveNotes=false;

          $scope.getCaseNotesTableData();

 

      }else if($scope.activeInfo === 'activity'){

          $scope.csv=$scope.getCSVServiceLinkforActivityLog();

 

          $scope.currentPageActivity = 1;

          $scope.AcitivityLogtableData = {};

          $scope.totalRecords;

 

            $scope.AcitivityLogtableData.headers = {

            'updatedUser' : 'UID',

            'status' : ' STATUS',

            'caseUpdatedTime' : 'UPDATED TIME',

            'eventType':'CHANGE TYPE',

            'change':'CHANGE'

            

          };

          $scope.loadActivityData();

       } else if($scope.activeInfo === 'accessTimeLine'){

 

        $scope.showGraph = true;

 

       

     $rootScope.suspectId =$scope.caseDetailsData.suspectId;

  

       }else if($scope.activeInfo === 'caseDetails'){

           $scope.csv = $scope.getCSVServiceLink();

           $("#dataTabs li").removeClass("active");

           $("#caseDetailsTab").addClass("active");

           $("#caseDetailsTab").show();

       }

 

      };

 

    $scope.loadActivityData = function(){

 

        caseDetailFactory.getCaseHistorySummary($scope.attID,$scope.currentPageActivity-1, $scope.rowsPerPageActivity, $scope.sortField ,$scope.sortDirec).then(function(data){

 
          $rootScope.loading = true;
          $scope.totalRecords = data.totalRecords;

          $scope.totalPages = data.totalPages;

          $('.activityLogTable  dynamic-table').remove();

          $('.activityLogTable').append($compile('<dynamic-table  filter-by="tableFilter" table-content="AcitivityLogtableData"  show-table-header="true" show-table-footer="hide" selectable-table-rows="false" per-page-options="tableOptionsActivity" current-page="currentPageActivity"  sorting="false" total-rows="totalRecords"  on-per-page-change="onRowsPerPageChange(perPageSelected);" total-pages="totalPages" on-page-change="onPageChange(page)"  table-filter-condition="activityLogSort"></dynamic-table>')($scope));

          $scope.activityData=data.caseHistoryList;

              for(var i=0;i<$scope.activityData.length;i++)

              {

 

                  $scope.activityData[i].caseUpdatedTime = dateTimeFactory.changeToLocalTimeFromDate($scope.activityData[i].caseUpdatedTime);

                  $scope.activityData[i].status =  $scope.activityData[i].status.name;

                  if($scope.activityData[i].change){
                 var str =  ($scope.activityData[i].change).split('|').join('<br>');
                
                //new code
                 if($scope.activityData[i].eventType == "CASE_CREATE"){
                    var n= str.indexOf("TIME");
                   // console.log(n)
                    var changeDate = str.substring(n+6,n+34);
                   // console.log(changeDate) 
                    var dateVal = str.replace(changeDate,$scope.activityData[i].caseUpdatedTime);
                   // console.log(dateVal) 
                    $scope.activityData[i].change=dateVal.split(' ').join('&nbsp;&nbsp;');
                 }else{
                    $scope.activityData[i].change=str.split(' ').join('&nbsp;&nbsp;');
                 }
				    
                }

              }

           

              //$scope.currentPageActivity =1;

              $scope.AcitivityLogtableData.tbody = $scope.activityData;

              //$('.rows-per-page label').text('Results per page');
$rootScope.loading = false;
 

           });

 

  };
$scope.loadActivityDataWithPagination = function(){

 

        caseDetailFactory.getCaseHistorySummary($scope.attID,$scope.currentPageActivity-1, $scope.rowsPerPageActivity, $scope.sortField ,$scope.sortDirec).then(function(data){

 
          $rootScope.loading = true;
          $scope.totalRecords = data.totalRecords;

          $scope.totalPages = data.totalPages;
          $scope.activityData=data.caseHistoryList;

              for(var i=0;i<$scope.activityData.length;i++)

              {

 

                  $scope.activityData[i].caseUpdatedTime = dateTimeFactory.changeToLocalTimeFromDate($scope.activityData[i].caseUpdatedTime);

                  $scope.activityData[i].status =  $scope.activityData[i].status.name;

                 if($scope.activityData[i].change){
                 var str =  ($scope.activityData[i].change).split('|').join('<br>');
                // $scope.activityData[i].change=str.split(' ').join('&nbsp;&nbsp;');

                //new code
                 if($scope.activityData[i].eventType == "CASE_CREATE"){
                    var n= str.indexOf("TIME");
                   // console.log(n)
                    var changeDate = str.substring(n+6,n+34);
                   // console.log(changeDate) 
                     var dateVal = str.replace(changeDate,$scope.activityData[i].caseUpdatedTime);
                   // console.log(dateVal) 
                    $scope.activityData[i].change=dateVal.split(' ').join('&nbsp;&nbsp;');
                 }else{
                    $scope.activityData[i].change=str.split(' ').join('&nbsp;&nbsp;');
                 }
/*                  $scope.activityData[i].change =  ($scope.activityData[i].change).replace(/(\||,)/g, '<br />');*/
                }
              }

           

              //$scope.currentPageActivity =1;

              $scope.AcitivityLogtableData.tbody = $scope.activityData;

              //$('.rows-per-page label').text('Results per page');
$rootScope.loading = false;
 

           });

 

  };
 

      $scope.cancelNote = function(){

      this.updateNotes = '';

      }

 

      $scope.saveCaseNote = function(){

      $scope.msg = (this.updateNotes)?this.updateNotes:'';

      this.updateNotes='';

          $scope.saveInfo = {

            "name": $scope.loggedFirstName + ' ' + $scope.loggedLastName,

            "attUserId": $rootScope.loggedAttId,

            "content": $scope.msg

          }

 

         caseNotesFactory.saveNotesData($scope.attID,$scope.saveInfo).then(function(data){

            $scope.updateNotes ='';

            $scope.isSaveNotes=true;

           $scope.getCaseNotesTableData();

 

          });

//$scope.getCaseNotesData();

 

      }

 

    $scope.updateCaseDetailsTableWithSorting = function(sortField,sortDirection) {

        $rootScope.loading = true;
        var params = $scope.updateCaseDetailsParams();
    caseDetailFactory.getCaseDetailsDataWithSorting($scope.attID,params,$scope.currentPage-1,$scope.rowsPerPage,sortField,sortDirection).then(function(data){

    

       $scope.caseDetailsData = data;

        var caseDetailsTableData = data.dataList;

        if($scope.caseDetailsData.location){

          $scope.street = $scope.caseDetailsData.location.address;

        }
        if(data.dataList){

          $scope.eventsListLength=caseDetailsTableData.length;

          $scope.alertsDataLength=caseDetailsTableData.length;

        } else {

          $scope.eventsListLength=0;

          $scope.alertsDataLength=0;

        }

 

          $scope.showForm = true;

          $scope.alertsDataLength=caseDetailsTableData.length;

          $(".rows-per-page label").text("Results per page");

           

          $scope.bulkCloseArrayDuplicate=[];

          $('#bulkCloseBtn').attr('disabled','disabled');

          var tableBody = [];

          $scope.tableData.tbody = [];

          

        $scope.prepareAlertsTableData(data);
         

        

        

                                                                  

      });

 

 

    }

 

    $scope.updateTableWithSorting = function(sortField,sortDirection,filterPage) {

       // $rootScope.loading = true;

        if(filterPage === "caseDetails")

        {

          $scope.updateCaseDetailsTableWithSorting(sortField,sortDirection);

        }

        else if(filterPage === "Notes") {

          $scope.getNotesDetailsDataWithSorting(sortField,sortDirection);

        }

        else if(filterPage === "activityLogSort"){

          $scope.getActivityLogDataWithSorting(sortField,sortDirection);

        }

      

       // console.log('inside the updateTableWithSorting sortField is:',sortField,': sortDirection is:',sortDirection,':currentPage :',$scope.currentPage);

    

  };

 

    $scope.lftContent = function(openLeft){

        if(openLeft){

            $scope.openLeft = false;

        } else {

            $scope.openLeft = true;

        }

    };

 

    $scope.leftLoad = function(){

 

      $scope.sideHeight = $window.innerHeight - ( 75 + 50 + $document.find('header').height() + $document.find('footer').height() );

      $document.find('.sideInfo').height($scope.sideHeight);

    };

 

    $scope.leftLoad();

 

    $(window).resize(function(){

     

      $scope.leftLoad();

    });

 
$window.appendAlertIds = function(){

    var alertids = [];

    $(".caseDetailsCheckbox").each(function( index ) {

        if($(this).is(":checked")){

            alertids.push($(this).val());

        }

    });

    var downloadLink = $scope.csv;
     var sortlink = (downloadLink && downloadLink.indexOf("&sort") > -1) ? "&sort="+downloadLink.split("&sort=")[1] : "";
    if(downloadLink && downloadLink.indexOf("&selectedAlerts") > -1 ){

     var splitLink = downloadLink.split("&selectedAlerts");

        downloadLink = splitLink[0];

    }

   

    if(alertids.length){       

        

    downloadLink = downloadLink +'&selectedAlerts='+alertids.toString();

        $("#selectedAlertsList").val(alertids.toString())

    }else{

      downloadLink = downloadLink +'&selectedAlerts=';

      $("#selectedAlertsList").val('');   

    }

   downloadLink = downloadLink + sortlink; 

    

    

    $scope.csv = downloadLink;

    console.log("downloadLink"+downloadLink);

}
   
  $scope.prepareAlertsTableData = function(data){
      $scope.totalPages = data.totalPages;

    $scope.totalRows = data.totalRecords;
      var caseDetailsTableData = data.dataList;
      $.each(caseDetailsTableData,function(i,v)

    {

 

        $rootScope.alertId = v.id;

 

        if(v.alertStatusType === "Closed"){

          v.caseId ={

           'value': caseDetailsTableData[i].id,

           'html': $sce.trustAsHtml($compile("<input type='checkbox' value= '"+ caseDetailsTableData[i].id+"' id=caseCheckbox"+i+" class='caseDetailsCheckbox disableRow' style='position : relative !important;' onclick='appendAlertIds()'/>")($scope)[0].outerHTML)

          };

        } else {

        v.caseId ={

          'value': caseDetailsTableData[i].id,

          'html': $sce.trustAsHtml($compile("<input type='checkbox' value= '"+ caseDetailsTableData[i].id+"' id=caseCheckbox"+i+"  class='caseDetailsCheckbox' style='position : relative !important;' onclick='appendAlertIds()'/>")($scope)[0].outerHTML)

         };

        }

        v.id ={

          'value': caseDetailsTableData[i].id,

          'html': $sce.trustAsHtml('<a style="position : relative !important;text-decoration:underline" href="#/alertDetails/'+caseDetailsTableData[i].id+'/'+ $scope.attID+'" >'+caseDetailsTableData[i].id+'</a>')

        }

        caseDetailsTableData[i].anomalyProbability=parseFloat($filter('number')(caseDetailsTableData[i].anomalyProbability * 100 , 3));

        caseDetailsTableData[i].accountsAccessed=caseDetailsTableData[i].accountsAccessed.toString();

        caseDetailsTableData[i].countOfCTNAccessed=caseDetailsTableData[i].countOfCTNAccessed.toString();

        caseDetailsTableData[i].accountsNotedBySuspectId=caseDetailsTableData[i].accountsNotedBySuspectId.toString();

        caseDetailsTableData[i].percentageNotedBySuspectId=caseDetailsTableData[i].percentageNotedBySuspectId.toString();
        caseDetailsTableData[i].date = caseDetailsTableData[i].date.substring(4,6)+'/'+caseDetailsTableData[i].date.substring(6,8)+'/'+caseDetailsTableData[i].date.substring(0,4);
      });

 

      $scope.tableData.tbody = caseDetailsTableData;
      $timeout(function() {

             $("input.disableRow").parents("tr.ng-scope").find("td").css("background","#f2f2f2");
             
             $rootScope.loading = false;

         },1000);
  };

 

  $scope.showMore = function(){

       

        

        $(".show-more-content").toggle(500);

        if($rootScope.showMoreContent){

            $rootScope.showMoreContent = false;

            $(".show-more-link a").html("Show more ...");

        }else{

            $rootScope.showMoreContent = true;

           

            $(".show-more-link a").html("Show less");

        }

       

    };
    

  $scope.init ();

}]);

