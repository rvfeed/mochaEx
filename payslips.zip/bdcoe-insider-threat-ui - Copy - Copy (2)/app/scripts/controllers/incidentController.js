angular.module('insiderApp')
.controller('incidentCtrl', ['$scope','$rootScope','getServiceURI' ,'incidentFactory','$sce','$compile','$q','caseDetailFactory','SessionService','topSummaryFactory','$state',function($scope,$rootScope,getServiceURI,incidentFactory,$sce,$compile,	$q,caseDetailFactory,SessionService,topSummaryFactory,$state){
   
	$rootScope.route = [
		{
		    "url" : "home",
		    "name" : "Home"
		},
		{
		    "url" : "incidentResponse",
		    "name" : "Incident Response"
		}
    ];
    $rootScope.fromGraph = "no";
    $scope.myDate=new Date();
    $scope.monthOptions = [{name:"Jan",value:0},{name:"Feb",value:1},{name:"Mar",value:2},{name:"Apr",value:3},{name:"May",value:4},{name:"Jun",value:5},{name:"Jul",value:6},{name:"Aug",value:7},{name:"Sep",value:8},{name:"Oct",value:9},{name:"Nov",value:10},{name:"Dec",value:11}];
    $scope.selectedMonth = $scope.monthOptions[$scope.myDate.getMonth()];
    $scope.csv = getServiceURI.build('insiderThreat', 'exportAllCases')+"/"+($scope.selectedMonth.value+1);
    $rootScope.loggedusername = SessionService.getLegacyUIDs('cingularCUID');
    $scope.init=function()
	{
        console.log("Step1---->Checking Admin Permissions");
		topSummaryFactory.checkUserInUPM().then(function(data){
  		if(data.upmCheck == "true")
  			$scope.isAdminUser=true;
  		else
  			$scope.isAdminUser=false;
  		// $state.go('error',{'id':""});
  		console.log("Step2---->Is Admin"+$scope.isAdminUser);
        topSummaryFactory.getUserPermissions().then(function(data){
           $scope.permissions = data.componentPermissionMap;
            if(!$scope.permissions.IT_INCIDENCE_RESPONSE.view){
                $state.go('error',{'id':""});
            }
            $scope.userCanAdd = $scope.permissions.IT_INCIDENCE_RESPONSE.add ;
            $scope.userCanEdit = $scope.permissions.IT_INCIDENCE_RESPONSE.edit;
            $scope.userCanDelete = $scope.permissions.IT_INCIDENCE_RESPONSE.delete;
            console.log("Step3---->Permissions"+$scope.userCanAdd+$scope.userCanEdit+$scope.userCanDelete);
            $scope.loadIncidentResponseData();
        });    
  		});
        

	}
    $scope.currentPage = 1;
	$scope.tableData = {};
	$scope.tableData.headers = {
		'investigatorId' : 'UID',
		'ruleId' : 'Rule Id',
		'threshold' : 'Threshold',
		'action' : 'Action',
		'contact' : 'Contact',
		'edit' : 'EDIT',
		'deleteId' : 'DELETE'
		
	}
		
        $scope.loadIncidentResponseData = function(){
            console.log("Step4---->Loading IncidentResponse");
        	incidentFactory.getAdminContacts().then(function(data){
		$scope.incidentData = data.incidentContactsList;
		$scope.incidentDataLength = data.incidentContactsList.length;
		if(data.serviceResult.success ===true){
		                    angular.forEach(data.incidentContactsList,function(value,key){

		                    		if($scope.userCanEdit ){
                                        console.log("Step5---->Had edit permissions");
                                        console.log("Step6---->"+$scope.isAdminUser);
                                        console.log("Step7---->"+typeof($scope.isAdminUser));
                                        if($scope.isAdminUser || value.investigatorId === $rootScope.loggedusername){
                                            console.log("Step8---->Finally can be edited");
										value.edit = 
		                                 {
		                                   "value": '0',
		                                   "html":  $sce.trustAsHtml($compile("<a title='id' onclick='editContact(event)'  data-toggle='modal' data-id="+value.id+" data-investigatorId="+value.investigatorId+" data-ruleId="+value.ruleId+" data-threshold="+value.threshold+" data-contact="+value.contact+" data-action="+value.action+" data-target='#myModal'><span class='glyphicon glyphicon-pencil' aria-hidden='true'></span></a>")($scope)[0].outerHTML)
		                                };
                                            }
                                    }
                                if($scope.userCanDelete){
                                    if($scope.isAdminUser || value.investigatorId === $rootScope.loggedusername){
										value.deleteId =
										{
											"value" : '0',
											"html" : $sce.trustAsHtml($compile("<a title='id' onclick='confirmDelete(event)' data-toggle='modal' data-id="+value.id+"  data-target='#myModal3'><span class='glyphicon glyphicon-trash' aria-hidden='true'></span></a>")($scope)[0].outerHTML)
										};
		                            	
                                }
                                }
		                    		$scope.conditionVal = value.condition;
		                    		value.threshold = value.condition + value.threshold;
		                    });
		                $scope.tableData.tbody  = data.incidentContactsList;            
		                console.log($scope.tableData.tbody);
		                 $(".rows-per-page label").text("Results per page");			

		            }
		})
        }
		$scope.setCurrentPageWhenSorting = function(pageNumber){
              //console.log('setting current page to bcoz unequla sorting columns',pageNumber);
              $scope.currentPage =pageNumber;
              //$scope.getActivityLogDataWithSorting( $scope.sortField,$scope.sortDirec);
        }
        $scope.setSortConditions = function(sortField,sortDirection){
             // console.log('setting the sort conditions in allCasesController to :',sortField,'::',sortDirection);
              $scope.sortField = sortField;
              $scope.sortDirec = sortDirection;
        }
        $scope.onPageChange = function(page){
          $scope.currentPage = page;
         // $scope.updateTableWithSorting($scope.sortField,$scope.sortDirec);
          //$scope.getActivityLogDataWithSorting( $scope.sortField,$scope.sortDirec);
        }
        $scope.getRowCount = function(i){
            var total = $scope.rowsPerPage,
            currentPage = $scope.currentPage;
            i += currentPage > 1 ? (currentPage * total) - total + 1 : 1;
                i = i>$scope.totalRows?$scope.totalRows:i;
            return i;
        };
        $scope.onRowsPerPageChange = function (page ) {
          $scope.currentPage =1;
            $scope.rowsPerPage = page.name;
           
        }
     //$scope.isAdminUser = true;
    //  $rootScope.loggedusername = "jc715w";
   	$scope.addNewContact = function(){
   		$scope.addNew = true;
  	}
   	$scope.cancelNewContact = function(){
   		$scope.addNew = false;
   		$scope.addContact = {				
		};
		$scope.addContact.condition = {
			'name' : 'Conditions'
		};		
		$scope.addContact.action = {			
			'name' : 'Actions'
		};
		$scope.addContact.investigatorId ={
			'name' : 'Investigator Id'		
		};
		$scope.addContact.ruleId ={
			'name' : 'Rule Id'
		};
		$scope.addContact.contact = '';
		$scope.addContact.threshold = '';	
   	}

    $scope.$watch('selectedMonth', function(newValue){
        $scope.csv = getServiceURI.build('insiderThreat', 'exportAllCases')+"/"+(newValue.value+1);
    });
	       
	$scope.addContact = {};
	$scope.editconditions = {
        'name' : '>='	
    };
	$scope.editactions = [
		{	'name' : 'Email'	},
		{	'name' : 'SMS'		}
	];
	$scope.editRuleId = [
		{
			'name' : "Rule Id"
		}
	];

	
	var	investigator = caseDetailFactory.getCaseOwners();
	var  getContact = incidentFactory.getAdminContacts();
	var  getRuleIds = incidentFactory.getAllRuleId();

	$q.all([investigator,getContact,getRuleIds]).then(function(resultData){
		
		$scope.Investigator = [{
		}];
		
		$scope.ruleIdList = [
		{
			'name' : "Rule Id"
		}
		];		
	    
	    var caseOwnersData = resultData[0];
	    var ruleIdsData = resultData[2]; 
	    $scope.ruleIdsListData = resultData[2]; 
	    
		if(resultData[1].incidentContactsList.length>0){
	        $scope.adminContacts = resultData[1].incidentContactsList;	          
	      	$scope.totalLogins=$scope.adminContacts.length;
	    }
         		
		
		for(var i=0;i<caseOwnersData.caseManagerList.length;i++){				
			if(i===0){
				$scope.Investigator.push({
					'name' : 'Investigator Id'
				})	;
			}
	    	$scope.Investigator.push({'name':caseOwnersData.caseManagerList[i].attUserId}) ;
			
		}	
		for(var j=0;j<ruleIdsData.length;j++){				
		 	$scope.ruleIdList.push({'name':ruleIdsData[j].ruleNumber}) ;
		 }	
		
		$scope.addContact.investigatorId ={
			'name' : 'Investigator Id'
		};
		if(ruleIdsData.length == 1){
			$scope.addContact.ruleId ={
				'name' : ruleIdsData[0].ruleNumber
			};
			$('#ruleId').attr("disabled", true);
		}else{
			$scope.addContact.ruleId ={
				'name' : 'Rule Id'
			};
		}
		
		$scope.conditions = [
			{'name' : '>='}
		];
		
		$scope.addContact.condition = {
			'name' : 'Conditions'
		};

		$scope.actions = [
			{'name' : 'Email'},
			{'name' : 'SMS'}
		];
		
		$scope.addContact.action = {
			'name' : 'Actions'
		}
      
		
		$scope.actions.push($scope.selectedAction);
		$scope.conditions.push($scope.selectedCondition );
		$scope.addContact.contact = '';
		$scope.addContact.threshold = '';
		
	});
	window.editContact = function(event){
		$scope.editContact={};
		// $scope.editContact.condition = {
		// 		'name' : 'Condition'
		// };
		$scope.editContact.action = {
				'name' : 'Actions'
		};
		$scope.editContact.ruleId = {		
				'name' : 'Rule Id'		
		};
		$scope.editContact.id = $(event.currentTarget).attr('data-id');
		$scope.editContact.investigatorId = $(event.currentTarget).attr('data-investigatorId');
		$scope.editContact.threshold = parseFloat($(event.currentTarget).attr('data-threshold'));
		$scope.editContact.contact = $(event.currentTarget).attr('data-contact');
		$scope.actionname = $(event.currentTarget).attr('data-action');
		$rootScope.invId = $scope.editContact.investigatorId;
		//$scope.editContact.condition= $(event.currentTarget).attr('data-condition');
		$scope.editContact.ruleId.name = $(event.currentTarget).attr('data-ruleId');	
		for(var j=0;j<$scope.ruleIdsListData.length;j++){
		  		$scope.editRuleId.push({'name':$scope.ruleIdsListData[j].ruleNumber}) ;
		}
		// for(var j=0;j<$scope.ruleIdsListData.length;j++){		
		// 		 $scope.editconditions.push({'name':$scope.ruleIdsListData[j].condition}) ;
		// }
      //  $("#edit-ruleId button").prop("disabled","disabled")
       // $("#edit-condition button").prop("disabled","disabled")
	}


	  window.confirmDelete=function(event){  
            //$scope.editContact= {};
            $scope.deleteContactId = $(event.currentTarget).attr('data-id');
            for(var i=0; i<$scope.incidentDataLength;i++){
        		if($scope.incidentData[i].id === $scope.deleteContactId){
        			$scope.indexVal = i;
        		}
        	}
            // $scope.indexVal=this.$index;
            // console.log(this.$index)
        }
		
        $scope.deleteContact=function(){
        	
        	console.log($scope.indexVal);
			$scope.adminContacts.splice($scope.indexVal, 1);        
            incidentFactory.removeContact($scope.deleteContactId);
           // $scope.loadIncidentResponseData();
            $(".modal").hide();
            window.location.reload();
            console.log("delete contact................")
            $scope.loadIncidentResponseData();
			//window.location.reload();
		}
		
		// $scope.editContact=function(x){
		// 	$scope.editContact.condition = {
		// 		'name' : 'Conditions'
		// 	};
		// 	$scope.editContact.action = {
		// 		'name' : 'Actions'
		// 	};
		// 	$scope.editContact.ruleId = {
		// 		'name' : 'Rule Id'
		// 	}
		// 	$scope.editRuleId = [
		// 		{
		// 			'name' : "Rule Id"
		// 		}
		// 	];
		// 	var obj=[];            
            
  //           obj.investigatorId=x.investigatorId;
		// 	obj.threshold=x.threshold.toString().charAt(0);
		// 	obj.action=x.action;
		// 	obj.contact=x.contact;
  //           $scope.id=x.id;	
		// 	$scope.treshold=parseFloat(x.threshold);
		// 	$scope.timeframe=x.contact;
		// 	$scope.actionname=x.action;	
		// 	$scope.investigatorId=x.investigatorId;
		// 	$scope.condition = x.condition;
		// 	$scope.ruleId=x.ruleId;
  //           $rootScope.invId=x.investigatorId;
  //           for(var j=0;j<$scope.ruleIdsListData.length;j++){		
          
		// 	 	$scope.editRuleId.push({'name':$scope.ruleIdsListData[j].ruleNumber}) ;
		// 	}
		// 	for(var j=0;j<$scope.ruleIdsListData.length;j++){		
          
		// 	 	$scope.editconditions.push({'name':$scope.ruleIdsListData[j].condition}) ;
		// 	}
		// 	$scope.editContact.condition.name = $scope.condition;
		// 	$scope.editContact.ruleId.name = $scope.ruleId;

  //        }

	$scope.addContacts=function(){

   		$scope.closeCasePopup = false;   
   		var _dataObj = {
			 'id':"",
			'investigatorId' : ($scope.addContact.investigatorId.name==='Investigator Id') ? '' : $scope.addContact.investigatorId.name,
			'condition' :  ($scope.addContact.condition.name==='Conditions') ? '' : $scope.addContact.condition.name,
			'action' :  ($scope.addContact.action.name==='Actions') ? '' : $scope.addContact.action.name,
			'contact' : $scope.addContact.contact,
			'threshold' : $scope.addContact.threshold,
			'ruleId' : ($scope.addContact.ruleId.name==='Rule Id') ? '' : $scope.addContact.ruleId.name
			
		};
//			incidentFactory.addNewContact(_dataObj).then(function(data){
//	           
//	            window.location.reload();              
//              	$(".form-element").removeClass("customRequired");
//				$scope.addNew = false;			
//				$scope.addContact = {				
//				};
//				$scope.addContact.condition = {
//					'name' : 'Conditions'
//				};		
//				$scope.addContact.action = {			
//					'name' : 'Actions'
//				};
//				$scope.addContact.investigatorId ={
//					'name' : 'Investigator Id'		
//				};
//				$scope.addContact.ruleId ={
//					'name' : 'Rule Id'
//				};
//				$scope.addContact.contact = '';
//				$scope.addContact.threshold = '';	
//				
//			});
        incidentFactory.addNewContact(_dataObj).then(function(data){
                    
                    	if(data.success==false){
	  					$scope.ruleIdexistedPopup=true;

	  					$scope.ruleIdfailuretext=data.errorMessage;


	  				}else{
	  					console.log("coming to else");	
	  					$scope.ruleIdexistedPopup=false;
						window.location.reload();

	  				}
	           
		           // window.location.reload();              
	           		$(".form-element").removeClass("customRequired");
					$scope.addNew = false;			
					$scope.addContact = {				
					};
					$scope.addContact.condition = {
						'name' : 'Conditions'
					};		
					$scope.addContact.action = {			
						'name' : 'Actions'
					};
					$scope.addContact.investigatorId ={
						'name' : 'Investigator Id'		
					};
					$scope.addContact.ruleId ={
						'name' : 'Rule Id'
					};
					$scope.addContact.contact = '';
					$scope.addContact.threshold = '';	
				});
	}



	$scope.updateIncidents=function(){
		$rootScope.loggedusername = SessionService.getLegacyUIDs('cingularCUID');
        var validForm =true; 
		$(".form-element").removeClass("customRequired");  
		if($scope.editContact.ruleId.name==='Rule Id'){
		    validForm = false;
		    $("#edit-ruleId").addClass('customRequired');
		}
		// if($scope.editContact.condition.name==='Conditions'){
		//     validForm = false;
		//     $("#edit-condition").addClass('customRequired');
		// }
       if($scope.actionname === "SMS"){
       	var phonePattern= /^[1-9]\d*$/;
       	var test = phonePattern.test($scope.editContact.contact);
       	if($scope.editContact.contact.length < 10 || $scope.editContact.contact.length > 10 ){
       		$scope.lengthVal ="true";
       	}
       	if($scope.editContact.contact.length < 10 || $scope.editContact.contact.length > 10 || !test){
       			$scope.inputVal = "true";
        		validForm = false;
             $("#timeframeRule").addClass('customRequired');
        	}
       }
        if($scope.actionname === "Email"){
       	var emailPattern = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
       	var test = emailPattern.test($scope.editContact.contact);
       	if($scope.editContact.contact.length == 0 || !test){
       		$scope.inputVal = "true";
        		validForm = false;
             $("#timeframeRule").addClass('customRequired');
        	}
       }

		if($scope.editContact.threshold.length == 0){
		    validForm = false;
		    $("#edit-treshold").addClass('customRequired');
		}
		if(!validForm){
		    return false;
		}  

		var _dataObj = {
            'id':$scope.editContact.id,
			'investigatorId' : $scope.editContact.investigatorId ,
            'condition' :  $scope.conditionVal,
            'contact' : $scope.editContact.contact,
            'action' : "",    
            'threshold' : $scope.editContact.threshold,
            'ruleId' :  $scope.editContact.ruleId.name
		};
		         
    	incidentFactory.checkThreshold(_dataObj).then(function(data){
 			if(data.status === "Smaller"){
    		$scope.closeUpdateIncidentsPopup=true;
	    	}
	    	else{

	   			var _dataObj = {
                    'id':$scope.editContact.id,
			        'investigatorId' : $scope.editContact.investigatorId ,
	                'condition' :  $scope.conditionVal,
	                'contact' : $scope.editContact.contact,
	                'action' : "",    
	                'threshold' : $scope.editContact.threshold,
	                'ruleId' : $scope.editContact.ruleId.name
				};
			console.log("data object before Edit",_dataObj);
				incidentFactory.updateContact(_dataObj).then(function(data){
	                $(".modal").hide();
				    window.location.reload();
				});
    		}
    	});
	}
	$scope.cancelUpdate= function(){
		$scope.lengthVal = false;
		$scope.inputVal = false;
		$("#timeframeRule").removeClass('customRequired');
	}

	$scope.updateIncidentContact=function(){

   		$scope.closeUpdateIncidentsPopup = false;   
   		var _dataObj = {
            'id':$scope.editContact.id,
		    'investigatorId' : $scope.editContact.investigatorId ,
            'condition' :  $scope.conditionVal,
            'contact' : $scope.editContact.contact,
            'action' : "",    
            'threshold' : $scope.editContact.threshold,
            'ruleId' :  $scope.editContact.ruleId.name
		};
		
		incidentFactory.updateContact(_dataObj).then(function(data){
            $(".modal").hide();
			window.location.reload();
		});
	}
	
	$scope.closeCasePopupClose = function(){
       	$scope.closeCasePopup = false;   
    }
	$scope.closeUpdateIncidentsPopupClose = function(){
       	$scope.closeUpdateIncidentsPopup = false;   
    }
      $scope.closeRuleFailurePopupClose= function(){
    	$scope.ruleIdexistedPopup=false;

    }

	$scope.addOneContact = function(){        
        $rootScope.loggedusername = SessionService.getLegacyUIDs('cingularCUID');
   		 if($scope.isAdminUser !== true){
   			$scope.addContact.investigatorId.name = $rootScope.loggedusername;
   		}    
		var validForm = true;    
		$(".form-element").removeClass("customRequired");
		if($scope.addContact.investigatorId.name==='Investigator Id' ){
            validForm = false;
            $("#investigatorId").addClass('customRequired');
           
        }
        if($scope.addContact.ruleId.name==='Rule Id'){
		    validForm = false;
		    $("#ruleId").addClass('customRequired');
		}
        if($scope.addContact.condition.name==='Conditions'){
            validForm = false;
            $("#condition").addClass('customRequired');
           
        }
        if($scope.addContact.action.name==='Actions'){
            validForm = false;
             $("#action").addClass('customRequired');
           
        }
        if($scope.addContact.action.name === "SMS"){
        	var re= /^[1-9]\d*$/;
        	var test = re.test($scope.addContact.contact) 
        	if($scope.addContact.contact.length == 0 || !test){
        		validForm = false;
             $("#contact").addClass('customRequired');
        	}
        }
        if($scope.addContact.action.name === "Email"){
         	var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  			var test =re.test($scope.addContact.contact);
        	if($scope.addContact.contact.length == 0 || !test){
        		validForm = false;
             $("#contact").addClass('customRequired');
        	}
        	
        }
        if($scope.addContact.contact.length == 0){
            validForm = false;
             $("#contact").addClass('customRequired');
           
        }
        if($scope.addContact.threshold.length == 0){
            validForm = false;
             $("#threshold").addClass('customRequired');
           
        }
        if(!validForm){
            return false;
        }
		
		var _dataObj = {
			'id':"",
			'investigatorId' : ($scope.addContact.investigatorId.name==='Investigator Id') ? '' : $scope.addContact.investigatorId.name,
			'condition' :  '>',
			'action' :  ($scope.addContact.action.name==='Actions') ? '' : $scope.addContact.action.name,
			'contact' : $scope.addContact.contact,
			'threshold' : $scope.addContact.threshold,
			'ruleId' : ($scope.addContact.ruleId.name==='Rule Id') ? '' : $scope.addContact.ruleId.name
			
		};
         
    	incidentFactory.checkThreshold(_dataObj).then(function(data){
 			if(data.status === "Smaller"){
    			$scope.closeCasePopup=true;
    		}
    		else{

    			var _dataObj = {
			         'id':"",
					'investigatorId' : ($scope.addContact.investigatorId.name==='Investigator Id') ? '' : $scope.addContact.investigatorId.name,
					'condition' :  ($scope.addContact.condition.name==='Conditions') ? '' : $scope.addContact.condition.name,
					'action' :  ($scope.addContact.action.name==='Actions') ? '' : $scope.addContact.action.name,
					'contact' : $scope.addContact.contact,
					'threshold' : $scope.addContact.threshold,
					'ruleId' : ($scope.addContact.ruleId.name==='Rule Id') ? '' : $scope.addContact.ruleId.name
					
				};
	  			incidentFactory.addNewContact(_dataObj).then(function(data){
                    
                    	if(data.success==false){
	  					$scope.ruleIdexistedPopup=true;

	  					$scope.ruleIdfailuretext=data.errorMessage;


	  				}else{
	  					console.log("coming to else");	
	  					$scope.ruleIdexistedPopup=false;
						window.location.reload();

	  				}
	           
		           // window.location.reload();              
	           		$(".form-element").removeClass("customRequired");
					$scope.addNew = false;			
					$scope.addContact = {				
					};
					$scope.addContact.condition = {
						'name' : 'Conditions'
					};		
					$scope.addContact.action = {			
						'name' : 'Actions'
					};
					$scope.addContact.investigatorId ={
						'name' : 'Investigator Id'		
					};
					$scope.addContact.ruleId ={
						'name' : 'Rule Id'
					};
					$scope.addContact.contact = '';
					$scope.addContact.threshold = '';	
				});
    		}
    	});
	}

	$scope.init();

}]);



