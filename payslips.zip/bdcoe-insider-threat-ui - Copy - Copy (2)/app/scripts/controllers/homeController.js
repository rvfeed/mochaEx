 'use strict';

angular.module('insiderApp')
.controller('homeCtrl', ['$scope','$rootScope','$sce', '$routeParams', '$log', '$location','topSummaryJson', '$filter','$state','casesService','allCasesFactory','topSummaryFactory','$compile', function ($scope,$rootScope, $sce,$routeParams, $log, $location ,topSummaryJson,$filter,$state,casesService,allCasesFactory,topSummaryFactory,$compile) {

    $rootScope.loading = true;
    $('#cases').show();
    $('#alerts').show();	
    $('#admin').show();
    $('#settings').show();
    $('#breadcrumb-1').show();
    $rootScope.routedFromAllAlerts = 'no';
    var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    $scope.isShow = false;
    $rootScope.fromGraph = "no";
    var caseList = topSummaryJson.caseList;
    if(caseList){
        var topSummary = [];
        for(var i=0;i<caseList.length;i++){
            var summaryDataList = caseList[i].summaryDataList;
            if(summaryDataList && summaryDataList.length>0){
                var summaryData = summaryDataList[0];
                var topSummaryData={};
                topSummaryData.attID = summaryData.userId;
                topSummaryData.caseId = caseList[i].id;
                topSummaryData.probabilityScore = caseList[i].maxProbability;
                topSummaryData.callCenterState = summaryData.agentState;
                topSummaryData.callCenterCity = summaryData.agentCity;
               /* var dateConvert  = caseList[i].latestAlertDate.split(',')[0].split('-');
                var date = new Date(dateConvert[2]+'/'+dateConvert[0]+'/'+dateConvert[1]);
                topSummaryData.dateOfAbnormalEvent = monthNames[date.getMonth()]+"  " +date.getDate()+", "+date.getFullYear();                */
                var dateconvert=caseList[i].latestAlertDate.substring(4,6)+'/'+caseList[i].latestAlertDate.substring(6,8)+'/'+caseList[i].latestAlertDate.substring(0,4)
                topSummaryData.dateOfAbnormalEvent= $filter('date')(new Date(dateconvert), 'MMM dd, yyyy');
                topSummaryData.firstName = summaryData.agentFirstName;
                topSummaryData.lastName = summaryData.agentLastName;
                topSummaryData.country = summaryData.agentCountryName;
                topSummaryData.lattitude = caseList[i].latitude;
                topSummaryData.longitude = caseList[i].longitude;
                topSummary[i] = topSummaryData;
            }
        }
        topSummaryJson.topSummary = topSummary;
    }
    $scope.topSummaryData = topSummaryJson; 
	  $rootScope.routedFromAllCases='no';
    //$rootScope.routedFromMycasesHomePage='no';
    if(topSummaryJson.topSummary.length == 0){
        $(".topSummary").hide();
    }
     $rootScope.caseDetailsFilterSelected = "no";
     $rootScope.allCaseFilterSelected = "no";
     $rootScope.alertDetailsFilterSelected = "no";
     $scope.topSummaryAndWorldMapData = topSummaryJson.topSummary; 
        
     var matchedID=[];
     var increment = 0;
     var matched = false;
     var topFiveData=angular.copy(topSummaryJson.topSummary);
    for(var i=0;i<topFiveData.length;i++)
    {
        var abEventDate=topFiveData[i].dateOfAbnormalEvent;
        var city=topFiveData[i].callCenterCity;
        var country=topFiveData[i].country;
        var userAttId=topFiveData[i].attID;
        var probabilityScore=Math.round(topFiveData[i].probabilityScore*100);
        matched = false;
        var tempData = '';
        var matchedData=topFiveData[i];
               
        
        for(var j=i+1;j<topFiveData.length;j++)
        {
            
         if(city === topFiveData[j].callCenterCity && country === topFiveData[j].country && topFiveData[j].compared===undefined)
            {
                matched = true;
                var matchedEmployeePS=Math.round(topFiveData[j].probabilityScore*100);
                topFiveData[j].compared="true";
               
                if(probabilityScore > matchedEmployeePS)
                {
                   tempData =   matchedData;                       
                }else{
                    tempData =   topFiveData[j];
                }
                                  
                
            } 
           
        }
       if(matched === true){
       matchedID[increment]=tempData;
           increment = increment+1; 
    }else if(topFiveData[i].compared===undefined){
        matchedID[increment]=topFiveData[i];
           increment = increment+1; 
    }
       
       
    } 
   
    $scope.WorldMapData=matchedID;
    
        
    $scope.allPriorityAlerts=[
    {
        'misUseDate':'',
        'misUseDay':'YESTERDAY',
        'misUsePercentage':''
    },
    {
        'misUseDate':'',
        'misUseDay':'TODAY',
        'misUsePercentage':''
    }];
$scope.init=function()
    {
        topSummaryFactory.getUserPermissions().then(function(data){
           $scope.permissions = data.componentPermissionMap;
            if(!$scope.permissions.IT_CASE_MGT.view){
                $state.go('error',{'id':""});
            }
            $scope.userEdit = $scope.permissions.IT_CASE_MGT.edit;
        });
    }
$scope.init();  
$scope.prorityData=false;

     topSummaryFactory.getAllPriorityData().then(function(data){

       var allPriorityData = data;  

        $scope.misUseLatestDate=  allPriorityData.latestDate;
        $scope.misUsePreviousDate=  allPriorityData.previousDate;
        $scope.misUseLatestDateAverage=Math.round(allPriorityData.latestDateAverage*100);
        $scope.misUsePreviouDatesAverage=Math.round(allPriorityData.previouDatesAverage*100);

        $scope.allPriorityAlerts[0].misUseDate=$scope.misUsePreviousDate;
        $scope.allPriorityAlerts[1].misUseDate=$scope.misUseLatestDate;
        $scope.allPriorityAlerts[0].misUsePercentage=$scope.misUsePreviouDatesAverage;
        $scope.allPriorityAlerts[1].misUsePercentage=$scope.misUseLatestDateAverage;
           

       $scope.prorityData=true;
  

     });

    
    
     $rootScope.hoverMap = function(attId,args){
      
         if(args==='out'){
               $('.'+attId).siblings().removeClass('bgHighlight');
               $('.'+attId).removeClass('bgHighlight');
             return false;
         }
       
          
         $.each($scope.topSummaryData.topSummary,function(ind,value){
            
            if(value.attID ===attId){ 
                $('.'+attId).siblings().removeClass('bgHighlight');
                
                $('.'+attId).addClass('bgHighlight');
            } 
             
         });
         
      },
                                 
      $rootScope.route = [
        {
            'url' : 'home',
            'name' : 'Home'
        },
      ];
    


    var params = {
			
      "loggedAttId":$rootScope.loggedAttId,
      "caseId": '',
      "alertType": [],
      "suspectUID": '',
      "alertProbabilityMinimum": '',
      "alertProbabilityMaximum": '',
      "companyName":'' ,
      "location": [],
      "investigatorUId": [$rootScope.loggedAttId],
      "status": ["New", "Open", "Referred", "Recycled", "InProgress"],
      "caseDisposition" :[],
      "fromCreatedDateTime":'',
      "toCreatedDateTime":'',
      "fromLastUpdateDateTime":'',
      "toLastUpdateDateTime":''
		}


    
    $scope.currentPage = 1;
    $scope.tableData = {};
    $scope.tableData.headers = {
        'id' : 'CASE ID',
        'createdDateTime':'CREATED DATE',
        'alertType' : 'ALERT TYPE',
        'keyField' : 'SUSPECT UID',
        'countOfAlerts':'COUNT OF ALERTS',		
        'latestAlertDate':'RECENT ABNORMAL EVENT DATE',
        'maxProbability' : 'ALERT PROBABILITY',
        'mobility' : 'MOBILITY',
        'companyName' : 'COMPANY NAME',
        'locationSiteId' : 'LOCATION SITE ID',
        'status' : 'STATUS',
        'caseDisposition':'DISPOSITION',
        'investigatorId' : 'INVESTIGATOR UID'
    };
    
    topSummaryFactory.getMyCasesData(params).then(function(data){
  		$rootScope.loading = false;
       $scope.result = true;

      $scope.serviceData = data.serviceResult;
     

      $scope.tableData.tbody = {};
   
      var data= data.casePage.content;
      var myCasesWithoutClosed=[];
      var k=0;
    
//      for(var j=0;j<data.length;j++){
//    
//        if(data[j].caseStatusType.name !== 'Closed'){
//          myCasesWithoutClosed[k]=data[j];
//          k++;
//        }
//      }
      
       if(data.length>10){
           data = data.slice(0, 10);
        }
//        else{
//
//          data = myCasesWithoutClosed;
//        }
////        if(data.length != 0){
//          $scope.result = true;
//          
//        }

  		$.each(data,function(i,v){
               
  		  v.alertType = v.alertType.name;
  		  v.status = v.caseStatusType.name;
//        if(v.caseDisposition)
//        {
//          v.caseDisposition=v.caseDisposition.name;
//        }
        
  			
  		  v.id ={
               'value': v.id,
              'html': $sce.trustAsHtml($compile("<a href='#/caseDetails/"+ v.id+"' onClick='setFlag()'>"+ v.id+"</a>")($scope)[0].outerHTML)  
            }
        v.maxProbability=parseFloat($filter('number')(v.maxProbability * 100 , 3));
         if(v.createdDateTime){
               var dateConvert  = v.createdDateTime.split(',')[0].split('-');
               v.createdDateTime = dateConvert[0]+'/'+dateConvert[1]+'/'+dateConvert[2];
            }
             if(v.latestAlertDate){
              v.latestAlertDate  = v.latestAlertDate.substring(4,6)+'/'+v.latestAlertDate.substring(6,8)+'/'+v.latestAlertDate.substring(0,4)
             } 
                 
      });
        
  	  $scope.tableData.tbody = data;	
		    
	  });
   
  window.setFlag=function(){
      $rootScope.routedFromMycasesHomePage='yes';
  }
  window.setFlagToAssign = function(){
      $rootScope.routedFromMycasesHomePage='no';
  }
    $scope.activeTab = 'cases';
    $scope.changeView = function(value){
      $scope.activeTab = value;
    }


    $scope.gotoMyCases = function(){
      $rootScope.routedtoMycasesTab='yes';
        casesService.setMyCasesSelected(true);
        $state.go("allCases");
    }
    
  }])

.controller('anomalyHomeCtrl', ['$scope','$rootScope','$http',
  function ($scope,$rootScope, $http) {

      $scope.isShow = false;
    
  }])


.controller('mainContentCtrl', ['$scope','$window','$document', function($scope,$window,$document){
  
    $scope.lftContent = function(openLeft){
        if(openLeft){
            $scope.openLeft = false;
        } else {
            $scope.openLeft = true;
        }
    };

    $scope.leftLoad = function(){

      $scope.sideHeight = $window.innerHeight - ( 75 + 50 + $document.find('header').height() + $document.find('footer').height() );
      $document.find('.sideInfo').height($scope.sideHeight);
    };

    $scope.leftLoad();

    $(window).resize(function(){
      $scope.leftLoad();
    });

}]);


