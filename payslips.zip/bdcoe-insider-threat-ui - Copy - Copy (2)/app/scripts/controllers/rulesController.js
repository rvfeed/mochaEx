angular.module('insiderApp')
.controller('rulesCtrl', ['$scope','$rootScope','$sce','rulePageFactory','$compile','topSummaryFactory','$state','dateTimeFactory' ,function($scope,$rootScope,$sce,rulePageFactory,$compile,topSummaryFactory,$state,dateTimeFactory){


        $rootScope.route = [
        {
            "url" : "home",
            "name" : "Home"
        },
        {
            "url" : "rules",
            "name" : "Rules"
        }
        ];

    $rootScope.fromGraph = "no";
    $scope.init=function()
    {
      topSummaryFactory.checkUserInUPM().then(function(data){
        if(data.upmCheck == "true"){
            $scope.isAdminUser=true;
        }
        topSummaryFactory.getUserPermissions().then(function(data){
           $scope.permissions = data.componentPermissionMap;
            if(!$scope.permissions.IT_RULES.view){
                $state.go('error',{'id':""});
            }
            $scope.loadRulePageData();
        });  
        });

    }
   
       $scope.currentPage = 1;
       $scope.tableData = {};
       $scope.tableData.headers = {	
                'edit'  : '',
               'ruleNumber' : 'RULE ID',
                'ruleName' : 'RULE NAME',
                'ruleColumn' : 'RULE COLUMN',
                'recycleDays': 'CASE RECYCLE LOGIC DAYS',
              /*'distinctCountField' : 'DISTINCT FIELD COUNT',*/
              'threshold' : 'THRESHOLD',
              'effectiveDate' : 'EFFECTIVE DATE',
              'expiryDate' : 'EXPIRY DATE',
              'createdDateTime' : 'CREATED DATE',
              'lastUpdatedDateTime' : 'LAST UPDATED'
 
       };
       $scope.loadRulePageData = function(){
        rulePageFactory.getRules().then(function(data){
            console.log(data.rulesInfoList.length)
            $scope.ruleInfo = data.rulesInfoList;
            $scope.totalRules=data.rulesInfoList.length;
            if(data.serviceResult.success ===true){
                    angular.forEach(data.rulesInfoList,function(value,key){
                              if($scope.permissions.IT_RULES.edit && $scope.isAdminUser){
                            value.edit = 
                                 {
                                   "value": '0',
                                   "html":  $sce.trustAsHtml($compile("<a title='id' onclick='updateModelValues(event)'  data-toggle='modal' data-rule = "+value.ruleNumber+" data-threshold = "+value.threshold+" data-timeFrame = "+value.timeFrameDays+" data-recycledays = "+value.recycleDays+" data-target='#myModal'><span class='glyphicon glyphicon-pencil' aria-hidden='true'></span></a>")($scope)[0].outerHTML)
                                };
                      }

                    });
            for(var i=0;i<$scope.totalRules;i++)
              {  
                $scope.ruleInfo[i].effectiveDate = dateTimeFactory.changeToLocalTimeFromDate($scope.ruleInfo[i].effectiveDate);
                $scope.ruleInfo[i].expiryDate = dateTimeFactory.changeToLocalTimeFromDate($scope.ruleInfo[i].expiryDate);
                $scope.ruleInfo[i].createdDateTime = dateTimeFactory.changeToLocalTimeFromDate($scope.ruleInfo[i].createdDateTime);
                $scope.ruleInfo[i].lastUpdatedDateTime = dateTimeFactory.changeToLocalTimeFromDate($scope.ruleInfo[i].lastUpdatedDateTime); 
                
              }       

                $scope.tableData.tbody  = data.rulesInfoList;            
                console.log($scope.tableData.tbody);
                 $(".rows-per-page label").text("Results per page");      

            }


        });
       }
        

         window.updateModelValues = function(event){
            $scope.rules = {			

            }; console.log($(event.currentTarget).attr('data-recycledays'))
             
            $scope.rules.treshold = parseFloat($(event.currentTarget).attr('data-threshold'));

            $scope.rules.timeframe = $(event.currentTarget).attr('data-timeframe');

            $scope.rules.ruleNumber = $(event.currentTarget).attr('data-rule');
             $scope.rules.recycleDays = $(event.currentTarget).attr('data-recycledays');

        }

        $scope.editRules = function(){
            console.log($scope.rules)
            rulePageFactory.editRules($scope.rules).then(function(){
                
                   // $scope.tableData.tbody[0]={ruleNumber:$scope.rules.ruleNumber,threshold:$scope.rules.treshold,timeFrameDays:$scope.rules.timeframe}
                    window.location.reload();
            });

        }

            $scope.currentPageActivity = 1;
             $scope.AcitivityLogtableData = {};
             $scope.rowsPerPageActivity = 10;
             $scope.AcitivityLogtableData.headers = {
              'ruleNumber' : 'RULE NUMBER',
              'updatedUser' : 'UID',              
              'updatedDateTime' : 'UPDATED TIME',
              'eventType':'CHANGE TYPE',
              'change':'CHANGE'
             
          };


        rulePageFactory.getRuleHistorySummary().then(function(data){
            $scope.tableOptions = [{ name:"10", selected: true },{ name:"40" },{ name:"60" }]; 
              $('.activityLogTable  dynamic-table').remove();
              $('.activityLogTable').append($compile('<dynamic-table  filter-by="tableFilter" table-content="AcitivityLogtableData"  show-table-header="true" show-table-footer="hide" selectable-table-rows="false" per-page-options="tableOptions" current-page="currentPageActivity"  sorting="false"></dynamic-table>')($scope));
            
              /*$scope.activityData=data.dataList;*/
              $scope.activityData=data.settingsHistoryPage.content;
              for(var i=0;i<$scope.activityData.length;i++)
              {                
                $scope.activityData[i].updatedDateTime = dateTimeFactory.changeToLocalTimeFromDate($scope.activityData[i].updatedDateTime);
                $scope.activityData[i].ruleNumber = $scope.activityData[i].tablePK; 
                $scope.activityData[i].updatedUser = $scope.activityData[i].updatedBy; 
                
                if($scope.activityData[i].change){
                  //  debugger;
                   var str =  ($scope.activityData[i].change).split('|').join('<br>');
                    $scope.activityData[i].change=str.split(' ').join('&nbsp;&nbsp;') 
  /*                  $scope.activityData[i].change =  ($scope.activityData[i].change).replace(/(\||,)/g, '<br />');*/
                }
              }
            

            $scope.AcitivityLogtableData.tbody = $scope.activityData;
             $('.rows-per-page label').text('Results per page');

           });
        $scope.init();


}]);



