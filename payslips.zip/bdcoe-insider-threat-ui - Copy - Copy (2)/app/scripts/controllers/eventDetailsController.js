 'use strict';
 angular.module('insiderApp')
 .controller('eventDetailsCtrl', ['$rootScope','$stateParams','$scope','createNewCaseFactory','$state','dateTimeFactory',function($rootScope,$stateParams,$scope,createNewCaseFactory,$state,dateTimeFactory){
   
$scope.eventId=$stateParams.alertId;
dateTimeFactory.lastPageLedger("eventDetails");
if($stateParams.alertId != null)
         $scope.suspId = $stateParams.alertId.split("_")[0];
     console.log($rootScope.fromGraph);
 $scope.AddtoCaseclick = function(){
     if($rootScope.fromGraph === "yes"){
          $scope.addAlertsArray = [];   
          $scope.addAlertsArray.push($stateParams.alertId)  
              $scope.newCaseInfo = {
                    "caseId": $stateParams.caseId,                                     
                    "alertId": $scope.addAlertsArray
              }
              $rootScope.loading = true;
          createNewCaseFactory.addAlertToCaseFromCaseDetails($scope.newCaseInfo).then(function(data){
                    $rootScope.loading = false;              
               // $scope.newCaseInstruction=data.value;
                //$scope.closeaddcasenote=true; 
                $scope.caseCreationData=data.value;
                $scope.casecreationMsg=data.value.split(':')[0];        
                if(data.value.split(':')[1] === undefined){
                    $scope.casecreationMsg = "Sorry, Unfortunately alerts can't be added to case ID due to the error: "+data.value;
                }else{
                    $scope.caseCreationID=data.value.split(':')[1].trim();
                }
              
                if($scope.caseCreationData)
                {
                  $scope.closeaddcasenote=true;
                  return false;
                }
            });
           
         
     }else{
        var suspId = ($stateParams.suspectId != "")?$stateParams.suspectId: $scope.suspId;
          $scope.addAlertsArray = [];   
          $scope.addAlertsArray.push($scope.eventId)  ;
              $scope.newCaseInfo = {
                    "suspectId": suspId, 
                    "startDate":"",
                    "endDate":"",                  
                    "alertIds": $scope.addAlertsArray
              }
              $rootScope.loading = true;
         
          createNewCaseFactory.creatNewCase($scope.newCaseInfo).then(function(data){
               
                $rootScope.loading = false;              
               // $scope.newCaseInstruction=data.value;
                //$scope.closeaddcasenote=true; 
                $scope.caseCreationData=data.value;
                $scope.casecreationMsg=data.value.split(':')[0];        
                if(data.value.split(':')[1] === undefined){
                    $scope.casecreationMsg = "Sorry, Unfortunately alerts can't be added to case ID due to the error: "+data.value;
                }else{
                    $scope.caseCreationID=data.value.split(':')[1].trim();
                }
              
                if($scope.caseCreationData)
                {
                  $scope.closeaddcasenote=true;
                  return false;
                }
            }); 
     }
     $rootScope.fromGraph === "no";
 }
           
         

        $scope.closeaddcasenoteClose=function(){
          $scope.closeaddcasenote=false;
            window.location.reload();
                    
      }
        $rootScope.routedFromEventDetails = "yes";
     setTimeout(function(){
    if($rootScope.routedFromCreateNewCase === 'yes'){

         $rootScope.route = [
            {
                "url" : "home",
                "name" : "Home"
            },
              {
                "url" : "allCases",
                "name" : "All Cases"                                           
            },
            {
                "url" : "createNewCase",
                "name" : "New Case"                                          
            },

            {
                "url" : "eventDetails",
                "name" : "Event Details"  

            }
          
            ];

    }else if($rootScope.routedFromAllAlerts === 'yes'){
           $rootScope.route = [
            {
                "url" : "home",
                "name" : "Home"
            },{
                "url" : "alerts",
                "name" : "All Alerts" 
            },{
                "url" : "eventDetails",
                "name" : "Event Details"  
            }
          
            ];
    }
    else{
        $rootScope.route = [
            {
                "url" : "home",
                "name" : "Home"
            },
              {
                "url" : "allCases",
                "name" : "All Cases"                                           
            },
            {
                "url" : "caseDetails({'caseId' : '"+$stateParams.caseId+"'})",
                "name" : "Case Detail"                                           
            },

            {
                "url" : "eventDetails",
                "name" : "Event Details"  

            }
          
            ];
    }


            $rootScope.$apply();


},2000);




        
  }]);