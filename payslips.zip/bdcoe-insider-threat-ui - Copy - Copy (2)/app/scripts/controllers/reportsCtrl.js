angular.module('insiderApp')
.controller('reportsCtrl', ['$scope','$rootScope','getServiceURI','dateTimeFactory','topSummaryFactory','$state','caseDetailFactory',function($scope,$rootScope,getServiceURI,dateTimeFactory,topSummaryFactory,$state,caseDetailFactory){


	$rootScope.route = [
    {
        "url" : "home",
        "name" : "Home"
    },
    {
        "url" : "reports",
        "name" : "Reports"
    }
    ];
    $scope.report = {};
    $scope.report.reportDateRange = {
        'name' : '',
        'value' : ''
    };

    //new code for report
    $scope.Investigator = [{
          'name' : 'Investigator Id'
     }];

         
    caseDetailFactory.getCaseOwners().then(function(data){
        
        var caseOwnersData = data;
              
        for(var i=0;i<caseOwnersData.caseManagerList.length;i++){               
        
            $scope.Investigator.push({'name':caseOwnersData.caseManagerList[i].attUserId}) ;
            
        }   
    
    });

    
    //end new code
    $scope.init=function()
    {
        topSummaryFactory.checkUserInUPM().then(function(data){
        if(data.upmCheck == "true")
            $scope.isAdminUser=true;
        else
         $state.go('error',{'id':""});

        });

    }

   // $scope.myDate=new Date();
   // $scope.monthOptions = [{name:"Jan",value:0},{name:"Feb",value:1},{name:"Mar",value:2},{name:"Apr",value:3},{name:"May",value:4},{name:"Jun",value:5},{name:"Jul",value:6},{name:"Aug",value:7},{name:"Sep",value:8},{name:"Oct",value:9},{name:"Nov",value:10},{name:"Dec",value:11}];
    
   // $scope.selectedMonth = $scope.monthOptions[$scope.myDate.getMonth()];
    var formattedRange = $scope.report.reportDateRange.value;
   
    $scope.csv = getServiceURI.build('insiderThreat', 'exportAllCases')+"/"+($scope.report.reportDateRange.value+1);
        
//        $scope.$watch('selectedMonth', function(newValue){
//         $scope.csv = getServiceURI.build('insiderThreat', 'exportAllCases')+"/"+(newValue.value+1);
//         console.log("*************",$scope.csv );
//        });
    $scope.getReport = function(){
        var reportDate=[];
        reportDate = dateTimeFactory.getDateRangesFromRawDatesAsString($scope.report.reportDateRange.name);
        

        if($scope.investigatorId.name=="Investigator Id"){
                 

            if($scope.report.reportDateRange.name.length == 0){
                reportDate = ["",""];
                $(".form-element").addClass("customRequired");
                //$scope.csv = "./#";
                 return false;
                 }else{
                     $(".form-element").removeClass("customRequired");
                   
                     var emptyval="";
                
                 /*location.href = getServiceURI.build('insiderThreat', 'exportAllCases')+"/"+(reportDate[0]+"/"+reportDate[1]);*/
                 /* location.href = getServiceURI.build('insiderThreat', 'exportAllCases')+"/"+(emptyval)+"/"+(reportDate[0]+"/"+reportDate[1]);*/
                   location.href = getServiceURI.build('insiderThreat', 'exportAllCases')+"/"+(reportDate[0]+"/"+reportDate[1])+"?investigatorId="+emptyval;
                 }


        }else{
            if($scope.report.reportDateRange.name.length == 0){
            reportDate = ["",""];
            $(".form-element").addClass("customRequired");
            //$scope.csv = "./#";
            return false;
        }else{
            $(".form-element").removeClass("customRequired");
            location.href = getServiceURI.build('insiderThreat', 'exportAllCases')+"/"+(reportDate[0]+"/"+reportDate[1])+"?investigatorId="+($scope.investigatorId.name);
        }



        }
        
        
    }
   $scope.init();
   
}]);



