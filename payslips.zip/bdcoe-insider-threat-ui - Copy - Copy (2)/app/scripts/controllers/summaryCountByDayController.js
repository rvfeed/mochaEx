 'use strict';
angular.module('insiderApp')
.controller('summaryCountByDayCtrl', ['getUserPhoto','$scope','$rootScope','$http','caseDetailFactory','$interval','$stateParams','dateFilter','$sce','$compile','$filter','createNewCaseFactory',
  function (getUserPhoto,$scope,$rootScope, $http,caseDetailFactory,$interval,$stateParams,dateFilter,$sce,$compile,$filter,createNewCaseFactory) {
    
   $rootScope.loading = true;
    $scope.showInvestigate = false;
      var graphData,minimum=0,maximum=30;
      var  lArrayX,lArrayY;
 
    $scope.top = {
      
    };

    
    
 /*   
      $scope.mouseenter=function(){
         this.bookmarkHoveShow = true;
       };
      $scope.mouseleave=function(){
          this.bookmarkHoveShow = false;
        };


        $scope.onPageChange = function(page){
          alert('current page = ' + page);
        };
            */  
      $scope.eightdayData = true;
     
      //$rootScope.notes = false;

     var margin = {top: 20, right: 100, bottom: 30, left: 100},
            width = $(".slider").width(),
            height =  $("#svgDv ").height() - margin.top - margin.bottom;



        $scope.activeInfo = 'events';
        $scope.$emit('sendingToCSV', $scope.activeInfo);
 

  $rootScope.getGraphDataCaseDetails = function(){


    caseDetailFactory.getGraphDetailData($rootScope.suspectId).then(function(data){
    //console.log("$scope.top.attID 3235325++++",$stateParams.attID );
        
$rootScope.loading = false;
    
var sixtyDayData = {

    };

    sixtyDayData.clarifyUniqueAccessCount = [];
    sixtyDayData.telegenceUniqueAccessCount = [];
    sixtyDayData.clarifySiteAvgUniqueAccessCount = [];
    sixtyDayData.telegenceSiteAvgUniqueAccessCount = [];
      
 
$.each(data.summaryUIDataList,function(i,v){
        sixtyDayData.clarifyUniqueAccessCount.push({

            "date":v.date,
            "count":v.clarifyUniqueAccessCount,
            "eventId" : v.id

          

            });
        sixtyDayData.telegenceUniqueAccessCount.push({

            "date":v.date,
            "count":v.telegenceUniqueAccessCount,
            "eventId" : v.id


        });
      
       sixtyDayData.clarifySiteAvgUniqueAccessCount.push({

            "date":v.date,
            "count":v.clarifySiteAvgUniqueAccessCount,
            "eventId" : v.id

            });
        sixtyDayData.telegenceSiteAvgUniqueAccessCount.push({

            "date":v.date,
            "count":v.telegenceSiteAvgUniqueAccessCount,
             "eventId" : v.id
           

        });

    });



     // $scope.employee = data.activityLog;
      $scope.data = sixtyDayData;
      var jsonstr = JSON.stringify($scope.data);
 
    // HERE you do the transform
   // var new_jsonstr = jsonstr.replace('"callCount"', '"data1"').replace('"accountAccessCount"', '"data2"').replace('"uniqueAccessCount"','"data3"').replace('"clarifySiteAccessCount"','"data4"');

   var new_jsonstr = jsonstr.replace('"clarifyUniqueAccessCount"', '"data1"').replace('"telegenceUniqueAccessCount"', '"data2"').replace('"clarifySiteAvgUniqueAccessCount"','"data3"').replace('"telegenceSiteAvgUniqueAccessCount"','"data4"');
    // You probably want to parse the altered string later
    $scope.data = JSON.parse(new_jsonstr);
         graphData = $scope.data;
           var format = d3.time.format("%m-%d-%Y");

          $.each( $scope.data,function(i,v){

             $.each(v,function(ind,val){
              
              val.count =+ val.count;
              val.date = val.date.substring(4,6) +'-'+ val.date.substring(6,8) +'-'+val.date.substring(0,4);
              val.date = format.parse(val.date);
         })
          
          
      });
     localStorage.maximum = "30";
      $scope.slider();

     
  dataRender($scope.data,"30","0","0");
     
   


  /*$.each(data.summaryUIDataList, function(i,v){


        v.date = new Date(parseInt(v.date.substring(0,4)), parseInt(v.date.substring(4,6))-1,parseInt(v.date.substring(6,8)));
        v.date = dateFilter(v.date,'mediumDate');


        v.date ={
              'value': (new Date(v.date)).getTime(),

              'html': $sce.trustAsHtml('<a href="#/anomalyEvent/'+ $scope.top.attID+'/'+ $scope.top.firstName+'/'+ $scope.top.lastName+'/'+ $scope.top.callCenterCity+'/'+$scope.top.callCenterState+'/'+$scope.top.country+'/'+v.date+'/'+v.anomalyProbability+'/'+$scope.top.agentEmail+'/'+$scope.top.agentPhone+'/'+$scope.top.agentManagerAttUserId+'/'+$scope.top.agentManagerFirstName+'/'+$scope.top.agentManagerLastName+'/'+$scope.top.agentManagerEmail+'/'+$scope.top.agentManagerPhone+'/'+$scope.top.agentStreet+'/'+$scope.top.agentZip+'/'+$scope.top.agentManagerManagerAttUserId+'">'+ v.date+'</a>')

             }
        v.id ={
                'value': v.id,
                'html': $sce.trustAsHtml('<a style="position : relative !important;text-decoration:underline" href="#/alertDetails/'+ $rootScope.alertId+'/'+ $scope.attID+'" >'+v.id.value+'</a>')

                };
    if(i===data.summaryUIDataList.length-1){
        $(".rows-per-page label").text("Results per page");
       $scope.tableData.tbody = data.summaryUIDataList;
    setTimeout(function(){
      
      $('.th-date').trigger('click');
      $('.th-date').trigger('click');
      
    },1000);
    
    }
    //$rootScope.loading = false;
      });*/

         var el = '<span style="position:absolute;left:0%" ></span >';
             
            $('.sliderLabels').append(el);
                var el = '<span style="position:absolute;right:0%"></span >';
             
            $('.sliderLabels').append(el);
                var el = '<span style="position:absolute;left:0%" >'+ $scope.getMonth('min') + " " + $scope.getDay('min')+ '</span >';
             
            $('.sliderLabels').append(el);
                var el = '<span style="position:absolute;right:0%">'+ $scope.getMonth('max') + " " + $scope.getDay('max')+ '</span >';
             
            $('.sliderLabels').append(el);
          
        
             dataRender($scope.data,"30","0","22");
            
       
       
        
     if( $(".slider").slider("option", "max")-$(".slider").slider("option", "values")[0] >2){
           $('.sliderLabels span:first-child').text($scope.getMonth('min') + " " +$scope.getDay('min')).css('position','absolute').css('left',$($('.ui-slider').find('span')[0]).css('left'));
        
      }
    else
        {
           $('.sliderLabels span:first-child').text(' ');
          
        }
        
     if( $(".slider").slider("option", "max")-$(".slider").slider("option", "values")[1] >2){
          $('.sliderLabels span:nth-child(2)').text($scope.getMonth('max') + " " +$scope.getDay('max')).css('position','absolute').css('left',$($('.ui-slider').find('span')[1]).css('left'));
        
      }
    else
        {
          $('.sliderLabels span:nth-child(2)').text(' ');
          
        }
     
         
      });   
  }


 
      $scope.changeData = function(argst){
                          
          $("#svgDv").empty();
          
          if(argst=="30")
          {
                    $scope.eightdayData = true;
                  
                     localStorage.maximum = "30";
                   $('.sliderLabels').empty();
                       var el = '<span style="position:absolute;left:0%" ></span >';
             
            $('.sliderLabels').append(el);
            var el = '<span style="position:absolute;right:0%"></span >';
             
            $('.sliderLabels').append(el);
                  
                     $scope.slider();
              
      dataRender($scope.data,"30","0","0");
                       var el = '<span style="position:absolute;left:0%" >'+ $scope.getMonth('min') + " " +$scope.getDay('min')+ '</span >';
             
            $('.sliderLabels').append(el);
                var el = '<span style="position:absolute;right:0%">'+ $scope.getMonth('max') + " " +$scope.getDay('max')+ '</span >';
             
            $('.sliderLabels').append(el);
                 dataRender($scope.data,"30","0","22");
                      $('.sliderLabels span:first-child').text($scope.getMonth('min') + " " +$scope.getDay('min')).css('position','absolute').css('left',$($('.ui-slider').find('span')[0]).css('left'));
           
              }
           if(argst=="60")
              {
                    $scope.eightdayData = false;
                    localStorage.maximum = "60";
                     $('.sliderLabels').empty();
                         var el = '<span style="position:absolute;left:0%" ></span >';
             
            $('.sliderLabels').append(el);
                 var el = '<span style="position:absolute;right:0%"></span >';
             
            $('.sliderLabels').append(el);
            
                     $scope.slider();
        
      dataRender($scope.data,"60","0",'0');
                      var el = '<span style="position:absolute;left:0%" >'+ $scope.getMonth('min') + " " +$scope.getDay('min')+ '</span >';
             
            $('.sliderLabels').append(el);
      var el = '<span style="position:absolute;right:0%">'+ $scope.getMonth('max') + " " +$scope.getDay('max')+ '</span >';
             
            $('.sliderLabels').append(el); 
             $('.sliderLabels span:first-child').text($scope.getMonth('min') + " " +$scope.getDay('min')).css('position','absolute').css('left',$($('.ui-slider').find('span')[0]).css('left'));
            
                  
              }
      
       if( $(".slider").slider("option", "max")-$(".slider").slider("option", "values")[0] >2){
           $('.sliderLabels span:first-child').text($scope.getMonth('min') + " " +$scope.getDay('min')).css('position','absolute').css('left',$($('.ui-slider').find('span')[0]).css('left'));
        
      }
    else
        {
           $('.sliderLabels span:first-child').text(' ');
          
        }
      
       if( $(".slider").slider("option", "max")-$(".slider").slider("option", "values")[1] >2){
          $('.sliderLabels span:nth-child(2)').text($scope.getMonth('max') + " " +$scope.getDay('max')).css('position','absolute').css('left',$($('.ui-slider').find('span')[1]).css('left'));
        
      }
      else
        {
          $('.sliderLabels span:nth-child(2)').text(' ');
          
        }
          
        
      }

      $rootScope.getGraphDataCaseDetails();
      
        $(".graphBtns a").on('click',function(event){
        
       
           if(!$(event.currentTarget).hasClass('selected')){
              
              $(event.currentTarget).addClass('selected');
              $(event.currentTarget).siblings('a').removeClass('selected');
             
          }
            else{
                
                return false;
            }
        
    });
     
      
    
          function dataRender(data,args,argsmax,argsmin)
          {
           // console.log('data: ', data,' ; args: ', args,' ; argsmax: ', argsmax,' ; argsmin: ', argsmin);
             /* var height = 400;
            var width = $("#svgDv").width();*/
             $rootScope.loading = false;
              var xScale;
              var dateArray = [];

              dateArray.push({
                    "date" : d3.max(data.data1, function(d){ return d.date; }),
                    "count" : d3.max(data.data1, function(d){ return d.count; }),

                  
                })  ;
              dateArray.push({
                "date" : d3.max(data.data2, function(d){ return d.date; }),
                "count" : d3.max(data.data2, function(d){ return d.count; })
                
            }) 
        
          dateArray.push({
                    "date" : d3.max(data.data3, function(d){ return d.date; }),
                    "count" : d3.max(data.data3, function(d){ return d.count; })
                   
                })  ;
              dateArray.push({
                "date" : d3.max(data.data4, function(d){ return d.date; }),
                "count" : d3.max(data.data4, function(d){ return d.count; })
                 
            }) 
        ;

                    
        var yScale = d3.scale.linear()
            .domain([0, d3.max(dateArray, function(d){ return d.count+100; })])
            .range([ height, 0]);

             var xAxis;         
              
                 
               $scope.maxDate1 = d3.max(dateArray, function(d){ return d.date; });
               $scope.minDate = new Date();
               $scope.minDate.setFullYear( $scope.maxDate1.getFullYear());
               $scope.minDate.setMonth( $scope.maxDate1.getMonth()); 
               $scope.maxDate = new Date();
               $scope.maxDate.setFullYear( $scope.maxDate1.getFullYear());
               $scope.maxDate.setMonth( $scope.maxDate1.getMonth()); 
               $scope.maxDate.setDate($scope.maxDate1.getDate()-argsmax);
               $scope.minDate.setMonth($scope.maxDate.getMonth()); 
          
              var yAxis = d3.svg.axis()
            .scale(yScale)
            .orient("left")
            .innerTickSize(-width)
            .outerTickSize(0)
            .tickPadding(10);
              
            setTimeout(function(){
                $($(".domain")[1]).css('stroke','none');
            },2);  

            var line ;
            
            $scope.minDate.setDate($scope.maxDate.getDate()-parseInt(args)+parseInt(argsmin)+1);
        
        var graphMinDate =new Date($scope.minDate.getTime()) ;
        
          graphMinDate.setDate($scope.minDate.getDate()-1);
              
            var spacing = (args-argsmin>=15) ? 3:1;
              xScale  = d3.time.scale()
         .range([0,  $(".slider").width()-100]).domain([graphMinDate,$scope.maxDate]);   
                 
                  xAxis  = d3.svg.axis()
            .scale(xScale)
            .orient("bottom").tickPadding(10).ticks(d3.time.days, spacing)
            .tickFormat(d3.time.format('%b %d'))
            .tickSize(10);

                          line  = d3.svg.line()
            .x(function(d) { return xScale(d.date); })
            .y(function(d) { return yScale(d.count); });
             

        $("#svgDv").empty();


        var svg = d3.select("#svgDv").append("svg")

            .attr("width", $(".topheading").width())
            .attr("height",  $("#svgDv").height())

          .append("g").attr('width',$(".topheading").width()) 
            .attr("transform", "translate(100,10)");

          svg.append("g")
            .attr("class", "x axis")
            .attr("transform", "translate(0," + height + ")")
            .call(xAxis)
            .selectAll("text") 
            .style("text-anchor", "end")
            .attr("dx", "-10px")
            .attr("dy", "-10px")
            .attr("transform", function(d) {
              return "rotate(-45)" 
          });



          svg.append("g")
              .attr("class", "y axis")
              .call(yAxis);

                     var g= svg.append("g");            
            g.append('path').data([[{
                "date" :graphMinDate,
                "count" :d3.max(dateArray, function(d){ return d.count+100; })
            },
            {
               "date" : $scope.maxDate,
               "count" : d3.max(dateArray, function(d){ return d.count+100; })
            }]]) .attr("class", "hline")
              .attr("d", line); 
          $.each(data,function(i,v){
          
           var g= svg.append("g");
            var tempObj = [];

             $.each(v,function(ind,val){

                if(val.date>=graphMinDate&&val.date<=$scope.maxDate){
                    tempObj.push(val);
                } 

             });
  
          getLineValues(tempObj);
                      if(graphMinDate<lArrayX){
                          g.append('path').data([[{
                "date" : lArrayX,
                "count" : 0
            },
            {
               "date" : lArrayX,
               "count" : lArrayY
                   
             }]]) .attr("class", "vline")
            .attr("d", line);  
          }

             g.append('path').data([tempObj])
                  .attr("class", "line"+i)
                  .attr("d", line);
         
            render(tempObj,g,i);
          
                    
      });
   
    function render(data,g,ind){

     //console.log('data: ', data,' ; g: ',g,' ; ind: ',ind);
    

    
        var color ;
        if(ind==="data1"){
            color = "#4ba80c";
        }
        else if (ind==="data2"){
            
              color = "#ffb81c";
        }
        else if (ind==="data3"){
              color = "#9062cd";
        }
    
    else if(ind==="data4"){
      
      color = "#009edb";
    }
    else
      {
        
        color = "#00ea9d";
        
      }
    
       var circles =  g.selectAll('circle').data(data);

            circles.enter().append('circle').attr('r','7').attr('fill',color).attr('name',function(d){return d.eventId;}).on('mouseover',function(e){
            $(this).on('click',function(event){
            
             $('.infowindow').show().offset({ top: $(window).scrollTop()+event.clientY-  $('.infowindow').height()*0.2, left:event.clientX + 20  });
                
                $('.infowindow').removeClass('lastDiv');

//$(".infowindow").text($(this).attr('data-eventId'));
$rootScope.alertId = $(this).attr('name');
                
                   if($('.infowindow').offset().left + $(".infowindow").width()>$(window).width()){
            $('.infowindow').show().offset({ top: $(window).scrollTop()+event.clientY- $('.infowindow').height()*0.2, left: event.clientX - 40-$(".infowindow").width()});
                        $('.infowindow').addClass('lastDiv');
                       
                     
                   }
        $scope.anomalyDate = dateFilter(event.target.__data__.date,'mediumDate');
       
       
        //$scope.anomalyCount = event.target.__data__.count;
        $scope.totalRecords =event.target.__data__.count;
        
         //new code
        createNewCaseFactory.checkalertId($rootScope.suspectId,$rootScope.alertId).then(function(data){
                     $rootScope.loading = false;
                     
                     if(data.status=="true"){
                        $rootScope.isaddToCase=false;

                     } else{

                      $rootScope.isaddToCase=true;
                     }                                       
                    console.log("data.status..."+data.status)                                         
                     
                     
             });

        //new code close.....
                

        //$scope.caseId = 'abcd';
      $rootScope.fromGraph = "yes";
      $('.orangeBtn').attr('href','#/eventDetails/'+$rootScope.alertId+'/'+$scope.attID+'/'+$rootScope.suspectId);
                
                
      //start of new code for Add to Case        
   $scope.AddtoCaseclick=function(){
          $scope.addAlertsArray = [];   
          $scope.addAlertsArray.push($rootScope.alertId)  
              $scope.newCaseInfo = {
                    "caseId": $stateParams.caseId,                                     
                    "alertId": $scope.addAlertsArray
              }
              $rootScope.loading = true;
         
          createNewCaseFactory.addAlertToCaseFromCaseDetails($scope.newCaseInfo).then(function(data){
               
                $rootScope.loading = false;              
                $rootScope.newCaseInstruction=data.value;
                $rootScope.closeaddcasenote=true; 
          
        
            });
           
       }  
      $rootScope.closeaddcasenoteClose=function(){
          $rootScope.closeaddcasenote=false;
           window.location.reload();
          
      }
      
   // end of new code           
                
        $scope.$apply(function(){
                
        $scope.showInvestigate = true;
          
        });
        

                 });
             
            });
     
            circles.attr('cx',function(d){return xScale(d.date);}).attr('cy',function(d){return yScale(d.count);});
            
            circles.exit().remove();

    }
      
      function getLineValues(dataX){
          
       var maxy=  d3.max(dataX, function(d){ return d.count; })
          
           $.each(dataX,function(ind,val){
               
               if(val.count==maxy){
                   
                   lArrayX = val.date;
                   lArrayY =  d3.max(dateArray, function(d){ return d.count+100;});
                   return false;
                   
               }
       
           });
          
      } 
      
      }

   $scope.slider = function(event){
          $('#datepicker').datepicker();
       
  $('.slider').slider({
  range: true,
        values: [ 1, parseInt(localStorage.maximum)],
        min : 1,
        max :parseInt(localStorage.maximum),
    
    
          step: 1,
         start : function(event){
      
      $scope.minsliderValue = $(".slider").slider("option", "values")[0];
      
      $scope.maxsliderValue = $(".slider").slider("option", "values")[1];
            
         
            //$scope.maxDate1
       if($($(event.target).find('span')[0]).hasClass('ui-state-hover')){
                 $('#datepicker').datepicker("setDate", $scope.minDate);
                 $('#datepicker').show().offset({ top: $($(event.target).find('span')[0]).offset().top- $('#datepicker').height()- $('.slider').height(), left: $($(event.target).find('span')[0]).offset().left-10 });
            if($('#datepicker').offset().left + $("#datepicker").width()>$(window).width()){
                
                  $('#datepicker').show().offset({ top: $($(event.target).find('span')[0]).offset().top- $('#datepicker').height()- $('.slider').height(), left: $(window).width()-$("#datepicker").width() });
 
            }
                
            }
            if($($(event.target).find('span')[1]).hasClass('ui-state-hover')){
                 $('#datepicker').datepicker("setDate", $scope.maxDate);
               $('#datepicker').show().offset({ top: $($(event.target).find('span')[0]).offset().top- $('#datepicker').height()- $('.slider').height(), left: $($(event.target).find('span')[1]).offset().left-10 });
            if($('#datepicker').offset().left + $("#datepicker").width()>$(window).width()){
                
                  $('#datepicker').show().offset({ top: $($(event.target).find('span')[0]).offset().top- $('#datepicker').height()- $('.slider').height(), left: $(window).width()-$("#datepicker").width() });
                

            }
            }
              
                $.each($(".ui-datepicker-calendar").find('td'),function(ind,val){
           
          if(($(val).attr('data-year')==$scope.minDate.getFullYear()||$(val).attr('data-year')==$scope.maxDate.getFullYear()))
             {
              
            if($(val).attr('data-month')==$scope.minDate.getMonth())
                {
                 if($(val).find('a').text()>=$scope.minDate.getDate())
                     {
                         if($(val).attr('data-month')==$scope.maxDate.getMonth()){
                      if($(val).find('a').text()<=$scope.maxDate.getDate()){
                    
                        $(val).find('a').attr('style','color : #000');
                          
                      }
                    
                  }  
                         else{
                             
                        $(val).find('a').attr('style','color : #000');
                             
                         }
                         
                     }
      
                }
                 
                  if($(val).attr('data-month')>$scope.minDate.getMonth()&&$(val).attr('data-month')<$scope.maxDate.getMonth()){
                      
                     
                        $(val).find('a').attr('style','color : #000');
                      
                  }
                 if($(val).attr('data-month')==$scope.maxDate.getMonth())
                     {
                         
                        if(!($(val).attr('data-month')==$scope.minDate.getMonth())){
                             
                               if($(val).find('a').text()<=$scope.maxDate.getDate()){
                            
                        $(val).find('a').attr('style','color : #000');
                          
                                   
                               }
                             
                         }
                         
                         
                     }
                          

                }
              
              });
            

        },
        slide : function(event){
          
               $('#datepicker').hide();
           if($($(event.target).find('span')[0]).hasClass('ui-state-active')){
               
                $('.sliderLabels span:first-child').text(' ');
          
                 $('#datepicker').show().offset({ top: $($(event.target).find('span')[0]).offset().top- $('#datepicker').height()- $('.slider').height(), left: $($(event.target).find('span')[0]).offset().left});
            if($('#datepicker').offset().left + $("#datepicker").width()>$(window).width()){
                
                  $('#datepicker').show().offset({ top: $($(event.target).find('span')[0]).offset().top- $('#datepicker').height()- $('.slider').height(), left: $(window).width()-$("#datepicker").width() });
      
            }
                
            }
            if($($(event.target).find('span')[1]).hasClass('ui-state-active')){
                
                 $('.sliderLabels span:nth-child(2)').text(' ');
                 $('#datepicker').show().offset({ top: $($(event.target).find('span')[0]).offset().top- $('#datepicker').height()- $('.slider').height(), left: $($(event.target).find('span')[1]).offset().left});
            if($('#datepicker').offset().left + $("#datepicker").width()>$(window).width()){
                  $('#datepicker').show().offset({ top: $($(event.target).find('span')[0]).offset().top- $('#datepicker').height()- $('.slider').height(), left: $(window).width()-$("#datepicker").width() });
    
            }
            }
        },
        stop : function(d){
        
       $('#datepicker').hide();
      
        if($scope.minsliderValue === $(".slider").slider("option", "values")[0] &&$scope.maxsliderValue === $(".slider").slider("option", "values")[1])
          {
            return false;
            
          }

            dataRender(graphData,parseInt(localStorage.maximum)-(parseInt(localStorage.maximum)-$( ".slider" ).slider( "option", "values" )[1]),parseInt(localStorage.maximum)-$( ".slider" ).slider( "option", "values" )[1],$( ".slider" ).slider( "option", "values" )[0]-1);

       if($(".slider").slider("option", "max")-$(".slider").slider("option", "values")[0] >2){
           $('.sliderLabels span:first-child').text($scope.getMonth('min') + " " +$scope.getDay('min')).css('position','absolute').css('left',$($('.ui-slider').find('span')[0]).css('left'));
          
         }
         else
        {
           $('.sliderLabels span:first-child').text(' ');
          
        }
     
      if( $(".slider").slider("option", "max")-$(".slider").slider("option", "values")[1] >2){
          $('.sliderLabels span:nth-child(2)').text($scope.getMonth('max') + " " +$scope.getDay('max')).css('position','absolute').css('left',$($('.ui-slider').find('span')[1]).css('left'));
        
      }
      else
        {
          $('.sliderLabels span:nth-child(2)').text(' ');
          
        }

    }
});
     
    
      
  if(localStorage.maximum=="30")     
       {
           $( ".slider" ).slider( "option", "values" ,[22,30]);

       }
         
           $(".slider").css('margin-left',  '30px');
         
         $('.sliderLabels').show().css('width',$('.slider').width()).css('height',$('.slider').height()).offset({ top: $('.slider').offset().top+20, left:  $('.slider').offset().left });

     };
      
    
      
      $scope.getMonth = function(args){
          
          var x =(args=="max")?$scope.maxDate.getMonth():$scope.minDate.getMonth();
     var month ;
     switch(x){
             
         case 0 :
             
             month = "Jan";
             break;
        case 1 :
             
             month = "Feb";
             break;
             case 2 :
             
             month = "Mar";
             break;
             case 3 :
             
             month = "Apr";
             break;
             case 4 :
             
             month = "May";
             break;
             case 5 :
             
             month = "Jun";
             break;
             case 6 :
             
             month = "Jul";
             break;
             case 7 :
             
             month = "Aug";
             break;
             case 8 :
             
             month = "Sep";
             break;
             case 9 :
             
             month = "Oct";
             break;
             case 10 :
             
             month = "Nov";
             break;
             default :
             
             month = "Dec";
             
             
             
     }
          
          
          return month;
      };

         
     
    
            
           

      
      $scope.getDay= function(args){
          
          var x = (args=="min")? $scope.minDate.getDate():$scope.maxDate.getDate();
          
          return x;
          
          
          
      }

$scope.currentPage = 1;
      $scope.tableData = {};
      $scope.tableData.headers = {
        'date' : 'date',
        'anomalyProbability' : 'ANOMALY PROBABILITY',
        'telegenceClarifySiteAvgAccessCount' : 'TC Site Unique Avg Count',
        'telegenceClarifyUniqueAccessCount' : 'TC Unique Count',
        'clarifyUniqueAccessCount' : 'clarify unique access count',
        'telegenceUniqueAccessCount' : 'Telegence Unique access count',
        'clarifySiteAvgUniqueAccessCount' : 'Clarify site Unique access count ',
        'telegenceSiteAvgUniqueAccessCount' : 'Telegence Site Unique access count'
         
    
      
      };


      $scope.onPageChange = function (page) {

    $scope.currentPage = page;
   // $scope.updateTablePageNation();

    }
    $scope.onPerPageChange = function (perPageSelected) {
        $scope.rowsPerPage = perPageSelected.name;
       // $scope.updateTablePageNation( $scope.rowsPerPage);

    }

  
    
/*    $(document).ready(function(){
      
     $('body').on('click',function(event){
       
      
       if($(event.target).offset().top<$('.infowindow').offset().top){
         
         $('.infowindow').hide();
         
       }
       

     });
      
    });*/
              
   }]);
  