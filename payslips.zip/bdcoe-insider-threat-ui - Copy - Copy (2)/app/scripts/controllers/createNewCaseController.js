 'use strict';

angular.module('insiderApp')
.controller('createNewCaseCtrl', ['$scope','$rootScope','$http','createNewCaseFactory','getServiceURI','dateTimeFactory','$filter','$sce','caseDetailFactory','$compile','topSummaryFactory','$state','$timeout',
  function ($scope,$rootScope,$http,createNewCaseFactory,getServiceURI,dateTimeFactory,$filter,$sce,caseDetailFactory,$compile,topSummaryFactory,$state,$timeout) {
 
  
    $scope.newCase = {};
    $rootScope.routedFromCreateNewCase = 'yes';
    $rootScope.routedFromAllCases='no';

    $scope.newCase.selectedSuspectId = '';
    $scope.newCase.selectedDate = [];
    $scope.newCase.selectedDate = {
        	'name' : '',
        	'value' : ''
    };
    $scope.eventsRecords=0;
    $scope.bulkCloseArrayDuplicate=[];
    $('#bulkCloseBtn').attr('disabled','disabled');
    $scope.showTableHeader = true;
    $scope.hideRowNumbers  = false;
    $scope.currentPage = 1;
    $scope.rowsPerPage = 25;
    $scope.itemsPerPageOptions = [{ name:'25'},{ name:'40' },{ name:'60' }];
    
    $scope.sortField = "";
    $scope.sortDirec = "";

    $scope.setSortConditions = function(sortField,sortDirection){
      //console.log('setting the sort conditions in allCasesController to :',sortField,'::',sortDirection);
      $scope.sortField = sortField;
      $scope.sortDirec = sortDirection;

    }
    $scope.setCurrentPageWhenSorting = function(pageNumber){
     // console.log('setting current page to bcoz unequla sorting columns',pageNumber);
      $scope.currentPage =pageNumber;
    }
      $scope.onPageChange = function(page){
      $scope.currentPage = page;
      $scope.updateTableWithSorting($scope.sortField,$scope.sortDirec);
    }
      $scope.getRowCount = function(i){
      var total = $scope.rowsPerPage,
      currentPage = $scope.currentPage;
      i += currentPage > 1 ? (currentPage * total) - total + 1 : 1;
      i = i>$scope.totalRows?$scope.totalRows:i;
      return i;
    };

     $scope.onRowsPerPageChange = function (page ) {
      $scope.currentPage =1;
      $scope.rowsPerPage = page.name;
      $scope.createCase();
    }
             
    $rootScope.route = [
    {
            "url" : "home",
            "name" : "Home"
    },
    {
            "url" : "allCases",
            "name" : "All Cases" 
    },
    {
            "url" : "createNewCase",
            "name" : "New Case"
    }
    ];
    
    $scope.caseStatus = {
      "name":"status"
    }
     

  $scope.init=function()
  { //alert($.inArray($rootScope.lastPageLedger.lastPage, ["alertDetails", "eventDetails"]))
      if($rootScope.newCaseFilterSelected === "yes"){
          if($.inArray($rootScope.lastPageLedger.lastPage, ["alertDetails", "eventDetails"]) > -1){
            $scope.newCaseFilterData();
             $scope.createCase();
              dateTimeFactory.lastPageLedger("createNewCase");
          }
      }
      topSummaryFactory.checkBasicUserInUPM().then(function(data){
        if(data.upmCheck == "false")
        {
            $state.go('error',{'id':""});
        }
        });
      topSummaryFactory.getUserPermissions().then(function(data){
           $scope.permissions = data.componentPermissionMap;
            if(!$scope.permissions.IT_CASE_MGT.add){
                $state.go('error',{'id':""});
            }
      });
  };

  $scope.getCSVServiceLink = function(){
 
 
      $scope.newCaseDate=[];
      if( $scope.newCase.selectedDate.name.length){
            $scope.newCaseDate = dateTimeFactory.getDateRangesFromRawDates($scope.newCase.selectedDate.name);
        }else{
            $scope.newCaseDate = dateTimeFactory.getDateRanges($scope.newCase.selectedDate.value);
      }
      if($scope.newCase.selectedDate.name.length == 0){
            $scope.newCaseDate = ["",""];
      }
      if($scope.newCaseDate[0] !== "" &&($scope.newCaseDate[1] === undefined ||$scope.newCaseDate[1] === "") )
      {
          $scope.newCaseDate[1]=$scope.newCaseDate[0];
      }
      var minAlertProbability= $scope.newCase.min ? $scope.newCase.min : "";
      var maxAlertProbability= $scope.newCase.max ? $scope.newCase.max : "";   
      
      var alertIds = $("#selectedAlertsList").val();
        console.log("alertIds....."+alertIds)
        if(alertIds==undefined){
            alertIds="";
        }
      var link = getServiceURI.build('insiderThreat', 'exportManualCaseData')+ '/' +$rootScope.loggedAttId+'/'+'?&suspectId='+$scope.newCase.selectedSuspectId.toUpperCase()+'&startDate='+$scope.newCaseDate[0]+'&endDate='+$scope.newCaseDate[1]+'&minAlertProbability='+minAlertProbability+'&maxAlertProbability='+maxAlertProbability+'&status='+ null+'&alertIdsList='+alertIds;
 
      console.log("****",link);
      return link;
    };
  
  
    $scope.tableData = {};
    $scope.itemsPerPage ={};
    $scope.itemsPerPage = $scope.itemsPerPageOptions[0];
dateTimeFactory.lastPageLedger("createNewCase");
      console.log($rootScope.lastPageLedger);
  $scope.createCase=function() {
  $(".hasDatepicker").hide();  
  $scope.currentPage = 1;
  $rootScope.newCaseFilterSelected = "yes";
  if($scope.newCase.selectedSuspectId=="" || $scope.newCase.selectedSuspectId==undefined ){
      console.log("enter values");
       $('#myModal3').modal('show');
       
    }else{
  
      $rootScope.loading = true;

      $scope.newCaseDate=[];
      if( $scope.newCase.selectedDate.name.length){
            $scope.newCaseDate = dateTimeFactory.getDateRangesFromRawDates($scope.newCase.selectedDate.name);
        }else{
            $scope.newCaseDate = dateTimeFactory.getDateRanges($scope.newCase.selectedDate.value);
      }
      if($scope.newCase.selectedDate.name.length == 0){
            $scope.newCaseDate = ["",""];
      }
       if($scope.newCaseDate[0] !== "" &&($scope.newCaseDate[1] === undefined ||$scope.newCaseDate[1] === "") )
        {
          $scope.newCaseDate[1]=$scope.newCaseDate[0];
        }

   
      $scope.totalRecords;
      $scope.tableData.headers = {
      'alertId' : '',
      'id' : 'ALERT ID',
      'anomalyProbability' : 'ALERT PROBABILITY',
      'date' : 'DATE OF ACCESS',
       'accountsAccessed' : 'ACCOUNTS ACCESSED',
      'countOfCTNAccessed' : '# OF CTNS ACCESSED',
      'accountsNotedBySuspectId' : 'ACCOUNTS NOTED BY SUSPECT',
      'percentageNotedBySuspectId' : 'PERCENTAGE NOTED BY SUSPECT',
      'averageNumberOfBAN' : 'AVERAGE # OF BAN',
      'averageNumberOfCTN' : 'AVERAGE # OF CTNS',
      'mobility' : 'MOBILITY',
      'clarifyNoMemoCount' : 'CLARIFY NO MEMO COUNT',
      'telegenceNoMemoCount' : 'TELEGENCE NO MEMO COUNT'
    };
      
      
      var alertsArray = [];
        $scope.newCaseDateStart = $scope.newCaseDate[0];
        $scope.newCaseDateEnd = $scope.newCaseDate[1];
        $rootScope.newCaseDataFromFilter = [];
       $scope.newCaseInfo = {
            "suspectId": ($rootScope.newCaseDataFromFilter.length !== 0)? $rootScope.newCaseDataFromFilter[0].suspectId.toUpperCase() : $scope.newCase.selectedSuspectId.toUpperCase(),
            "startDate": ($rootScope.newCaseDataFromFilter.length !== 0)? $rootScope.newCaseDataFromFilter[0].startDate : $scope.newCaseDate[0],
            "endDate": ($rootScope.newCaseDataFromFilter.length !== 0)? $rootScope.newCaseDataFromFilter[0].endDate : $scope.newCaseDate[1],
            //New code
            "minAlertProbability":$scope.newCase.min ? ($rootScope.newCaseDataFromFilter.length !== 0) ? $rootScope.newCaseDataFromFilter[0].minAlertProbability : $scope.newCase.min : "",
            "maxAlertProbability":$scope.newCase.max ? ($rootScope.newCaseDataFromFilter.length !== 0)? $rootScope.newCaseDataFromFilter[0].maxAlertProbability : $scope.newCase.max : "",           
           //New code
            "alertIds": alertsArray
      }
       
       $rootScope.newCaseDataFromFilter.push(
       {
           "suspectId": $scope.newCase.selectedSuspectId.toUpperCase(),
            "startDate": $scope.newCaseDate[0],
            "endDate": $scope.newCaseDate[1],
            //New code
            "minAlertProbability":$scope.newCase.min ? $scope.newCase.min : "",
            "maxAlertProbability":$scope.newCase.max ? $scope.newCase.max : "",           
           //New code
            "alertIds": alertsArray
       })
       createNewCaseFactory.creatNewCase($scope.newCaseInfo,$scope.currentPage-1,$scope.rowsPerPage).then(function(data){
       // $scope.totalRecords=data.dataList.length;
        $scope.totalPages = data.totalPages;
        $scope.totalRecords = data.totalRecords;
        $scope.alertsSearchResults = data.dataList;
        if(data.dataList){
          $scope.totalRecords1=data.dataList.length;
          $scope.eventsRecords= $scope.totalRecords1;
        }
        else{
          if(!data.serviceResult.success){
            $scope.totalRecords1=0;
            $scope.eventsRecords= $scope.totalRecords1;
          }
          
        }
        $scope.csv = $scope.getCSVServiceLink();
        $scope.bulkCloseArrayDuplicate=[];
        $('#bulkCloseBtn').attr('disabled','disabled');
        $.each(data.dataList,function(i,v)
        {
          v.alertId ={
            'value': data.dataList[i].id,
            'html': $sce.trustAsHtml("<input type='checkbox' value= '"+ data.dataList[i].id+"' id=caseCheckbox"+i+"  class='createCaseCheckBox' style='position : relative !important;' onClick='appendAlertIdsinCreatePage()' />")
          }
           if(v.caseId !== null){
              v.alertId ={
                'value': data.dataList[i].id,
                'html': $sce.trustAsHtml("<input type='checkbox' value= '"+ data.dataList[i].id+"' id=caseCheckbox"+i+" class='createCaseCheckBox disableRow' style='position : relative !important;' onClick='appendAlertIdsinCreatePage()'/>")
              }
              v.id ={
                'value': data.dataList[i].id,
                'html': $sce.trustAsHtml('<a style="position : relative !important;text-decoration:underline" href="#/alertDetails/'+data.dataList[i].id+'/'+data.dataList[i].caseId+'" >'+data.dataList[i].id+'</a>')
             };
           }else{
              v.id ={
                'value': data.dataList[i].id,
                'html': $sce.trustAsHtml('<a style="position : relative !important;text-decoration:underline" href="#/eventDetails/'+data.dataList[i].id+'/'+ data.dataList[i].caseId+'/'+$scope.newCase.selectedSuspectId.toUpperCase()+'" >'+data.dataList[i].id+'</a>')
             };
           }
          data.dataList[i].anomalyProbability=parseFloat($filter('number')(data.dataList[i].anomalyProbability * 100 , 3));

              data.dataList[i].accountsAccessed=data.dataList[i].accountsAccessed.toString(); 
              data.dataList[i].countOfCTNAccessed=data.dataList[i].countOfCTNAccessed.toString(); 
              data.dataList[i].accountsNotedBySuspectId=data.dataList[i].accountsNotedBySuspectId.toString();
              data.dataList[i].percentageNotedBySuspectId=data.dataList[i].percentageNotedBySuspectId.toString();
         
              data.dataList[i].date=data.dataList[i].date.substring(4,6)+'/'+data.dataList[i].date.substring(6,8)+'/'+data.dataList[i].date.substring(0,4);

//              if(data.dataList[i].alertDisposition)
//              {
//                 data.dataList[i].alertDisposition=data.dataList[i].alertDisposition.name;
//              }   
            
        });
         $scope.tableData.tbody = data.dataList;
           $rootScope.loading = false;
          $timeout(function() {
             $("input.disableRow").parents("tr.ng-scope").find("td").css("background","#f2f2f2");
             appendAlertIdsinCreatePage();
             $rootScope.loading = false;
         },1000);
         });
    }
    }
  $scope.newCaseFilterData = function(){
       $scope.newCase.selectedSuspectId = $rootScope.newCaseDataFromFilter[0].suspectId;
       $scope.newCaseDateStart = $rootScope.newCaseDataFromFilter[0].startDate;
       $scope.newCaseDateEnd = $rootScope.newCaseDataFromFilter[0].endDate;
       $scope.newCase.min = $rootScope.newCaseDataFromFilter[0].minAlertProbability;
       $scope.newCase.max = $rootScope.newCaseDataFromFilter[0].maxAlertProbability;
       var date1 = $scope.newCaseDateStart ? $scope.newCaseDateStart.substring(4,6)+'/'+$scope.newCaseDateStart.substring(6,8)+'/'+$scope.newCaseDateStart.substring(0,4) : "";
       var date2 = $scope.newCaseDateEnd ? $scope.newCaseDateEnd.substring(4,6)+'/'+$scope.newCaseDateEnd.substring(6,8)+'/'+$scope.newCaseDateEnd.substring(0,4) : "";
       $scope.newCase.selectedDate.name = $scope.newCaseDateStart ? date1 + "-" + date2 : "";
  }
    $scope.closeCasePopupClose = function(){
      $scope.closeCasePopup = false;
      $scope.openCaseStatusPopup = false;
      $scope.closeCaseStatusPopup = false;
      $("input:checkbox").prop("checked",false);
      appendAlertIdsinCreatePage();
      $scope.caseStatus.name = false;
      $scope.createCase();
      
    }


     $scope.updateTableWithSorting = function(sortField,sortDirection) {
      $rootScope.loading = true;


      $scope.newCaseDate=[];
      if( $scope.newCase.selectedDate.name.length){
            $scope.newCaseDate = dateTimeFactory.getDateRangesFromRawDates($scope.newCase.selectedDate.name);
        }else{
            $scope.newCaseDate = dateTimeFactory.getDateRanges($scope.newCase.selectedDate.value);
      }
      if($scope.newCase.selectedDate.name.length == 0){
            $scope.newCaseDate = ["",""];
      }
       if($scope.newCaseDate[0] !== "" &&($scope.newCaseDate[1] === undefined ||$scope.newCaseDate[1] === "") )
        {
          $scope.newCaseDate[1]=$scope.newCaseDate[0];
        }

        var alertsArray = [];
       $scope.newCaseInfo = {
            "suspectId": $scope.newCase.selectedSuspectId.toUpperCase(),
            "startDate": $scope.newCaseDate[0],
            "endDate": $scope.newCaseDate[1],
            //New code
            "minAlertProbability":$scope.newCase.min ? $scope.newCase.min : "",
            "maxAlertProbability":$scope.newCase.max ? $scope.newCase.max : "",                        
           //New code
            "alertIds": alertsArray
      }
      
      createNewCaseFactory.creatNewCaseWithSorting($scope.newCaseInfo,$scope.currentPage-1,$scope.rowsPerPage,sortField,sortDirection).then(function(data){
      
       // $scope.totalRecords=data.dataList.length;
         $scope.totalPages = data.totalPages;
        $scope.totalRecords = data.totalRecords;
       $scope.alertsSearchResults = data.dataList;
        if(data.dataList){
          $scope.totalRecords1=data.dataList.length;
          $scope.eventsRecords= $scope.totalRecords1;
        }
        else{
          if(!data.serviceResult.success){
            $scope.totalRecords1=0;
            $scope.eventsRecords= $scope.totalRecords1;
          }
          
        }
        $scope.bulkCloseArrayDuplicate=[];
        $('#bulkCloseBtn').attr('disabled','disabled');
        $.each(data.dataList,function(i,v)
        {


          v.alertId ={
            'value': data.dataList[i].id,
            'html': $sce.trustAsHtml("<input type='checkbox' value= '"+ data.dataList[i].id+"' id=caseCheckbox"+i+"  class='createCaseCheckBox' style='position : relative !important;' onClick='appendAlertIdsinCreatePage()'/>")
          };
          if(v.caseId !== null){
              v.alertId ={
                'value': data.dataList[i].id,
                'html': $sce.trustAsHtml("<input type='checkbox' value= '"+ data.dataList[i].id+"' id=caseCheckbox"+i+" class='createCaseCheckBox disableRow' style='position : relative !important;' onClick='appendAlertIdsinCreatePage()'/>")
              }
              v.id ={
                'value': data.dataList[i].id,
                'html': $sce.trustAsHtml('<a style="position : relative !important;text-decoration:underline" href="#/alertDetails/'+data.dataList[i].id+'/'+ data.dataList[i].caseId+'" >'+data.dataList[i].id+'</a>')
             };
           }else{
              v.id ={
                'value': data.dataList[i].id,
                'html': $sce.trustAsHtml('<a style="position : relative !important;text-decoration:underline" href="#/eventDetails/'+data.dataList[i].id+'/'+ data.dataList[i].caseId+'/'+$scope.newCase.selectedSuspectId.toUpperCase()+'" >'+data.dataList[i].id+'</a>')
             };
           }
          data.dataList[i].anomalyProbability=parseFloat($filter('number')(data.dataList[i].anomalyProbability * 100 , 3));

              data.dataList[i].accountsAccessed=data.dataList[i].accountsAccessed.toString(); 
              data.dataList[i].countOfCTNAccessed=data.dataList[i].countOfCTNAccessed.toString(); 
              data.dataList[i].accountsNotedBySuspectId=data.dataList[i].accountsNotedBySuspectId.toString();
              data.dataList[i].percentageNotedBySuspectId=data.dataList[i].percentageNotedBySuspectId.toString();
         
              data.dataList[i].date=data.dataList[i].date.substring(4,6)+'/'+data.dataList[i].date.substring(6,8)+'/'+data.dataList[i].date.substring(0,4);

//              if(data.dataList[i].alertDisposition)
//              {
//                 data.dataList[i].alertDisposition=data.dataList[i].alertDisposition.name;
//              }   
            
        });
        $scope.tableData.tbody = data.dataList;
        $rootScope.loading = false;
        $timeout(function() {
             $("input.disableRow").parents("tr.ng-scope").find("td").css("background","#f2f2f2");
            appendAlertIdsinCreatePage();
             $rootScope.loading = false;
         },1000);
         });


    };

    $scope.addAlertsToCreateACase=function()
    {

      $scope.addAlertsArray = [];
       $rootScope.loading = true; 
        var canAddAlerts = true;
        for(var i=0;i<$scope.totalRecords;i++){
        if($('#caseCheckbox'+i).prop('checked')){
             $.each($scope.alertsSearchResults,function(j,v)
            {
             if(v.alertId.value === $('#caseCheckbox'+i).val())
             {
                if(v.caseId!= null){
                    $('#myModal4 .modal-body').html("Selected alerts are already assigned to the case "); 
                    $('#myModal4').modal('show');
                    canAddAlerts = false;
                }    
             }   
            });
          $scope.addAlertsArray.push($('#caseCheckbox'+i).val());
        }
      };
        if(!canAddAlerts){
            $rootScope.loading = false; 
            return false;
        }
       if($scope.newCaseDate[0] !== "" &&($scope.newCaseDate[1] === undefined ||$scope.newCaseDate[1] === "") )
        {
          $scope.newCaseDate[1]=$scope.newCaseDate[0];
        }

       
      $scope.newCaseInfo = {
            "suspectId": $scope.newCase.selectedSuspectId.toUpperCase(),
            "startDate": $scope.newCaseDate[0],
            "endDate": $scope.newCaseDate[1],
            //New code
           "minAlertProbability":$scope.newCase.min ? $scope.newCase.min : "",
            "maxAlertProbability":$scope.newCase.max ? $scope.newCase.max : "",                     
           //New code
            
            "alertIds": $scope.addAlertsArray,
            "status" : ""
      }

      console.log("new case info****************",$scope.newCaseInfo);
      createNewCaseFactory.creatNewCase($scope.newCaseInfo).then(function(data){
        $rootScope.loading = false; 
        $scope.caseCreationData=data.value;
        $scope.casecreationMsg=data.value.split(':')[0];
        $scope.caseCreationID=data.value.split(':')[1].trim();
        $rootScope.routedFromAllCases = 'yes' ;
        if(($scope.casecreationMsg).toLowerCase().indexOf("closed")!== -1){
            $scope.openCaseStatusPopup = true;
                 // $('#myModal2').modal('show');
                return false;
        }else{
                $scope.closeCasePopup=true;
                return false;
        }
      });
      $scope.caseStatusOptions=function(){
        if($scope.caseStatus.name === "New"){
            $scope.newCaseInfo.status = "new";
            //console.log($scope.newCaseInfo.status)
          }else if($scope.caseStatus.name === "Recycle"){
            $scope.newCaseInfo.status = "recycled";
            //console.log($scope.newCaseInfo.status)
          }
        if($scope.permissions.IT_CASE_MGT.add){
          $('#caseCreateButton').removeAttr("disabled");
           }
          console.log($scope.newCaseInfo.status)
      }
      $scope.createCaseWithOptions = function(){
          $scope.openCaseStatusPopup = false;
          $rootScope.loading = true; 
          createNewCaseFactory.creatNewCase($scope.newCaseInfo).then(function(data){
          
          $scope.caseCreationData=data.value;
          $scope.casecreationMsg=data.value.split(':')[0];
          $scope.caseCreationID=data.value.split(':')[1].trim();
          $rootScope.routedFromAllCases = 'yes' ;
          $rootScope.routedFromMycasesHomePage ='yes'
          $rootScope.loading = false;
          $scope.closeCaseStatusPopup = true ;
          //$('#myModal1').modal('show');
          //console.log("haaa"+$scope.caseCreationData);
         });
      }

      console.log("new case info after case creation****************",$scope.newCaseInfo);
      //end of new code

        $scope.bulkCloseArrayDuplicate=[];
        $('#bulkCloseBtn').attr('disabled','disabled');

      /*  createNewCaseFactory.getEventDetailsData($scope.newCase.selectedSuspectId,$scope.newCaseDate[0],$scope.newCaseDate[1]).then(function(data){
      
        $scope.totalRecords=data.dataList.length;
        $scope.bulkCloseArrayDuplicate=[];
        $('#bulkCloseBtn').attr('disabled','disabled');
        $.each(data.dataList,function(i,v)
        {
          v.caseId ={
            'value': data.dataList[i].id,
            'html': $sce.trustAsHtml("<input type='checkbox' value= '"+ data.dataList[i].id+"' id=caseCheckbox"+i+"  class='allCaseCheckbox' style='position : relative !important;' />")
          };
        });
         $scope.tableData.tbody = data.dataList;

      });
*/


    }
    function appendAlertIdsinCreatePage(){ 

    var alertids = [];    
    $(".createCaseCheckBox").each(function( index ) {    
        if($(this).is(":checked")){   
            alertids.push($(this).val());   
        }   
    });     
    var downloadLink = $scope.csv;    
    if(downloadLink && downloadLink.indexOf("&alertIdsList") > -1 ){    
     var splitLink = downloadLink.split("&alertIdsList");   
        downloadLink = splitLink[0];    
    }   
        
    if(alertids.length){            
      downloadLink = downloadLink +'&alertIdsList='+alertids.toString();    
      $("#selectedAlertsList").val(alertids.toString())   
    }else{    
      downloadLink = downloadLink +'&alertIdsList=';    
      $("#selectedAlertsList").val('');       
    }   
        
        
     $scope.csv =   downloadLink;
    //$("#downloadCSV").attr("href",downloadLink);    
    console.log("downloadLink"+downloadLink);   
 }
    
    $scope.init();


     

}]);


 