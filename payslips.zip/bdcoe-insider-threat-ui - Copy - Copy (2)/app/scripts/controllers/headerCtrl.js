angular.module('insiderApp')
.controller('headerCtrl', ['$scope','$rootScope','$http', function ($scope,$rootScope,$http) {
 
 }
 ]);