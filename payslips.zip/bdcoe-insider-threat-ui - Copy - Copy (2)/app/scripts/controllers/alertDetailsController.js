 'use strict';
 angular.module('insiderApp')
  .controller('alertDetailsCtrl', ['$scope','$rootScope','$state','alertDetailsFactory','caseDetailFactory','$stateParams','getServiceURI','$filter','componentService','$compile','dateTimeFactory','$q','$sce','$window','$document','topSummaryFactory','$timeout','dispositionFactory', 'createNewCaseFactory',function($scope,$rootScope,$state,alertDetailsFactory,caseDetailFactory,$stateParams,getServiceURI,$filter,componentService,$compile,dateTimeFactory,$q,$sce,$window,$document,topSummaryFactory,$timeout,dispositionFactory, createNewCaseFactory) {
 // .controller('alertDetailsCtrl', ['$scope','$rootScope','$state','alertDetailsFactory','caseDetailFactory','$stateParams','getServiceURI','$filter','componentService','$compile','dateTimeFactory','$q','$sce','$window','$document',function($scope,$rootScope,$state,alertDetailsFactory,caseDetailFactory,$stateParams,getServiceURI,$filter,componentService,$compile,dateTimeFactory,$q,$sce,$window,$document) {
  $scope.caseId= $stateParams.caseId;
  $scope.alertId= $stateParams.alertId;
  $scope.showTableHeader = true;
  $scope.hideRowNumbers  = false;
  $rootScope.showMoreContent = false;
  $scope.assigneeAdded = false;
  var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

  if($rootScope.loggedUserName == undefined){
    $rootScope.loggedUserName='PRASOONA GOLI';
  }
  $scope.lftContent = function(openLeft){
    if(openLeft){
      $scope.openLeft = false;
    } else {
      $scope.openLeft = true;
    }
  };

  $scope.leftLoad = function(){
    $scope.sideHeight = $window.innerHeight - ( 75 + 50 + $document.find('header').height() + $document.find('footer').height() );
    $document.find('.sideInfo').height($scope.sideHeight);
  };

  $scope.leftLoad();

  $(window).resize(function(){
    $scope.leftLoad();
  });

  $scope.loggedFirstName=$rootScope.loggedUserName.split(' ')[0];
  $scope.loggedLastName =$rootScope.loggedUserName.split(' ')[1]; 
  $scope.currentPage = 1;
  $scope.rowsPerPage = 25;

  $scope.getCSVServiceLink = function(){

    //var dateOfAccess = ($scope.alertDetails.dateOfAccess.name===undefined)? '' :($scope.alertDetails.dateOfAccess.name.search('Select')===-1)?$scope.alertDetails.dateOfAccess.name : ''; 
    var dateOfAccess =  $scope.alertDetails.dateOfAccess.length == 0 ? "" : _.pluck($scope.alertDetails.dateOfAccess, 'id');
    var timeOfAccess = $scope.alertDetails.timeOfAccess; 
    var selectDateSource =$scope.alertDetails.selectDateSource.length == 0 ? "" : _.pluck($scope.alertDetails.selectDateSource, 'id');
    var selectBanMarket= $scope.alertDetails.selectBanMarket.length == 0 ? "" : _.pluck($scope.alertDetails.selectBanMarket, 'id');
    var selectDtTiAgNot = ($scope.alertDetails.selectDtTiAgNot.name===undefined)? '' :($scope.alertDetails.selectDtTiAgNot.name.search('Select')===-1)?$scope.alertDetails.selectDtTiAgNot.name : ''; 
    var selectKeyType = $scope.alertDetails.selectedKeyType.length == 0 ? "" : _.pluck($scope.alertDetails.selectedKeyType, 'id'); 
    var accntEstDate=[],accntDiscDate=[];
  
    if($scope.alertDetails.selectAccDtEst.name.length){
            accntEstDate = dateTimeFactory.getDateRangesFromRawDatesAsString($scope.alertDetails.selectAccDtEst.name);
        }else{
             accntEstDate =dateTimeFactory.getDateRanges($scope.alertDetails.selectAccDtEst.value);
        }
      if( $scope.alertDetails.selectAccDisDate.name.length){
            accntDiscDate = dateTimeFactory.getDateRangesFromRawDatesAsString($scope.alertDetails.selectAccDisDate.name);
        }else{
             accntDiscDate =dateTimeFactory.getDateRanges($scope.alertDetails.selectAccDisDate.value);
        }
       if($scope.alertDetails.selectAccDtEst.name.length == 0){
            accntEstDate = ["",""];
        }
        if($scope.alertDetails.selectAccDisDate.name.length == 0 ){
            accntDiscDate =["",""];
        }
          if(accntEstDate[0] !== "" &&(accntEstDate[1] === undefined ||accntEstDate[1] === "") )
        {
          accntEstDate[1]=accntEstDate[0];
        }
        if(accntDiscDate[0] !== "" &&(accntDiscDate[1] === undefined ||accntDiscDate[1] === "") )
        {
          accntDiscDate[1]=accntDiscDate[0];
        }
    
    var link = getServiceURI.build('insiderThreat', 'exportAlertDetails')+ '/' +$rootScope.loggedAttId+'/'+ $scope.caseId +'/' + $scope.alertId+'?timeOfAccess='+timeOfAccess+'&dateOfAccess='+dateOfAccess+'&itemKey='+$scope.alertDetails.itemKey+'&dataSource='+selectDateSource+'&banMarket='+selectBanMarket+'&billingFirstName='+$scope.alertDetails.billingFirstName+'&billingLastName='+$scope.alertDetails.billingLastName+'&billingAddress='+$scope.alertDetails.billingAddress+'&startAccountDateEstablished='+accntEstDate[0]+'&endAccountDateEstablished='+accntEstDate[1]+'&keyType='+selectKeyType+'&startAccountDisconnectDate='+accntDiscDate[0]+'&endAccountDisconnectDate='+accntDiscDate[1]+'&dateOrTimeAgentNotation='+selectDtTiAgNot+'&accountStatus='+$scope.alertDetails.statusType+'&agentNoted='+$scope.alertDetails.statusType2+'&accessType='+$scope.alertDetails.accessType+'&searchBlock='+$scope.alertDetails.searchBlock+'&customerCity='+$scope.alertDetails.customerCity+'&customerState='+$scope.alertDetails.customerState+'&customerZip='+$scope.alertDetails.customerZip;
  //  var link = getServiceURI.build('insiderThreat', 'exportAlertDetails')+ '/' +$rootScope.loggedAttId+'/'+ $scope.caseId +'/' + $scope.alertId+'?timeOfAccess='+timeOfAccess+'&dateOfAccess='+dateOfAccess+'&itemKey='+$scope.alertDetails.itemKey+'&dataSource='+selectDateSource+'&banMarket='+selectBanMarket+'&billingName='+$scope.alertDetails.billingName+'&billingAddress='+$scope.alertDetails.billingAddress+'&startAccountDateEstablished='+accntEstDate[0]+'&accountDisconnectDate='+$scope.alertDetails.selectAccDisDate.value+'&dateOrTimeAgentNotation='+selectDtTiAgNot+'&accountStatus='+$scope.alertDetails.statusType+'&agentNoted='+$scope.alertDetails.statusType2;
    console.log("after export ********",link);
     return link;
  };

  $scope.showForm = false;
  $rootScope.loading = true;
  $scope.alertDetails = {
      'timeOfAccess' : '',
      'dateOfAccess' : [],
      'itemKey' : '',
      'selectDateSource' : [],
      'selectBanMarket' : [],
      'billingFirstName' : '',
      'billingLastName' : '',
      'billingAddress' : '',
      'selectAccDtEst' : {
        'name' : '',
        'value' : ''
      },
      'selectAccDisDate' :{
        'name' : '',
        'value' : ''
      },
      'selectDtTiAgNot' : '',
      'statusType' : [],
      'statusType2' : [],
      'selectedKeyType':[],
	    'accessType':'',
      'searchBlock':'',
      "customerCity":"",
      "customerState":"",
      "customerZip":""
  };
  
  var params = {
      //"banMarket":$scope.alertDetails.selectBanMarket,"dateOfAccess":$scope.alertDetails.dateOfAccess,   "dataSource":$scope.alertDetails.selectDateSource,
      "banMarket":_.pluck($scope.alertDetails.selectBanMarket, 'id'),
      "billingAddress":$scope.alertDetails.billingAddress,
      "startAccountDateEstablished":"",
      "endAccountDateEstablished":"",
      "startAccountDisconnectDate":"",
      "endAccountDisconnectDate":"",
      "dateOrTimeOfAgentNotation":'',
      "itemKey":$scope.alertDetails.itemKey,
      "billingFirstName":$scope.alertDetails.billingFirstName,
      "billingLastName":$scope.alertDetails.billingLastName,
      "timeOfAccess":$scope.alertDetails.timeOfAccess,
      "dateOfAccess":_.pluck($scope.alertDetails.dateOfAccess, 'id'),
      "dataSource":_.pluck($scope.alertDetails.selectDateSource, 'id'),
      "accountStatusList":$scope.alertDetails.statusType,
      "agentNoteList": $scope.alertDetails.statusType2,
      "keyType":_.pluck($scope.alertDetails.selectedKeyType, 'id'),
	    "accessType": $scope.alertDetails.accessType,
      "searchBlock":$scope.alertDetails.searchBlock,
      "customerCity":$scope.alertDetails.customerCity,
      "customerState":$scope.alertDetails.customerState,
      "customerZip":$scope.alertDetails.customerZip

  }

  $scope.CaseStatusOptions = [];   
  $scope.$watch('caseStatusSelectedOption', function(newValue){             
    });
  
  $scope.CaseDispositionOptions = [
    { name:'Select upon case Closure',value:'Select upon case Closure'}
  ];
  $scope.caseDispositionSelectedOption = $scope.CaseDispositionOptions[0];
  $scope.alertDispositionOptions = [ { name:'Select upon case Closure',value:'Select upon case Closure'}];  
  $scope.alertDispositionSelectedOption = $scope.alertDispositionOptions[0];
  dispositionFactory.getAllDisposition().then(function(data){
        $.each(data.dispositionTypeList,function(i,v)
        {
            var dorpdown ={}
            dorpdown.name = data.dispositionTypeList[i].dispositionName;
            dorpdown.value = data.dispositionTypeList[i].dispositionName;
            dorpdown.disabled = data.dispositionTypeList[i].dispositionEnabled ? false : true; 
            $scope.CaseDispositionOptions.push(dorpdown);
            $scope.alertDispositionOptions.push(dorpdown);
        });
               
        $scope.$watch('caseDispositionSelectedOption', function(newValue){});
         $scope.$watch('alertDispositionSelectedOption', function(newValue){
        });

    });

   
  $scope.caseOwnsers = [
    { name: 'Select' }
  ];
  $scope.caseOwnerSelectedOption = $scope.caseOwnsers[0];
  $scope.caseOwnersArray=[];

  
  
  
  
  $scope.statusChange=function(statusValue){
         if($scope.caseStatus == "New"){
                if($("#statusOptions .dropdown-menu li:nth-child(1) a").html() == "New"){
                    $("#statusOptions .dropdown-menu li:nth-child(1)").remove();
                }
            }
    if($scope.investigatorId == '' || $scope.investigatorId == null || $scope.investigatorId == 'null')
    {
      // console.log("investigator id is empty",statusValue.name);
      $scope.caseOwnerSelectedOption.name =$scope.loggedFirstName + ' ' + $scope.loggedLastName;
      $scope.caseOwnerPosition=false;
        
      if(statusValue.name !=='Closed'){
        
        $('#addColorToDisp').removeClass('customRequired');
        $scope.caseDispositonPosition=true;
        caseDetailFactory.changeCaseStatus(statusValue.name,$scope.caseId,'caseStatusType',$rootScope.loggedAttId).then(function(data){
           $scope.lastUpdatedDate = dateTimeFactory.changeToLocalTimeFromDate(data.lastUpdateDateTime);

        });
        $scope.caseOwnerPosition=false;
        $scope.alertDispositonPosition=false;
      
      } else if(statusValue.name ==='Closed'){
          $('#addColorToDisp').addClass('customRequired');
          $scope.caseDispositonPosition=false;
          $scope.caseOwnerPosition=true;
          $scope.alertDispositonPosition=true;
      }
    }
    else if($scope.investigatorId  === $rootScope.loggedAttId){
      // console.log("selected owner iss logged Att ID", $scope.caseOwnerSelectedOption.value);
      if(statusValue.name !=='Closed'){
        
        $scope.caseDispositonPosition=true;
        if($rootScope.isAdmin){
            $scope.caseOwnerPosition=false;
         }
        $scope.alertDispositonPosition=false;

        caseDetailFactory.changeCaseStatus(statusValue.name,$scope.caseId,'caseStatusType',$scope.caseOwnerSelectedOption.value).then(function(data){
          $scope.lastUpdatedDate = dateTimeFactory.changeToLocalTimeFromDate(data.lastUpdateDateTime);  
          $state.reload();        
        });
      }
      else if(statusValue.name ==='Closed'){

        if( $scope.caseDispositionSelectedOption.value === 'Select upon case Closure')
        {
          $('#addColorToDisp').addClass('customRequired');
        } else{
          console.log("disposition not empty");
          caseDetailFactory.changeCaseStatus(statusValue.name,$scope.caseId,'caseStatusType',$rootScope.loggedAttId).then(function(data){

            $scope.lastUpdatedDate = dateTimeFactory.changeToLocalTimeFromDate(data.lastUpdateDateTime);  
            $state.reload();        
          });
        }
        $scope.caseDispositonPosition=false;
          if($rootScope.isAdmin){
            $scope.caseOwnerPosition=false;
          }
        $scope.alertDispositonPosition=false;
      }
    }
    else {

      // console.log("selected owner iss not logged Att ID", $scope.caseOwnerSelectedOption.value);
      $scope.caseOwnerSelectedOption.name =$scope.loggedFirstName + ' ' + $scope.loggedLastName;
      if(statusValue.name !=='Closed')
      {
        $scope.caseDispositonPosition=true;
        if($rootScope.isAdmin){
            $scope.caseOwnerPosition=false;
          }
        $scope.alertDispositonPosition=false;
        caseDetailFactory.changeCaseStatus(statusValue.name,$scope.caseId,'caseStatusType',$rootScope.loggedAttId).then(function(data){
          $scope.lastUpdatedDate = dateTimeFactory.changeToLocalTimeFromDate(data.lastUpdateDateTime);
          $state.reload();
        });
      }
      else if(statusValue.name ==='Closed')
      {
        if( $scope.caseDispositionSelectedOption.value === 'Select upon case Closure')
        {
          $('#addColorToDisp').addClass('customRequired');
        }else{
         
          caseDetailFactory.changeCaseStatus(statusValue.name,$scope.caseId,'caseStatusType',$rootScope.loggedAttId).then(function(data){
            $scope.lastUpdatedDate = dateTimeFactory.changeToLocalTimeFromDate(data.lastUpdateDateTime);  
            $state.reload();        
          });
        }
        $scope.caseDispositonPosition=false;
        if($rootScope.isAdmin){
            $scope.caseOwnerPosition=false;
          }
        $scope.alertDispositonPosition=false;
      }
    }
  };

  $scope.dispositionChange=function(dispositionValue){
      console.log("Case disposition Change");
    if(dispositionValue.value === "Select upon case Closure"){
            return;
    }
    caseDetailFactory.changeCaseStatus(dispositionValue.value,$scope.caseId,'caseDisposition',$rootScope.loggedAttId).then(function(data){
      if(data.alertvalue === 'false')
      {
        $scope.closeCasePopup = true;
        return false; 
      }
      $('#addColorToDisp').removeClass('customRequired');
      $state.reload();
      $scope.CaseStatusPosition=false;
      $scope.caseDispositonPosition=false;
      if($rootScope.isAdmin){
            $scope.caseOwnerPosition=false;
          }
      $scope.alertDispositonPosition=false;
    $scope.lastUpdatedDate = dateTimeFactory.changeToLocalTimeFromDate(data.lastUpdateDateTime);
    });
  }
  $scope.OwnerChange=function(caseOwnerValue){
    if( caseOwnerValue.value !== undefined){
      caseDetailFactory.changeCaseStatus(caseOwnerValue.value,$scope.caseId,'manager',$rootScope.loggedAttId).then(function(data){
       $scope.lastUpdatedDate = dateTimeFactory.changeToLocalTimeFromDate(data.lastUpdateDateTime);
       $state.reload();      
      });
	  
    }
  }
  
  $scope.closeCasePopupClose = function(){
    $scope.closeCasePopup = false;   
    $state.reload();
  }
  $scope.closeCasePopupOpen = function(){
    $scope.closeCasePopup = true;
    $state.reload();
  } 

  $scope.currentPage = 1;
  $scope.tableData = {};
  $scope.rowsPerPage = 25;
  $scope.itemsPerPageOptions = [{ name:'25'},{ name:'40' },{ name:'60' }];
  $scope.totalRecords;
  $scope.itemsPerPage = $scope.itemsPerPageOptions[0];
  $scope.tableData.headers = {
      'agentId':'ATTUID',
      'location':'Location(IP ADDRESS)',
      'dataSource' : 'DATA SOURCE',
      'accessDate' : 'DATE OF ACCESS',
      'accessTime' : 'TIME OF ACCESS',
      'accessType': 'ACCESS TYPE',
      'itemKey': 'ITEM KEY',
      'keyType': 'ITEM KEY TYPE',
      'ban': 'BAN',
      'marketCode' : 'BAN MARKET',
      'memoFlag' : 'AGENT MEMO',
      'customerFirstNameOrBusinessName' : 'BILLING FIRST NAME',
      'customerLastNameOrBusinessName' : 'BILLING LAST NAME',
      'billingAddress' : 'BILLING ADDRESS',
      'customerCity': 'BILLING CITY',
      'customerState': 'BILLING STATE',
      'customerZip':'BILLING ZIP',
      'banStatusCode' : 'ACCOUNT STATUS',
      'banActivationDate' : 'ACCOUNT DATE ESTABLISHED',
      'banExpiryDate' : 'ACCOUNT DISCONNECT DATE',
      'fraudEvent': 'FRAUD EVENT AFTER TOUCH (GFMS)',
      'dateofFraudEvent': 'DATE OF FRAUD EVENT(GFMS)',
      'fraudType':'FRAUD TYPE',
      'searchBlock':'SEARCH BLOCK'
    };

     //Added below to fields related to sort 
    $scope.sortField = "";
    $scope.sortDirec = "";

    $scope.setSortConditions = function(sortField,sortDirection){
      //console.log('setting the sort conditions in allCasesController to :',sortField,'::',sortDirection);
      $scope.sortField = sortField;
      $scope.sortDirec = sortDirection;

    }
  $scope.setCurrentPageWhenSorting = function(pageNumber){
     // console.log('setting current page to bcoz unequla sorting columns',pageNumber);
      $scope.currentPage =pageNumber;
    }
    var _agentNoteArray = [
      { name: '0 - No Memo', value:'NoMemo' },
      { name: '1 - System Memo', value:'SystemMemo' },
      { name: '2 - Manual Memo', value:'ManualMemo' },
      { name: '3 - System And Manual Memo', value:'SystemAndManualMemo' },
      { name: '9 - No CTN To BAN Mapping Information', value:'NoCTNToBANMappingInformation' }
    ];
      $scope.itemKeyTypeArray = [
      { name: 'BAN' },
      { name: 'CTN' },
      { name: 'SSN' },
      { name: 'FAN' },
      { name: 'EQU' },
      { name: 'NAM' },
      { name: 'TAX' },
      { name: 'CNM' },
      { name: 'IMS' },
      { name: 'IME' },
      { name: 'CBN' },
      { name: 'MIL' },
      { name: 'ZIP' },
      { name: 'TAX'}
    ];
    
    $scope.agentNoteArray = _agentNoteArray;
    $scope.itemKeyTypeArray.sort(function(a, b){
        if(a.name > b.name) return 1;
        if(a.name < b.name) return -1;
        return 0;
    });
    
    var getCaseOwners = caseDetailFactory.getCaseOwners(),
      getAlertDetails = alertDetailsFactory.getAlertDetailsEventsData($stateParams.caseId,$stateParams.alertId,$scope.currentPage-1,$scope.rowsPerPage,params),
      getBanData = alertDetailsFactory.getBanData();
    
    
  $q.all([getCaseOwners,getAlertDetails,getBanData]).then(function(resultData){
      
    var ownerData = resultData[0];
    for(var i=0;i<ownerData.caseManagerList.length;i++){
        $scope.caseOwnersArray.push({'name':ownerData.caseManagerList[i].name,'value':ownerData.caseManagerList[i].attUserId}) ;
    }
    for( var j=0;j<$scope.caseOwnersArray.length;j++){
      $scope.caseOwnsers.push({name:$scope.caseOwnersArray[j].name,
      value:$scope.caseOwnersArray[j].value });
    };
      
    var data = resultData[1];
     $scope.caseIdNotNull=true;
     if($stateParams.caseId === "null" || $stateParams.caseId === null)
        {
          $scope.caseIdNotNull=false;
          $scope.CaseStatusPosition=true;
          $scope.caseDispositonPosition=true;
          $scope.caseOwnerPosition=true;
          $scope.alertDispositonPosition=true;
        }else if($stateParams.alertId != undefined){
            var suspectId = $stateParams.alertId.split("_")[0];
                 createNewCaseFactory.checkalertId(suspectId, $stateParams.alertId).then(function(data){
                     $rootScope.loading = false;
                     
                     if(data.status=="true"){
                       $scope.caseIdNotNull=true;

                     } else{
                      $scope.caseIdNotNull=false;
                     }                                       
                    console.log("data.status..."+data.status)
                     
             });
        }
       
    $scope.anomalyProbabilityforHeader='';
    $scope.totalPages = data.totalPages;
    $scope.totalRecords = data.totalRecords;
    $scope.alertProfile = data.summaryData;
    if($scope.alertProfile){
      $scope.anomalyProbabilityforHeader=parseFloat($filter('number')( $scope.alertProfile.anomalyProbability *100, 1));
    }
    var city='',state='',country='';
    if(data.companyName){
      $scope.company = data.companyName;
    }
    if(data.summaryData){
    if(data.summaryData.agentStreet){
      $scope.street = data.summaryData.agentStreet;
    }
    if(data.summaryData.agentCity){
       city = data.summaryData.agentCity;
    } if(data.summaryData.agentState){
       state = data.summaryData.agentState;
    } if(data.summaryData.agentCountryName){
       country = data.summaryData.agentCountryName;
    }

    $scope.location=city+' '+state+ ' '+country;
    if(data.lastUpdateDateTime !== null || data.lastUpdateDateTime !== 'null' || data.lastUpdateDateTime !== ''){
     $scope.lastUpdatedDate = dateTimeFactory.changeToLocalTimeFromDate(data.lastUpdateDateTime);
    }

    var alertDispositionValue='';
    if(data.summaryData.alertDisposition)
    {
            $("#alertDispositionDropdown .dropdown-menu li:nth-child(1)").remove(); 
       alertDispositionValue =  data.summaryData.alertDisposition;
    }
    else{
        $scope.alertDispositionSelectedOption = $scope.alertDispositionOptions[0];
    }
  } 
    var caseStatus = data.caseStatusType.name;
      $scope.caseStatus = caseStatus;
      $scope.CaseStatusOptions.push(
        { name:'New' },
        { name:'Open'},
        { name:'Referred' },
        { name:'Recycled', disabled: true },
        { name:'InProgress' }, 
        { name:'Closed' }
      );
    var caseDispositionValue=data.caseDisposition;
    var investigatorId=data.investigatorId;
    var caseDisposition='';
    $scope.investigatorId=data.investigatorId;

    data.alertProbability=parseFloat($filter('number')( data.alertProbability , 3));
    if(caseDispositionValue === null || caseDispositionValue === 'null' || caseDispositionValue === '' )
    {
      $scope.caseDispositionSelectedOption = $scope.CaseDispositionOptions[0];
    } else{
      caseDisposition=data.caseDisposition;
    }
         
    for(var i=0;i<$scope.caseOwnsers.length;i++){
      var caseOwnerAttId=$scope.caseOwnsers[i].value;
      if(caseOwnerAttId === investigatorId)
      {
        $scope.caseOwnerSelectedOption=$scope.caseOwnsers[i];
        break;
      }
    }
    for(var i=0;i<$scope.CaseDispositionOptions.length;i++){
      var caseDispositionValue=$scope.CaseDispositionOptions[i].value;
      if(caseDispositionValue === caseDisposition)
      {
        $scope.caseDispositionSelectedOption = $scope.CaseDispositionOptions[i];
        break;
      }
    }
    for(var j=0;j<$scope.alertDispositionOptions.length;j++){
      var alertDispValue=$scope.alertDispositionOptions[j].value;
      if(alertDispValue === alertDispositionValue)
      {
        $scope.alertDispositionSelectedOption = $scope.alertDispositionOptions[j];
        break;
      }
    }
    for(var i=0; i < $scope.CaseStatusOptions.length; i++ ){
      if($scope.CaseStatusOptions[i].name === caseStatus){
        $scope.caseStatusSelectedOption = $scope.CaseStatusOptions[i];
        break;
      };
    };

    if(investigatorId == '' || investigatorId == null || investigatorId == 'null')
    {
      // console.log("this is unassigned case::::::::::",investigatorId);
      $scope.CaseStatusPosition=false;
      $scope.caseDispositonPosition=true;
      $scope.caseOwnerPosition=true;
    } else if(investigatorId === $rootScope.loggedAttId)
    {
      // console.log("this is assigned case::::::::::",investigatorId);
      $scope.CaseStatusPosition=false;
      $scope.caseDispositonPosition=true;
        if($rootScope.isAdmin){
            $scope.caseOwnerPosition=false;
        }
    } else { 
      // console.log("this is assigned to diif usercase::::::::::",investigatorId);
      /*$scope.CaseStatusPosition=false;
      $scope.caseDispositonPosition=true;
      $scope.caseOwnerPosition=false;
      */  
      topSummaryFactory.checkUserInUPM().then(function(data){
        if(data.upmCheck == "true"){
            $rootScope.isAdmin = true;
          $scope.CaseStatusPosition=false;
            
          if(caseStatus === 'Closed') {      
                    $scope.caseDispositonPosition=false;
                }else{
                    $scope.caseDispositonPosition=true;
                }
          $scope.caseOwnerPosition=false;
        }
        else{
            $rootScope.isAdmin = false;
          $scope.CaseStatusPosition=true;
          $scope.caseDispositonPosition=true;
          $scope.caseOwnerPosition=true;
          $scope.alertDispositonPosition=true;
        }
      });


    }

    if(caseStatus === 'Closed')
    {
      $scope.CaseStatusPosition=false;
      $scope.caseDispositonPosition=false;
      $scope.caseOwnerPosition=false;
      $scope.alertDispositonPosition=false;
    }

    var _selectTimeArray = [],_dateOfAccess = [],_dataSourceArray= [],_accDateEstdArray = [],_accDisDateArray = [],_dateTimeOfAgentNotationArray = [],_statusArray=[];
    
    var alertDetailsTableData = data.dataList;
    if(alertDetailsTableData){
      $scope.alertsDataLength = alertDetailsTableData.length;
    } else {      
      $scope.alertsDataLength = 0;
    }
    $scope.csv = $scope.getCSVServiceLink();
  if(alertDetailsTableData){
    for(var i=0;i<alertDetailsTableData.length;i++){
      //alertDetailsTableData[i].location ='';
       alertDetailsTableData[i].fraudEvent ='';
       alertDetailsTableData[i].dateofFraudEvent='';
       alertDetailsTableData[i].fraudType ='';
       
      alertDetailsTableData[i].billingAddress=alertDetailsTableData[i].customerAddress1+" "+alertDetailsTableData[i].customerAddress2;  
      var alertACStatus=alertDetailsTableData[i].banStatusCode;

      var memoFlag=alertDetailsTableData[i].memoFlag;
      if(alertACStatus === 'T'){
        alertDetailsTableData[i].banStatusCode='Tentative';
      } else if(alertACStatus === 'O'){
        alertDetailsTableData[i].banStatusCode='Open';
      } else if(alertACStatus === 'C'){
        alertDetailsTableData[i].banStatusCode='Cancelled';
      } else if(alertACStatus === 'S'){
        alertDetailsTableData[i].banStatusCode='Suspended';
      } else if(alertACStatus === 'N'){
        alertDetailsTableData[i].banStatusCode='Closed';
      }

      var memoFlagTitle;
      if(memoFlag === '0'){
        memoFlagTitle = 'No Memo';
      } else if(memoFlag === '1'){
        memoFlagTitle = 'System Memo';
      }  else if(memoFlag === '2'){
        memoFlagTitle = 'Manual Memo';
      } else if(memoFlag === '3'){
        memoFlagTitle = 'System And Manual Memo';
      } else if(memoFlag === '9'){
        memoFlagTitle = 'No CTN To BAN Mapping Information';
      }
      
      alertDetailsTableData[i].memoFlag = $sce.trustAsHtml('<div title="' + memoFlagTitle + '"  alt="' + memoFlagTitle +'">' + memoFlag + '</div>');

      if(alertDetailsTableData[i].banActivationDate){
        alertDetailsTableData[i].banActivationDate= alertDetailsTableData[i].banActivationDate.split(' ')[0];
        alertDetailsTableData[i].banActivationDate = (alertDetailsTableData[i].banActivationDate).replace(/-/g,'');
        alertDetailsTableData[i].banActivationDate= alertDetailsTableData[i].banActivationDate.substring(4,6)+'/'+alertDetailsTableData[i].banActivationDate.substring(6,8)+'/'+alertDetailsTableData[i].banActivationDate.substring(0,4);
        _accDateEstdArray.push(alertDetailsTableData[i].banActivationDate);
      }
      if(alertDetailsTableData[i].banExpiryDate){
        alertDetailsTableData[i].banExpiryDate =alertDetailsTableData[i].banExpiryDate.split(' ')[0];
        alertDetailsTableData[i].banExpiryDate = (alertDetailsTableData[i].banExpiryDate).replace(/-/g,'');
        alertDetailsTableData[i].banExpiryDate=alertDetailsTableData[i].banExpiryDate.substring(4,6)+'/'+alertDetailsTableData[i].banExpiryDate.substring(6,8)+'/'+alertDetailsTableData[i].banExpiryDate.substring(0,4);
        _accDisDateArray.push(alertDetailsTableData[i].banExpiryDate);
      }

      _selectTimeArray.push(alertDetailsTableData[i].accessTime) ;

      if(alertDetailsTableData[i].accessDate){
        _dateOfAccess.push(alertDetailsTableData[i].accessDate);
        alertDetailsTableData[i].accessDate = (alertDetailsTableData[i].accessDate).replace(/-/g,'');
        alertDetailsTableData[i].accessDate =alertDetailsTableData[i].accessDate.substring(4,6)+'/'+alertDetailsTableData[i].accessDate.substring(6,8)+'/'+alertDetailsTableData[i].accessDate.substring(0,4);
      }
         
      _dataSourceArray.push(alertDetailsTableData[i].dataSource);
      _dateTimeOfAgentNotationArray.push( alertDetailsTableData[i].accessDateTime);
      
    }
  }
    //filter form data generation
    //time of access dropdown           
    _selectTimeArray=componentService.getUniqueArray(_selectTimeArray);

    $scope.selectTime =  [
      { name:'Select time' }
    ];

    $.each(_selectTimeArray,function(i,v){
      $scope.selectTime.push({
        name:v
      });
    });

   //Date of Access
    _dateOfAccess=componentService.getUniqueArray(_dateOfAccess);
    $scope.selectDate =  [
    
    ];
  
    $.each(_dateOfAccess,function(i,v){
      $scope.selectDate.push({
        name:v
      });
    });
    
    $scope.dateSource =  [
      
      { name:'TLG_BTTW' },
      { name:'CFY_BTTW' }
    ];
    
    $scope.dateSource.sort(function(a, b){
        if(a.name > b.name) return 1;
        if(a.name < b.name) return -1;
        return 0;
    });
    
    $scope.banMarket =  [
      
    ];

    $.each(resultData[2],function(i,v){
      $scope.banMarket.push({
        name:v.marketCode
      });
    });

    //accDateEstd data
    _accDateEstdArray=componentService.getUniqueArray(_accDateEstdArray);

    $scope.accDateEstd =  [
      { name:'Select' }
    ];

    $.each(_accDateEstdArray,function(i,v){
      $scope.accDateEstd.push({
        name:v
      });
    });

    //accDisDate data
    _accDisDateArray=componentService.getUniqueArray(_accDisDateArray);

    $scope.accDisDate =  [
      { name:'Select' }
    ];  

    $.each(_accDisDateArray,function(i,v){
      $scope.accDisDate.push({
        name:v
      });
    });
  
    //dateTimeOfAgentNotation data
    _dateTimeOfAgentNotationArray=componentService.getUniqueArray(_dateTimeOfAgentNotationArray);
    
    $scope.dateTimeOfAgentNotation =  [
      { name:'Select' }
    ];

    $.each(_dateTimeOfAgentNotationArray,function(i,v){
      $scope.dateTimeOfAgentNotation.push({
        name:v
      });
    });

    _statusArray= ['Open','Tentative','Cancelled','Closed','Suspended'];

    $scope.statusArray = _statusArray;
    $scope.agentNoteArrayPost = [];
    $scope.tableData.tbody = alertDetailsTableData;
    if(alertDetailsTableData){
      $scope.alertsDataLength = alertDetailsTableData.length;
    } else {      
      $scope.alertsDataLength = 0;
    }
    $(".rows-per-page label").text("Results per page");

    $scope.showForm = true;
        $timeout(function() {
             if($scope.caseStatus != "New"){
            $("#statusOptions .dropdown-menu li:nth-child(1)").remove(); 
            
          }
            if($scope.permissions.IT_CASE_MGT.edit){
        if($rootScope.isAdmin){
             if($scope.caseStatus != "New"){
                $scope.caseOwnerPosition=false;
                 $scope.alertDispositonPosition = false;
             }else{
                $scope.caseOwnerPosition=true;
                 $scope.alertDispositonPosition = true;
             }
                 
         }else if( $scope.investigatorId == $rootScope.loggedAttId){
             $scope.caseOwnerPosition=false;
             $scope.alertDispositonPosition = false;
         }else{
             
             $scope.caseOwnerPosition=true;
             $scope.alertDispositonPosition = true;
         }    
            }else{
                $scope.caseOwnerPosition=true;
                 $scope.CaseStatusPosition=true;
                 $scope.caseDispositonPosition=true ;
                $scope.alertDispositonPosition = true;
            }
        $.each($scope.alertDetails.statusType2,function(i,v){
            $("#an"+v).prop('checked', true);
        });
        $.each($scope.alertDetails.statusType,function(i,v){
            $("#ac"+v).prop('checked', true);
        });
        $.each($scope.alertDetails.selectDateSource,function(i,v){
            $("a:contains('"+v+"') span").addClass("glyphicon glyphicon-ok");
        });
        $.each($scope.alertDetails.dateOfAccess,function(i,v){
            $("a:contains('"+v+"') span").addClass("glyphicon glyphicon-ok");
        });
        $.each($scope.alertDetails.selectedKeyType,function(i,v){
            $("a:contains('"+v+"') span").addClass("glyphicon glyphicon-ok");
        });
        $.each($scope.alertDetails.selectBanMarket,function(i,v){
            $("a:contains('"+v+"') span").addClass("glyphicon glyphicon-ok");
        });
        $rootScope.loading = false;    
        },1000);
  });
 $scope.alertDispositionChange=function(alertDispChangedValue){
      console.log("Alert disposition Change");
     if(alertDispChangedValue.value === "Select upon case Closure"){
            return;
        }
    caseDetailFactory.bulkCloseCaseInfo($stateParams.alertId,$stateParams.caseId,alertDispChangedValue.value).then(function(data){
      var msg=data.status;
      $state.reload();
    });
  }
  $scope.invokeUpdateAlertDetails = function(){
    $scope.currentPage = 1;
    $scope.rowsPerPage = 25;
    $scope.itemsPerPage =  $scope.itemsPerPageOptions[0];
    
    $scope.updateAlertDetails();
  }
    
  $scope.updateAlertDetails = function(){
      
      $(".hasDatepicker").hide();
      $rootScope.loading = true;
      
 $scope.csv = $scope.getCSVServiceLink();
      var params = $scope.updateEventsParams();
        
      $rootScope.alertDetailsFilterSelected = "yes";
      alertDetailsFactory.getAlertDetailsEventsData($stateParams.caseId,$stateParams.alertId,$scope.currentPage-1,$scope.rowsPerPage,params).then(function(data){
      
            $scope.prepareEventsData(data);
     
        });
      };

    $scope.banMarketSettings = {
      displayProp: 'name', 
      idProp: 'name', 
      scrollableHeight: '200px',
      scrollable: true,
      showCheckAll : true,
      showUncheckAll : true,
      enableSearch : true,
      smartButtonMaxItems : 5
    }
    $scope.banMarketCustomText = {buttonDefaultText: 'Select'};
    $scope.dateOfAccessSettings = {
      displayProp: 'name', 
      idProp: 'name', 
      scrollableHeight: '200px',
      scrollable: true,
      showCheckAll : true,
      showUncheckAll : true,
      enableSearch : true,
      smartButtonMaxItems : 5
    }
    $scope.dateOfAccessCustomText = {buttonDefaultText: 'Select date'}; 
    $scope.dataSourceSettings = {
      displayProp: 'name', 
      idProp: 'name', 
      scrollableHeight: '200px',
      scrollable: true,
      showCheckAll : true,
      showUncheckAll : true,
      enableSearch : true,
      smartButtonMaxItems : 5
    }
    $scope.dataSourceCustomText = {buttonDefaultText: 'Select'};


  
    function onItemSelect(property) {
      $scope.invokeUpdateAlertDetails();
    }
      
    function onItemDeselect(property) {
      $scope.invokeUpdateAlertDetails();
    } 

    
    localStorage.caseId = $stateParams.caseId;
     $rootScope.routedFromAlertDetails = "yes";
    if($rootScope.routedFromAllCases==='yes'){
      $rootScope.route = [
      {
        'url' : 'home',
        'name' : 'Home'
      },
      {
        'url' : 'allCases',
        'name' : 'All Cases'                                           
      },
      {
        'url' : 'caseDetails({ caseId: "'+$stateParams.caseId+'"})',
        'name' : 'Case Detail'
      },
      {
        'url' : 'alertDetails',
        'name' : 'Alert Details'
      }
      ];
    }
    else if($rootScope.routedFromCreateNewCase === 'yes'){

         $rootScope.route = [
            {
                "url" : "home",
                "name" : "Home"
            },
              {
                "url" : "allCases",
                "name" : "All Cases"                                           
            },
            {
                "url" : "createNewCase",
                "name" : "New Case"                                          
            },

            {
                "url" : "alertDetails",
                "name" : "Alert Details"  

            }
          
            ];

    }else if($rootScope.routedFromAllAlerts === 'yes'){
           $rootScope.route = [
            {
                "url" : "home",
                "name" : "Home"
            },{
                "url" : "alerts",
                "name" : "All Alerts" 
            },{
                "url" : "alertDetails",
                "name" : "Alert Details"  
            }
          
            ];
    }
    else{
      $rootScope.route = [
      {
        'url' : 'home',
        'name' : 'Home'
      },
      {
        'url' : 'caseDetails({ caseId: "'+$stateParams.caseId+'"})',
        'name' : 'Case Detail'
      },
      {
        'url' : 'alertDetails',
        'name' : 'Alert Detail'
      }
      ];
    }
      
    /*$scope.selectDate = [
      {name: 'Select date'},
      {name: 'dd'}
    ];*/

 
    
    $scope.resetFilter = function(){

      $scope.alertDetails.timeOfAccess = '';
      $scope.alertDetails.dateOfAccess = [];
      $scope.alertDetails.itemKey = '';
      $scope.alertDetails.resetField = '';
      $scope.alertDetails.selectDateSource = [];
      $scope.alertDetails.selectBanMarket  = [];
      $scope.alertDetails.billingFirstName = '';
      $scope.alertDetails.billingLastName = '';
      $scope.alertDetails.billingAddress = '';
      $scope.alertDetails.selectAccDtEst  = {
        'name' : '',
        'value' : ''
      };
      $scope.alertDetails.selectAccDisDate  = {
        'name' : '',
        'value' : ''
      };
      $scope.alertDetails.selectDtTiAgNot  = {
        'name' : 'Select'
      };
      $scope.alertDetails.statusType=[];
      $scope.alertDetails.statusType2=[];
	    $scope.alertDetails.selectedKeyType =  [];
      $('#alertDetailsStatus').empty();
      $('#alertDetailsStatus').append($compile('<div ng-repeat = "data in statusArray">'+ 
        '<div class="checkbox"><input type="checkbox" value="{{data}}" id="ac{{data}}" ng-model="status" my-checkbox1 />'+
        '<label for = "ac{{data}}" >{{data}}</label></div></div>')($scope));


      $('#alertDetailsAgentNote').empty();
      $('#alertDetailsAgentNote').append($compile(' <div ng-repeat = "data1 in agentNoteArray">'+
        '<div class="checkbox"><input type="checkbox" name="agentMemo" value="{{data1.value}}" id="an{{data1.value}}" ng-model="status2" my-checkbox2 />'+
        '<label for = "an{{data1.value}}" >{{data1.name}}</label></div></div>')($scope));
   
	   $scope.alertDetails.accessType = '';
       $scope.alertDetails.searchBlock = '';
       $scope.alertDetails.customerCity = '';
       $scope.alertDetails.customerState = '';
       $scope.alertDetails.customerZip = '';
       $rootScope.alertDetailsFromFilter = [];
        $scope.updateAlertDetails();
}
    
    $scope.onPageChange = function(page){
      $scope.currentPage = page;
      $scope.updateTableWithSorting($scope.sortField,$scope.sortDirec);
    }
    $scope.getRowCount = function(i){
      var total = $scope.rowsPerPage,
      currentPage = $scope.currentPage;
      i += currentPage > 1 ? (currentPage * total) - total + 1 : 1;
      i = i>$scope.totalRows?$scope.totalRows:i;
      return i;
    };

    $scope.onRowsPerPageChange = function (page ) {
      $scope.currentPage =1;
      $scope.rowsPerPage = page.name;
      $scope.updateAlertDetails();
    }
 
     $scope.updateTableWithSorting = function(sortField,sortDirection) {
      $rootScope.loading = true;
      var params = $scope.updateEventsParams();
    
        
         alertDetailsFactory.getAlertDetailsEventsDataWithSorting($stateParams.caseId,$stateParams.alertId,params,$scope.currentPage-1,$scope.rowsPerPage,sortField,sortDirection).then(function(data){
      
        $scope.prepareEventsData(data);
    
    });

  
	
  };
  $scope.prepareEventsData = function(data){
       
        $scope.totalPages = data.totalPages;
        $scope.totalRecords = data.totalRecords;
        var alertDetailsTableData = data.dataList;
        if(alertDetailsTableData){
          $scope.alertsDataLength = alertDetailsTableData.length;
        } else {      
          $scope.alertsDataLength = 0;
        }

       
        for(var i=0;i< $scope.alertsDataLength;i++){
           //alertDetailsTableData[i].location ='';
           alertDetailsTableData[i].fraudEvent ='';
           alertDetailsTableData[i].dateofFraudEvent='';
           alertDetailsTableData[i].fraudType ='';

          //  alertDetailsTableData[i].billingName=alertDetailsTableData[i].customerFirstNameOrBusinessName+" "+alertDetailsTableData[i].customerLastNameOrBusinessName;  
            alertDetailsTableData[i].billingAddress=alertDetailsTableData[i].customerAddress1+" "+alertDetailsTableData[i].customerAddress2;  
            
            var alertACStatus=alertDetailsTableData[i].banStatusCode;
            var memoFlag=alertDetailsTableData[i].memoFlag;
            if(alertACStatus === 'T')
            {
              alertDetailsTableData[i].banStatusCode='Tentative';
            } else if(alertACStatus === 'O')
            {
              alertDetailsTableData[i].banStatusCode='Open';
            } else if(alertACStatus === 'C'){
              alertDetailsTableData[i].banStatusCode='Cancelled';
            } else if(alertACStatus === 'S'){
              alertDetailsTableData[i].banStatusCode='Suspended';
            } else if(alertACStatus === 'N'){
              alertDetailsTableData[i].banStatusCode='Closed';
            }
            
            var memoFlagTitle;
            if(memoFlag === '0'){
              memoFlagTitle = 'No Memo';
            } else if(memoFlag === '1'){
              memoFlagTitle = 'System Memo';
            }  else if(memoFlag === '2'){
              memoFlagTitle = 'Manual Memo';
            } else if(memoFlag === '3'){
              memoFlagTitle = 'System And Manual Memo';
            } else if(memoFlag === '9'){
              memoFlagTitle = 'No CTN To BAN Mapping Information';
            }
            alertDetailsTableData[i].memoFlag = $sce.trustAsHtml('<div title="' + memoFlagTitle + '"  alt="' + memoFlagTitle +'">' + memoFlag + '</div>');

            if(alertDetailsTableData[i].banActivationDate){
              alertDetailsTableData[i].banActivationDate =dateTimeFactory.changeToLocalDate(alertDetailsTableData[i].banActivationDate);
            }
            if(alertDetailsTableData[i].banExpiryDate){
                alertDetailsTableData[i].banExpiryDate =dateTimeFactory.changeToLocalDate(alertDetailsTableData[i].banExpiryDate);
            }
            if(alertDetailsTableData[i].accessDate){
              alertDetailsTableData[i].accessDate = dateTimeFactory.changeToLocalDate(alertDetailsTableData[i].accessDate);
            }
          }

          $scope.tableData.tbody = alertDetailsTableData;
          var alertDetailsTableData = data.dataList;
          if(alertDetailsTableData){
              $scope.alertsDataLength = alertDetailsTableData.length;
          } else {      
            $scope.alertsDataLength = 0;
          }

          $(".rows-per-page label").text("Results per page");
          $scope.showForm = true;  
          $rootScope.loading = false;
  };
  $scope.updateEventsParams = function(){
      var accntEstDate=[],accntDiscDate=[];
      if( $scope.alertDetails.selectAccDtEst.name.length){
            accntEstDate = dateTimeFactory.getDateRangesFromRawDatesAsString($scope.alertDetails.selectAccDtEst.name);
        }else{
             accntEstDate =dateTimeFactory.getDateRanges($scope.alertDetails.selectAccDtEst.value);
        } 
      if( $scope.alertDetails.selectAccDisDate.name.length){
            accntDiscDate = dateTimeFactory.getDateRangesFromRawDatesAsString($scope.alertDetails.selectAccDisDate.name);
        }else{
             accntDiscDate =dateTimeFactory.getDateRanges($scope.alertDetails.selectAccDisDate.value);
        }  
     if($scope.alertDetails.selectAccDtEst.name.length == 0){
            accntEstDate = ["",""];
        }
        if($scope.alertDetails.selectAccDisDate.name.length == 0 ){
            accntDiscDate =["",""];
        }

        if(accntEstDate[0] !== "" &&(accntEstDate[1] === undefined ||accntEstDate[1] === "") )
        {
          accntEstDate[1]=accntEstDate[0];
        }
        if(accntDiscDate[0] !== "" &&(accntDiscDate[1] === undefined ||accntDiscDate[1] === "") )
        {
          accntDiscDate[1]=accntDiscDate[0];
        }
//      if($rootScope.alertDetailsFilterSelected !== "yes"){
//          $rootScope.alertDetailsFromFilter = [];
//      }
       $rootScope.alertDetailsFromFilter = [];
       var params = {    
    
        "banMarket":($rootScope.alertDetailsFromFilter.length !== 0)? $rootScope.alertDetailsFromFilter[0].banMarket : _.pluck($scope.alertDetails.selectBanMarket, 'id'),
        "billingAddress": ($rootScope.alertDetailsFromFilter.length !== 0)? $rootScope.alertDetailsFromFilter[0].billingAddress : $scope.alertDetails.billingAddress,
        "startAccountDateEstablished": ($rootScope.alertDetailsFromFilter.length !== 0)? $rootScope.alertDetailsFromFilter[0].startAccountDateEstablished : accntEstDate[0],
        "endAccountDateEstablished": ($rootScope.alertDetailsFromFilter.length !== 0)? $rootScope.alertDetailsFromFilter[0].endAccountDateEstablished : accntEstDate[1],
        "startAccountDisconnectDate": ($rootScope.alertDetailsFromFilter.length !== 0)? $rootScope.alertDetailsFromFilter[0].startAccountDisconnectDate : accntDiscDate[0],
        "endAccountDisconnectDate": ($rootScope.alertDetailsFromFilter.length !== 0)? $rootScope.alertDetailsFromFilter[0].endAccountDisconnectDate : accntDiscDate[1],
        "dateOrTimeOfAgentNotation":'',
        "itemKey":($rootScope.alertDetailsFromFilter.length !== 0)? $rootScope.alertDetailsFromFilter[0].itemKey : $scope.alertDetails.itemKey,
        "billingFirstName": ($rootScope.alertDetailsFromFilter.length !== 0)? $rootScope.alertDetailsFromFilter[0].billingFirstName : $scope.alertDetails.billingFirstName,
        "billingLastName": ($rootScope.alertDetailsFromFilter.length !== 0)? $rootScope.alertDetailsFromFilter[0].billingLastName : $scope.alertDetails.billingLastName,
        "timeOfAccess": ($rootScope.alertDetailsFromFilter.length !== 0)? $rootScope.alertDetailsFromFilter[0].timeOfAccess : $scope.alertDetails.timeOfAccess,
        "dateOfAccess": ($rootScope.alertDetailsFromFilter.length !== 0)? $rootScope.alertDetailsFromFilter[0].dateOfAccess : _.pluck($scope.alertDetails.dateOfAccess, 'id'),
        "dataSource": ($rootScope.alertDetailsFromFilter.length !== 0)? $rootScope.alertDetailsFromFilter[0].dataSource : _.pluck($scope.alertDetails.selectDateSource, 'id'),
        "accountStatusList": ($rootScope.alertDetailsFromFilter.length !== 0)? $rootScope.alertDetailsFromFilter[0].accountStatusList : $scope.alertDetails.statusType,
        "agentNoteList": ($rootScope.alertDetailsFromFilter.length !== 0)? $rootScope.alertDetailsFromFilter[0].agentNoteList : $scope.alertDetails.statusType2,
		"keyType":($rootScope.alertDetailsFromFilter.length !== 0)? $rootScope.alertDetailsFromFilter[0].keyType : _.pluck($scope.alertDetails.selectedKeyType, 'id'),
 		"accessType": ($rootScope.alertDetailsFromFilter.length !== 0)? $rootScope.alertDetailsFromFilter[0].accessType : $scope.alertDetails.accessType,
      	"searchBlock": ($rootScope.alertDetailsFromFilter.length !== 0)? $rootScope.alertDetailsFromFilter[0].searchBlock : $scope.alertDetails.searchBlock,
        "customerCity": ($rootScope.alertDetailsFromFilter.length !== 0)? $rootScope.alertDetailsFromFilter[0].customerCity : $scope.alertDetails.customerCity,
        "customerState": ($rootScope.alertDetailsFromFilter.length !== 0)? $rootScope.alertDetailsFromFilter[0].customerState : $scope.alertDetails.customerState,
        "customerZip": ($rootScope.alertDetailsFromFilter.length !== 0)? $rootScope.alertDetailsFromFilter[0].customerZip : $scope.alertDetails.customerZip
      }
      $scope.startAccountDateEstablished = accntEstDate[0];
	  $scope.endAccountDateEstablished = accntEstDate[1];
	  $scope.startAccountDisconnectDate = accntDiscDate[0];
	  $scope.endAccountDisconnectDate = accntDiscDate[1];
      
      $rootScope.alertDetailsFromFilter.push({
        "banMarket":_.pluck($scope.alertDetails.selectBanMarket, 'id'),
        "billingAddress":$scope.alertDetails.billingAddress,
        "startAccountDateEstablished":accntEstDate[0],
        "endAccountDateEstablished":accntEstDate[1],
        "startAccountDisconnectDate":accntDiscDate[0],
        "endAccountDisconnectDate":accntDiscDate[1],
        //"dateOrTimeOfAgentNotation":'',
        "itemKey":$scope.alertDetails.itemKey,
        "billingFirstName":$scope.alertDetails.billingFirstName,
        "billingLastName":$scope.alertDetails.billingLastName,
        "timeOfAccess":$scope.alertDetails.timeOfAccess,
        "dateOfAccess":_.pluck($scope.alertDetails.dateOfAccess, 'id'),
        "dataSource":_.pluck($scope.alertDetails.selectDateSource, 'id'),
        "accountStatusList":$scope.alertDetails.statusType,
        "agentNoteList": $scope.alertDetails.statusType2,
        "keyType":_.pluck($scope.alertDetails.selectedKeyType, 'id'),
        "accessType": $scope.alertDetails.accessType,
      	"searchBlock":$scope.alertDetails.searchBlock,
        "customerCity":$scope.alertDetails.customerCity,
        "customerState":$scope.alertDetails.customerState,
        "customerZip":$scope.alertDetails.customerZip
      })
      
      return params;
  };
      $scope.alertDetailsFilterData = function(){
          $scope.alertDetails.selectBanMarket = $rootScope.alertDetailsFromFilter[0].banMarket;
          $scope.alertDetails.billingAddress = $rootScope.alertDetailsFromFilter[0].billingAddress;
          $scope.startAccountDateEstablished = $rootScope.alertDetailsFromFilter[0].startAccountDateEstablished;
          $scope.endAccountDateEstablished = $rootScope.alertDetailsFromFilter[0].endAccountDateEstablished;
          $scope.startAccountDisconnectDate = $rootScope.alertDetailsFromFilter[0].startAccountDisconnectDate;
          $scope.endAccountDisconnectDate = $rootScope.alertDetailsFromFilter[0].endAccountDisconnectDate;
          $scope.alertDetails.itemKey = $rootScope.alertDetailsFromFilter[0].itemKey;
          $scope.alertDetails.billingFirstName = $rootScope.alertDetailsFromFilter[0].billingFirstName;
          $scope.alertDetails.billingLastName = $rootScope.alertDetailsFromFilter[0].billingLastName;
          $scope.alertDetails.timeOfAccess = $rootScope.alertDetailsFromFilter[0].timeOfAccess;
          $scope.alertDetails.dateOfAccess = $rootScope.alertDetailsFromFilter[0].dateOfAccess;
          $scope.alertDetails.selectDateSource = $rootScope.alertDetailsFromFilter[0].dataSource;
          $scope.alertDetails.statusType = $rootScope.alertDetailsFromFilter[0].accountStatusList;
          $scope.alertDetails.statusType2 = $rootScope.alertDetailsFromFilter[0].agentNoteList;
          $scope.alertDetails.selectedKeyType = $rootScope.alertDetailsFromFilter[0].keyType;
          $scope.alertDetails.accessType = $rootScope.alertDetailsFromFilter[0].accessType;
          $scope.alertDetails.searchBlock = $rootScope.alertDetailsFromFilter[0].searchBlock;
          $scope.alertDetails.customerCity = $rootScope.alertDetailsFromFilter[0].customerCity;
          $scope.alertDetails.customerState = $rootScope.alertDetailsFromFilter[0].customerState;
          $scope.alertDetails.customerZip = $rootScope.alertDetailsFromFilter[0].customerZip;
          
          $scope.alertDetails.selectAccDtEst.name =$scope.startAccountDateEstablished ? $scope.startAccountDateEstablished.split("-").join("/") + "-" + $scope.endAccountDateEstablished.split("-").join("/") : "";
          $scope.alertDetails.selectAccDisDate.name = $scope.startAccountDisconnectDate ? $scope.startAccountDisconnectDate.split("-").join("/") + "-" + $scope.endAccountDisconnectDate.split("-").join("/") : "";
      }
  $scope.showMore = function(){
        
        
        $(".show-more-content").toggle(500);
        if($rootScope.showMoreContent){
            $rootScope.showMoreContent = false;
            $(".show-more-link a").html("Show more ...");
        }else{
            $rootScope.showMoreContent = true;
            
            $(".show-more-link a").html("Show less");
        }
        
    };
      
      
         $scope.init=function()
    {
       if($rootScope.alertDetailsFilterSelected === "yes"){
           $scope.alertDetailsFilterData();
           $scope.updateAlertDetails();
       }
             
       topSummaryFactory.checkBasicUserInUPM().then(function(data){
        if(data.upmCheck == "false")
        {
            $state.go('error',{'id':""});
        }
        });
        topSummaryFactory.checkUserInUPM().then(function(data){
            if(data.upmCheck == "true"){
                $rootScope.isAdmin = true;
            }else{
                $rootScope.isAdmin = false;
            }
        });
        topSummaryFactory.getUserPermissions().then(function(data){
           $scope.permissions = data.componentPermissionMap;
            if(!$scope.permissions.IT_CASE_MGT.view){
                $state.go('error',{'id':""});
            }
});

        dateTimeFactory.lastPageLedger("alertDetails");
    }
      $scope.init ();

     

      
      
      
      
}]);
        