'use strict';

/**
 * @ngdoc function
 * @name insiderApp.controller:ErrorCtrl
 * @description
 * # ErrorCtrl
 * Controller of the insiderApp
 */
angular.module('insiderApp')
.controller('ErrorCtrl', ['$rootScope', '$scope', '$stateParams', '$log',
	function ($rootScope, $scope, $stateParams, $log) {
		
		//TODO: create a constant object with kpi dashboard errors that can be used around the site
		var errors = {
			1: 'Need AT&T UID to create direct report.',
			2: 'You are not logged into CSP.'
		};


	    $('#alerts').hide();
		$('#cases').hide();
        $('#admin').hide();
        $('#settings').hide();
		$('#breadcrumb-1').hide();
				
		$rootScope.route=[];
			
        if($stateParams.id)
        {            
           // console.log('$stateParams.id is:',$stateParams.id);        
            
            var errorId = parseInt($stateParams.id);
            
          
            if(angular.isNumber(errorId) && !isNaN(errorId)) {             
                 
                $scope.errorMessage =  errors[$stateParams.id];
                 
             } else {
                 $scope.errorMessage = $stateParams.id;
             }
        }        
        else {
            $scope.errorMessage = 'Access Not Allowed.';
        }
		

		//console.log("Your ATTUID is not authorized to access the Insider Threat application.",$stateParams.id);
		$scope.errorMessage = $stateParams.id;
        $rootScope.loading = false;
		$log.error($scope.errorMessage);
	}
]);
