        'use strict';
        angular.module('insiderApp')
        .controller('dispositionCtrl', ['$scope','$rootScope','$http','dispositionPageFactory','caseDetailFactory','getServiceURI','$state','$filter','$sce','$compile','componentService','casesService','$q','$window','$document','dateTimeFactory','$timeout','topSummaryFactory',function ($scope,$rootScope,$http,dispositionPageFactory,caseDetailFactory,getServiceURI,$state,$filter,$sce,$compile,componentService,casesService,$q,$window,$document,dateTimeFactory,$timeout,topSummaryFactory) {


            $rootScope.loading = true; 
            $scope.filterShow = false;
            $scope.showForm = false;
            $scope.showTableHeader = true;
            $scope.hideRowNumbers  = false;
            $rootScope.showMoreContent  = false;
            $scope.userEdit= true;
            $scope.userCanAdd = true;
            $rootScope.fromGraph = "no";
            $scope.table = {
            }; 
            $scope.init=function()
            {     
                topSummaryFactory.checkBasicUserInUPM().then(function(data){
                if(data.upmCheck == "false")
                {
                    $state.go('error',{'id':""});
                }
                });
                topSummaryFactory.checkUserInUPM().then(function(data){
                    if(data.upmCheck == "false")
                {
                    $scope.userEdit = "false";
                }

                });
                topSummaryFactory.getUserPermissions().then(function(data){
                $scope.permissions = data.componentPermissionMap;
                if(!$scope.permissions.IT_ADMIN.view){
                    $state.go('error',{'id':""});
                }
                    console.log("Permissions received ------->");
                   $scope.userCanAdd = $scope.permissions.IT_ADMIN.add;
                    $scope.userCanEdit = $scope.permissions.IT_ADMIN.edit;
                    $scope.userCanDelete = $scope.permissions.IT_ADMIN.delete;
                    console.log("Permissions received ------->"+$scope.userCanAdd);
                    console.log("Permissions received ------->"+$scope.userCanEdit);
                    console.log("Permissions received ------->"+$scope.userCanDelete);
                     $scope.getDispositionData();
                     $scope.getDispositionLogData();
               
            });

            $scope.status = true;

            }
            $scope.init();

            $scope.bulkCloseArrayDuplicate=[];
            $('#bulkCloseBtn').attr('disabled','disabled');
            $rootScope.routedFromAllCases='yes';
          $rootScope.routedtoMycasesTab='no';


            $scope.df = $filter('date')(new Date(), 'yyyyMMdd');

            $rootScope.route = [
            {
                "url" : "home",
                "name" : "Home"
            },
            {
                "url" : "disposition",
                "name" : "Disposition"
            }
            ]
            $scope.itemsPerPage ={};
              $scope.itemsPerPageLog ={};
            $scope.currentPage = 1;
            $scope.currentPageLog = 1;
            $scope.tableData = {};
            $scope.rowsPerPage = 10;
             $scope.rowsPerPageLog = 10;
            $scope.itemsPerPageOptions = [{ name:'10'},{ name:'20' },{ name:'40' }];
            $scope.itemsPerPageOptionsLog = [{ name:'10'},{ name:'20' },{ name:'40' }];
            $scope.itemsPerPageLog = $scope.itemsPerPageOptionsLog[0];
            $scope.itemsPerPage = $scope.itemsPerPageOptions[0];
         $scope.tableData.headers = {               

                       'id' : 'DISPOSITION ID',
                        'dispositionName' : 'DISPOSITION NAME',
                      'createdBy' : 'CREATED BY',
                      'lastUpdatedBy' : 'LAST UPDATED BY',
                      'createdDateTime' : 'CREATED DATE',
                      'lastUpdatedDateTime' : 'LAST UPDATED',
                      'dispositionEnabledView' : 'DISPOSITION ENABLED',
                      'edit'  : 'EDIT',
                      'remove' : 'DELETE'

               };

             //Added below to fields related to sort 
            $scope.sortField = "";
            $scope.sortDirec = "";

            $scope.setSortConditions = function(sortField,sortDirection){
                //console.log('setting the sort conditions in allCasesController to :',sortField,'::',sortDirection);
                $scope.sortField = sortField;
                $scope.sortDirec = sortDirection;
            }

            $scope.onPageChange = function (page) {
                $scope.currentPage = page;
                $scope.updateTableWithSorting($scope.sortField,$scope.sortDirec, "allDispositionsTable");
            }
            $scope.setCurrentPageWhenSorting = function(pageNumber, filterpage){
                if(filterpage == "allDispositionsLogTable"){
                    $scope.currentPageLog =pageNumber;
                }else{
                    $scope.currentPage =pageNumber;
                }
            }
            //End : sort conditions
            $scope.getRowCount = function(i){
                var total = $scope.rowsPerPage,
                currentPage = $scope.currentPage;
                i += currentPage > 1 ? (currentPage * total) - total + 1 : 1;
                i = i>$scope.totalRows?$scope.totalRows:i;
                return i;
            };

            $scope.onRowsPerPageChange = function (page ) {
                $scope.currentPage =1;
                $scope.rowsPerPage = page.name;
                $scope.getDispositionData();
            }	
            //Log Code
             
            $scope.onPageChangeLog = function (page) {
                $scope.currentPageLog = page;
                $scope.updateTableWithSorting($scope.sortField,$scope.sortDirec, "allDispositionsLogTable");
            }

            //End : sort conditions
              $scope.getRowCountLog = function(i){
                var total = $scope.rowsPerPageLog,
                currentPage = $scope.currentPageLog;
                i += currentPage > 1 ? (currentPage * total) - total + 1 : 1;
                i = i>$scope.totalRows?$scope.totalRows:i;
                return i;
            };

            $scope.onRowsPerPageChangeLog = function (page ) {
                $scope.currentPageLog =1;
                $scope.rowsPerPageLog = page.name;
                $scope.getDispositionLogData();
            }		
            function setCrudHtml(value){
                     var on = "";
                      var off = "";
                      if(value.dispositionEnabled){
                           on = " btn-primary active";
                         off = " btn-default";
                      }else{
                         off = " btn-primary active";
                         on = " btn-default";  
                      }
                console.log("Table Rendered ------->"+$scope.permissions);
                    if($scope.userCanEdit){                        
                        value.dispositionName = value.dispositionName.split(' ').join('&nbsp;');
                            value.edit = 
                                         {
                                           "value": '0',
                                           "html":  $sce.trustAsHtml($compile("<a title='id' onclick=updateModelValues("+value.id+",\'"+value.dispositionName+"\')  data-toggle='modal'  data-target='#myModal'><span class='glyphicon glyphicon-pencil' aria-hidden='true'></span></a>")($scope)[0].outerHTML)
                                        };
                    }
                if($scope.userCanDelete){
                            value.remove = 
                                         {
                                           "value": '0',
                                           "html":  $sce.trustAsHtml($compile("<a title='id' onclick='confirmDeleteDisposition("+value.id+")' data-toggle='modal'  data-target='#myModal3'><span class='glyphicon glyphicon-trash' aria-hidden='true'></span></a>")($scope)[0].outerHTML)
                                        };
                }
                if($scope.userCanEdit){
                            value.dispositionEnabledView =  {
                                           "value": '0',
                                           "html":  $sce.trustAsHtml($compile('<div class="btn-group btn-toggle" onclick="dispositionEnabledToggle(this,'+value.id+' )" "><button class="btn'+ on+'">YES</button><button class="btn '+ off+'">NO</button></div>')($scope)[0].outerHTML)
                                        };
                }
                return value;
            }
            
            $scope.getDispositionData = function(){
            var tableData =  dispositionPageFactory.getDisposition($scope.currentPage-1,$scope.rowsPerPage);
            $q.all([tableData]).then(function(resultData){		
                var data = resultData[0];	
                console.log(data)
                $rootScope.loading = false;      	
                $scope.totalPages = data.totalPages;
                $scope.totalRows = data.totalRecords;
           /*     data.dispositionTypeList = _.filter(data.dispositionTypeList, function(item){
                          return item.removed == false;
                      });*/
                $scope.totalDispositions= data.totalRecords;  
              
                for( var i=0;i<data.dispositionTypeList.length;i++){                   
                    $(".rows-per-page label").text("Results per page");
                } 
                
                        angular.forEach(data.dispositionTypeList,function(value,key){
                     value.lastUpdatedBy =  $filter('date')(value.lastUpdatedBy, 'MM/dd/yyyy');
                      value.createdDateTime = $filter('date')( value.createdDateTime, 'MM/dd/yyyy');
                      value.lastUpdatedDateTime = $filter('date')(value.lastUpdatedDateTime, 'MM/dd/yyyy');
                    value = $.extend({}, value, setCrudHtml(value));
                            });
                console.log(data.dispositionTypeList)

                $scope.tableData.tbody = data.dispositionTypeList;
            });
        
        }
           
       $window.dispositionEnabledToggle = function(ctx, i){
        $(ctx).find('.btn').toggleClass('active');
        if ($(ctx).find('.btn-primary').length >0) {
            $(ctx).find('.btn').toggleClass('btn-primary');
        }    
        $(ctx).find('.btn').toggleClass('btn-default');
                $scope.dispUdpateId = i;
                $(ctx).find('.btn .active').text();
                $scope.dispositionEnabled = $(ctx).find('.active').text() == 'YES'? true : false;
                $scope.updateDisposition('dispEnabled')
            }

             $scope.disposition = {};        
              $scope.addNewDisposition=function(){
                  $scope.isDispositionName = false;
                      if($scope.addDispositionName !== undefined){
                         var _dataObj = {
                         'id':"",
                        'dispositionName' : $scope.addDispositionName,
                              'createdBy' :  $rootScope.loggedAttId
                    };
                    console.log(_dataObj);
                        dispositionPageFactory.createDisposition(_dataObj).then(function(data){	           
                            window.location.reload();              		                         
                        });   
                      }else{
                          $scope.isDispositionName = true;
                      }

                }
              $scope.clearNewDisposition = function(){
                  $scope.addDispositionName = "";
              }
          $window.updateModelValues = function(id, name){ 
               $scope.isUpdateDispositionName = false;
                    $scope.dispUdpateId = id;
              //$scope.UpdateDispositionName = name;
              console.log(name);
              $("input[name=dispositionName]").attr('placeholder',name);
                }
          $scope.updateDisposition=function(flag){

              if(flag == "dispName"){
                if($scope.UpdateDispositionName !== undefined){
                     var _dataObj = {
                    'id': $scope.dispUdpateId,
                  'dispositionName' : decodeURI($scope.UpdateDispositionName),
                   'lastUpdatedBy' : $rootScope.loggedAttId
                }
                dispositionPageFactory.updateDisposition(_dataObj);
                    $("#myModal").hide();
                    $window.location.reload();
                      

              }else{
                  $scope.isUpdateDispositionName = true;
              }
              }else if(flag == "dispEnabled"){
                  var _dataObj = {
                    'id': $scope.dispUdpateId,
                  'dispositionEnabled' : $scope.dispositionEnabled,
                      'lastUpdatedBy' :  $rootScope.loggedAttId
              }              
                dispositionPageFactory.updateDisposition(_dataObj);
                  $("#myModal").hide();
                    $window.location.reload();
                  }              
         
            }
          
          $window.confirmDeleteDisposition = function(x){                  
                    $scope.indexVal=x;
                }		
          $scope.deleteDisposition=function(){
               var _dataObj = {
                    'id': $scope.indexVal,                 
                    'removed' : "true",
                    'lastUpdatedBy' :  $rootScope.loggedAttId
              }                         
                    dispositionPageFactory.deleteDisposition(_dataObj);
                    $("#myModal3").hide();
                    $window.location.reload();
                }
          if($rootScope.loggedUserName == undefined){
                $rootScope.loggedUserName='PRASOONA GOLI';
            }
          $scope.loggedFirstName=$rootScope.loggedUserName.split(' ')[0];
          $scope.loggedLastName =$rootScope.loggedUserName.split(' ')[1];   
          $('#myModal2').on('hidden.bs.modal', function () {
                angular.element(this).find("div[data-toggle='dropdown']>button").text($scope.caseDispositionSelectedOption.name);
            });
                $scope.currentPageActivity = 1;
                     $scope.AcitivityLogtableData = {};
                     $scope.rowsPerPageActivity = 10;
                     $scope.AcitivityLogtableData.headers = {  
                      'updatedBy' : 'UID',
                      'updatedDateTime' : 'UPDATED TIME',
                      'eventType':'CHANGE TYPE',
                      'change':'CHANGE'
                  };
            $scope.getDispositionLogData = function(){
                dispositionPageFactory.getDispositionLogDataWithSorting($scope.currentPageLog-1,$scope.rowsPerPageLog, "updatedDateTime", "DESC").then(function(data){
                    $scope.tableOptionsLog = [{ name:"10", selected: true },{ name:"20" },{ name:"30" }];          

                      $scope.activityData=data.settingsHistoryPage.content; 
                        $scope.totalPagesLog = data.settingsHistoryPage.totalPages;
                    
                $scope.totalRowsLog = data.settingsHistoryPage.totalElements;
                      for(var i=0;i<$scope.activityData.length;i++)
                      {                        
                            $scope.activityData[i].createdDateTime = dateTimeFactory.changeToLocalTimeFromDate($scope.activityData[i].createdDateTime);
                            $scope.activityData[i].updatedDateTime = dateTimeFactory.changeToLocalTimeFromDate($scope.activityData[i].updatedDateTime);
                            if($scope.activityData[i].change){
                              //  debugger;
                               var str =  ($scope.activityData[i].change).split('\t').join('<br>');
                                $scope.activityData[i].change=str.split(' ').join('&nbsp;&nbsp;')  
                            }                        
                      }
                    $scope.AcitivityLogtableData.tbody = $scope.activityData;
                     $('.rows-per-page label').text('Results per page');
                   });
            }
            
            $scope.updateTableWithSorting = function(sortField,sortDirection, filtertable) {
                $rootScope.loading = true;	 
                if(filtertable == "allDispositionsTable"){
                     dispositionPageFactory.getDispositionDataWithSorting($scope.currentPage - 1, $scope.rowsPerPage, sortField,sortDirection).then(function(data) {
                        $scope.totalPages = data.totalPages;
                        $scope.totalDispositions = data.totalRecords;
                         $scope.totalRows = data.totalRecords;
                        var tableBody = [];
                        angular.forEach(data.dispositionTypeList, function(v, i) {
                            v.lastUpdatedBy =  $filter('date')(v.lastUpdatedBy, 'MM/dd/yyyy');
                      v.createdDateTime = $filter('date')( v.createdDateTime, 'MM/dd/yyyy');
                      v.lastUpdatedDateTime = $filter('date')(v.lastUpdatedDateTime, 'MM/dd/yyyy');                           
                         v = $.extend({}, v, setCrudHtml(v)); 
                            this.push(v);
                        }, tableBody);   
                         console.log("oooooooooooooooo");
                         console.log(tableBody)
                        $scope.tableData.tbody = tableBody;
                        $rootScope.loading = false;
                    });
                } else  if(filtertable == "allDispositionsLogTable"){
                     dispositionPageFactory.getDispositionLogDataWithSorting($scope.currentPageLog - 1, $scope.rowsPerPageLog,sortField,sortDirection).then(function(data) {           
                        var AcitivityLogtableData = [];
                        angular.forEach(data.settingsHistoryPage.content, function(v, i) {                           
                             v.createdDateTime = dateTimeFactory.changeToLocalTimeFromDate(v.createdDateTime);
                        v.updatedDateTime = dateTimeFactory.changeToLocalTimeFromDate(v.updatedDateTime); 
                            if(v.change){
                          //  debugger;
                           var str =  (v.change).split('\t').join('<br>');
                            v.change=str.split(' ').join('&nbsp;&nbsp;')  
                        }
                            this.push(v);
                        }, AcitivityLogtableData);                    
                        $scope.AcitivityLogtableData.tbody = AcitivityLogtableData;
                        $rootScope.loading = false;
                    });
                }

                };
         }]);
