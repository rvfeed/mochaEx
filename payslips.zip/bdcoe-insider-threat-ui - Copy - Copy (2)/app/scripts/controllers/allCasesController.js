'use strict';
angular.module('insiderApp')
.controller('allCasesCtrl', ['$scope','$rootScope','$http','allCasesFactory','caseDetailFactory','getServiceURI','$state','$filter','$sce','$compile','componentService','casesService','$q','$window','$document','dateTimeFactory','$timeout','topSummaryFactory','dispositionFactory',function ($scope,$rootScope,$http,allCasesFactory,caseDetailFactory,getServiceURI,$state,$filter,$sce,$compile,componentService,casesService,$q,$window,$document,dateTimeFactory,$timeout,topSummaryFactory,dispositionFactory) {

     
	$rootScope.loading = true; 
    $scope.filterShow = false;
	$scope.showForm = false;
	$scope.showTableHeader = true;
    $scope.hideRowNumbers  = false;
    $rootScope.showMoreContent  = false;
    $rootScope.fromGraph = "no";
    $rootScope.routedFromAllAlerts = 'no';
    $scope.userEdit= true;
	$scope.table = {
	};

	$scope.filterCaseDisp = [];
    $scope.CaseDispositionOptions = [
      { name:'Select upon case Closure',value:'Select upon case Closure'}
      
    ];
    $rootScope.caseDetailsFilterSelected = "no";
    $rootScope.alertDetailsFilterSelected = "no";
    $scope.caseDispositionSelectedOption = $scope.CaseDispositionOptions[0];
    dispositionFactory.getAllDisposition().then(function(data){
        $.each(data.dispositionTypeList,function(i,v)
        {
            var dorpdown ={}
            dorpdown.name = data.dispositionTypeList[i].dispositionName;
            dorpdown.value = data.dispositionTypeList[i].dispositionName;
            $scope.filterCaseDisp.push(dorpdown);
            dorpdown.disabled = data.dispositionTypeList[i].dispositionEnabled ? false : true; 
            $scope.CaseDispositionOptions.push(dorpdown);
        });
             
        //$scope.selectedFilterAlertDisp = $scope.filterAlertDisp[0];
        $scope.$watch('selectedFilterAlertDisp', function(newValue){});
        $scope.$watch('caseDispositionSelectedOption', function(newValue){});
    });
    
    $scope.lftContent = function(openLeft){
        if(openLeft){
            $scope.openLeft = false;
        } else {
            $scope.openLeft = true;
        }
    };

    $scope.leftLoad = function(){

      $scope.sideHeight = $window.innerHeight - ( 75 + 50 + $document.find('header').height() + $document.find('footer').height() );
      $document.find('.sideInfo').height($scope.sideHeight);
    };

    $scope.leftLoad();
    $(window).resize(function(){
      $scope.leftLoad();
    });
    $scope.init=function()
    {
   
//      if($rootScope.allCaseFilterSelected==='yes'){
//               // $rootScope.loading = true;
//                $scope.allCasesFilterData();
//          //$rootScope.allCaseDetailsFromFilters =[];
//          
//               // $scope.updateAllCases();
//
//      }

        topSummaryFactory.checkBasicUserInUPM().then(function(data){
        if(data.upmCheck == "false")
        {
            $state.go('error',{'id':""});
        }
        });
        topSummaryFactory.checkUserInUPM().then(function(data){
            if(data.upmCheck == "false")
        {
            $scope.userEdit = "false";
        }
            
        });
        topSummaryFactory.getUserPermissions().then(function(data){
           $scope.permissions = data.componentPermissionMap;
            $scope.viewIncidentResponse = $scope.permissions.IT_INCIDENCE_RESPONSE.view;
            $scope.userCanEdit = $scope.permissions.IT_CASE_MGT.edit;
            $scope.userCanAdd = $scope.permissions.IT_CASE_MGT.add;
            if(!$scope.permissions.IT_CASE_MGT.view){
                $state.go('error',{'id':""});
            }
        });
        dateTimeFactory.lastPageLedger("allCases");
                                                

    }
    

	$scope.bulkCloseArrayDuplicate=[];
	$('#bulkCloseBtn').attr('disabled','disabled');
 	$rootScope.routedFromAllCases='yes';
    $rootScope.routedtoMycasesTab='no';

	$scope.getCSVServiceLink = function(){
		var selectedAlert = $scope.allcase.selectedAlert.length == 0 ? "" : _.pluck($scope.allcase.selectedAlert, 'id');
		var selectedCompany = encodeURIComponent($scope.allcase.selectedCompany);
		var selectedInvestigator = $scope.allcase.selectedInvestigator.length == 0 ? "" : _.pluck($scope.allcase.selectedInvestigator, 'id');
		var alertProbabilityMinimum=($scope.allcase.alertMin=== null)?'':$scope.allcase.alertMin;
		var	alertProbabilityMaximum= ($scope.allcase.alertMax=== null)?'':$scope.allcase.alertMax;
        var selectedLocationId = $scope.allcase.locationId.length == 0 ? [] : _.pluck($scope.allcase.locationId, 'id');
		var createdDateTime=[],latestAlertDateTime=[];
      	
      	if( $scope.allcase.createdDateTime.name.length){
            createdDateTime = dateTimeFactory.getDateRangesFromRawDatesAsString($scope.allcase.createdDateTime.name);
        }else{
            createdDateTime = dateTimeFactory.getDateRanges($scope.allcase.createdDateTime.value);
        }
        
      	if( $scope.allcase.latestAlertDateTime.name.length){
            latestAlertDateTime = dateTimeFactory.getDateRangesFromRawDatesAsString($scope.allcase.latestAlertDateTime.name);
        }else{
             latestAlertDateTime =dateTimeFactory.getDateRanges($scope.allcase.latestAlertDateTime.value);
        }
        if($scope.allcase.createdDateTime.name.length == 0){
            createdDateTime = ["",""];
        }
        if($scope.allcase.latestAlertDateTime.name.length == 0 ){
            latestAlertDateTime =["",""];
        }

        if(createdDateTime[0] !== "" &&(createdDateTime[1] === undefined ||createdDateTime[1] === "") )
        {
          createdDateTime[1]=createdDateTime[0];
        }
        if(latestAlertDateTime[0] !== "" &&(latestAlertDateTime[1] === undefined ||latestAlertDateTime[1] === "") )
        {
          latestAlertDateTime[1]=latestAlertDateTime[0];
        }
	
		if($scope.myCasesActive){
			selectedInvestigator = $rootScope.loggedAttId;
		}

		var selectedFilterCaseDisp = $scope.allcase.selectedFilterCaseDisp.length == 0 ? "" : _.pluck($scope.allcase.selectedFilterCaseDisp, 'id');
  	    var link = getServiceURI.build('insiderThreat', 'exportCasesData')+'?loggedAttId=&caseId='+$scope.allcase.caseID+'&alertType='+selectedAlert+'&suspectUID='+$scope.allcase.suspectId+'&alertProbabilityMinimum='+alertProbabilityMinimum+'&alertProbabilityMaximum='+alertProbabilityMaximum+'&companyName='+selectedCompany+'&location='+selectedLocationId+'&investigatorUId='+selectedInvestigator+'&status='+$scope.allcase.statusType+'&caseDisposition='+selectedFilterCaseDisp+'&fromCreatedDateTime='+createdDateTime[0]+'&toCreatedDateTime='+createdDateTime[1]+'&fromLatestAlertDate='+latestAlertDateTime[0]+'&toLatestAlertDate='+latestAlertDateTime[1];
        console.log(" after encode export Link ::::::::::::",link);
        return link;
    };
  
    $scope.df = $filter('date')(new Date(), 'yyyyMMdd');
            
    $rootScope.route = [
    {
        "url" : "home",
        "name" : "Home"
    },
    {
        "url" : "allCases",
        "name" : "All Cases"
    }
    ]
    $scope.itemsPerPage ={};
    $scope.currentPage = 1;
    $scope.tableData = {};
    $scope.rowsPerPage = 25;
    $scope.itemsPerPageOptions = [{ name:'25'},{ name:'40' },{ name:'60' }];
    $scope.itemsPerPage = $scope.itemsPerPageOptions[0];
    $scope.tableData.headers = {
		'caseCheckBox' : ' ',
        'id' : 'CASE ID',
        'createdDateTime':'CREATED DATE',
        'alertType' : 'ALERT TYPE',
       /* 'caseDisposition':'DISPOSITION',*/
        'keyField' : 'SUSPECT UID',
        'countOfAlerts':'COUNT OF ALERTS',		
        'latestAlertDate':'RECENT ABNORMAL EVENT DATE',
        'maxProbability' : 'ALERT PROBABILITY',
        'mobility' : 'MOBILITY',
        'companyName' : 'COMPANY NAME',
        'locationSiteId' : 'LOCATION SITE ID',
        'status' : 'STATUS',
        'caseDisposition':'DISPOSITION',
        'investigatorId' : 'INVESTIGATOR UID'
      
    };

     //Added below to fields related to sort 
    $scope.sortField = "";
    $scope.sortDirec = "";

    $scope.setSortConditions = function(sortField,sortDirection){
    	//console.log('setting the sort conditions in allCasesController to :',sortField,'::',sortDirection);
    	$scope.sortField = sortField;
    	$scope.sortDirec = sortDirection;
    }
   
    $scope.onPageChange = function (page) {
        $scope.currentPage = page;
        $scope.updateTableWithSorting($scope.sortField,$scope.sortDirec);
    }
	$scope.setCurrentPageWhenSorting = function(pageNumber){
	   	$scope.currentPage =pageNumber;
    }
    //End : sort conditions
    $scope.getRowCount = function(i){
		var total = $scope.rowsPerPage,
		currentPage = $scope.currentPage;
		i += currentPage > 1 ? (currentPage * total) - total + 1 : 1;
        i = i>$scope.totalRows?$scope.totalRows:i;
		return i;
	};

    $scope.onRowsPerPageChange = function (page ) {
    	$scope.currentPage =1;
      	$scope.rowsPerPage = page.name;
        $scope.updateAllCases();
	}
    
    var abonormatEventDate='';
	
	$scope.allcase = {};
	$scope.allcase.caseID = '';
	$scope.allcase.selectedAlert = [];
	$scope.allcase.suspectId = '';
	$scope.allcase.alertMin = '';
	$scope.allcase.alertMax = '';
	$scope.allcase.selectedCompany = '';
	$scope.allcase.locationId = [];
	$scope.allcase.selectedInvestigator = [];
	$scope.allcase.statusType = [];
	$scope.allcase.selectedFilterCaseDisp = [];
	$scope.allcase.createdDateTime = {
        'name' : '',
        'value' : ''
    };
    $scope.allcase.latestAlertDateTime = {
        'name' : '',
        'value' : ''
      };

	
	var params = {
		"loggedAttId": $rootScope.loggedAttId,
		"caseId": $scope.allcase.caseID,
		"alertType": _.pluck($scope.allcase.selectedAlert, 'id'),
		"suspectUID": $scope.allcase.suspectId,
		"alertProbabilityMinimum": $scope.allcase.alertMin,
		"alertProbabilityMaximum": $scope.allcase.alertMax,
        "mobility" : $scope.allcase.mobility,
		"companyName": $scope.allcase.selectedCompany,
		"location": _.pluck( $scope.allcase.locationId, 'id'),
		"investigatorUId":_.pluck( $scope.allcase.selectedInvestigator, 'id'),
		"status": $scope.allcase.statusType,
		"caseDisposition":_.pluck($scope.allcase.selectedFilterCaseDisp, 'id'),
		"fromCreatedDateTime":"",
		"toCreatedDateTime":"",
		"fromLatestAlertDate":"",
		"toLatestAlertDate":""
	};
   if($rootScope.routedtoMycasesTab==='yes')
      {
        //console.log("routed from mycases");
        $scope.myCasesActive=true;
      }
      else{
        $scope.myCasesActive=false;
      }
    
        $scope.updateAllCasesParams = function(){
        
        var createdDateTime=[],latestAlertDateTime=[];
        if( $scope.allcase.createdDateTime.name.length){
            createdDateTime = dateTimeFactory.getDateRangesFromRawDatesAsString($scope.allcase.createdDateTime.name);
        }else{
            createdDateTime = dateTimeFactory.getDateRanges($scope.allcase.createdDateTime.value);
        }
        if($scope.allcase.latestAlertDateTime.name.length){
            latestAlertDateTime = dateTimeFactory.getDateRangesFromRawDatesAsString($scope.allcase.latestAlertDateTime.name);
        }else{
             latestAlertDateTime =dateTimeFactory.getDateRanges($scope.allcase.latestAlertDateTime.value);
        }
        if($scope.allcase.createdDateTime.name.length == 0){
            createdDateTime = ["",""];
        }
        if($scope.allcase.latestAlertDateTime.name.length == 0 ){
            latestAlertDateTime =["",""];
        }

        if(createdDateTime[0] !== "" &&(createdDateTime[1] === undefined ||createdDateTime[1] === "") )
        {
          createdDateTime[1]=createdDateTime[0];
        }
         if(latestAlertDateTime[0] !== "" &&(latestAlertDateTime[1] === undefined ||latestAlertDateTime[1] === "") )
        {
          latestAlertDateTime[1]=latestAlertDateTime[0];
        }
        if($rootScope.allCaseFilterSelected !== 'yes'){
          $rootScope.allCaseDetailsFromFilters = []; 
//        }else{
//            $rootScope.allCaseFilterSelected = 'no';
        }
           
            
        var params = {
             "loggedAttId": $rootScope.loggedAttId,
            "caseId":  $scope.allcase.caseID,
            "alertType": _.pluck($scope.allcase.selectedAlert, 'id'),
            "suspectUID": $scope.allcase.suspectId,
            "alertProbabilityMinimum":$scope.allcase.alertMin,
            "alertProbabilityMaximum": $scope.allcase.alertMax,
            "companyName":  $scope.allcase.selectedCompany,
            "location": _.pluck($scope.allcase.locationId, 'id'),
            "investigatorUId":  _.pluck($scope.allcase.selectedInvestigator, 'id'),
            "status":  $scope.allcase.statusType,
            "caseDisposition" : _.pluck($scope.allcase.selectedFilterCaseDisp , 'id'),
            "fromCreatedDateTime":createdDateTime[0],
            "toCreatedDateTime": createdDateTime[1],
            "fromLatestAlertDate":latestAlertDateTime[0],
            "toLatestAlertDate":latestAlertDateTime[1]
        };
       /*  $scope.fromCreatedDateTime = createdDateTime[0];
        $scope.toCreatedDateTime = createdDateTime[1];
        $scope.fromLatestAlertDate = latestAlertDateTime[0];
        $scope.toLatestAlertDate = latestAlertDateTime[1];
        */
        $rootScope.allCaseDetailsFromFilters[0] =
                    {'caseId' : $scope.allcase.caseID,
                     'fromCreatedDateTime' : createdDateTime[0],
                     'toCreatedDateTime' : createdDateTime[1],
                     'alertType' :  _.pluck($scope.allcase.selectedAlert, 'id'),
                     'investigatorId' : _.pluck($scope.allcase.selectedInvestigator, 'id'),
                     'caseDisposition' :  _.pluck($scope.allcase.selectedFilterCaseDisp , 'id'),
                     'suspectId' : $scope.allcase.suspectId,
                     'fromLatestAlertDate' : latestAlertDateTime[0],
                     'toLatestAlertDate' : latestAlertDateTime[1],
                     'alertProbabilityMaximum' : $scope.allcase.alertMax,
                     'alertProbabilityMinimum' : $scope.allcase.alertMin,
                     'companyName' : $scope.allcase.selectedCompany,
                     'locationId' : _.pluck($scope.allcase.locationId, 'id'),
                     'statusType' : $scope.allcase.statusType
                    };
           
        console.log($rootScope.allCaseDetailsFromFilters)
        console.log(params);
        return params;
        
    };
    $scope.allCasesFilterData = function(){
        //$scope.allcase.caseID = 1225;
        if($rootScope.allCaseDetailsFromFilters[0]){
        $scope.allcase.caseID = $rootScope.allCaseDetailsFromFilters[0].caseId;
        $scope.fromCreatedDateTime = $rootScope.allCaseDetailsFromFilters[0].fromCreatedDateTime;
        $scope.toCreatedDateTime = $rootScope.allCaseDetailsFromFilters[0].toCreatedDateTime;
        //$scope.allcase.selectedAlert = $rootScope.allCaseDetailsFromFilters[0].alertType;
        //$scope.allcase.selectedFilterCaseDisp = $rootScope.allCaseDetailsFromFilters[0].caseDisposition;
        $scope.allcase.suspectId = $rootScope.allCaseDetailsFromFilters[0].suspectId;
        $scope.fromLatestAlertDate = $rootScope.allCaseDetailsFromFilters[0].fromLatestAlertDate;
        $scope.toLatestAlertDate = $rootScope.allCaseDetailsFromFilters[0].toLatestAlertDate;
        $scope.allcase.alertMax = $rootScope.allCaseDetailsFromFilters[0].alertProbabilityMaximum;
        $scope.allcase.alertMin = $rootScope.allCaseDetailsFromFilters[0].alertProbabilityMinimum;
        $scope.allcase.selectedCompany = $rootScope.allCaseDetailsFromFilters[0].companyName;
        //$scope.allcase.locationId = $rootScope.allCaseDetailsFromFilters[0].locationId;
        //$scope.allcase.selectedInvestigator = $rootScope.allCaseDetailsFromFilters[0].investigatorId;
        $scope.allcase.statusType = $rootScope.allCaseDetailsFromFilters[0].statusType;
        console.log($scope.fromCreatedDateTime);
        console.log($scope.fromLatestAlertDate);
        $scope.allcase.createdDateTime.name = $scope.fromCreatedDateTime ? $scope.convertDate($scope.fromCreatedDateTime,$scope.toCreatedDateTime) : "";
        $scope.allcase.latestAlertDateTime.name =$scope.fromLatestAlertDate ? $scope.convertDate($scope.fromLatestAlertDate, $scope.toLatestAlertDate) : "";
        
        $.each($rootScope.allCaseDetailsFromFilters[0].caseDisposition,function(i,v){
            $scope.allcase.selectedFilterCaseDisp.push({id:v});
        });
        $.each($rootScope.allCaseDetailsFromFilters[0].locationId,function(i,v){
            $scope.allcase.locationId.push({id:v});
        });
        $.each($rootScope.allCaseDetailsFromFilters[0].investigatorId,function(i,v){
            $scope.allcase.selectedInvestigator.push({id:v});
        });
        $.each($rootScope.allCaseDetailsFromFilters[0].alertType,function(i,v){
            $scope.allcase.selectedAlert.push({id:v});
        });
        }
        //console.log($scope.allcase.selectedFilterCaseDisp);
      }
    $scope.convertDate = function(value1,value2){
        var v1 = value1.split("-")
        var dateValue1 = v1[1]+"/"+v1[2]+"/"+v1[0];
        var v2 = value2.split("-")
        var dateValue2 = v2[1]+"/"+v2[2]+"/"+v2[0];
        return dateValue1+"-"+dateValue2;
    }
	$scope.allCasesTabs = function(value){
		$scope.allCasesTab = value;
		$scope.resetOnlyFilters();
		 var $btn = $document.find('.multiselect-parent button');
		if('myCasesActive' === $scope.allCasesTab){
			$btn.attr('disabled', true);
            $('#filterCaseDisp .btn').attr('disabled', false);
			$('#alertType .btn').attr('disabled', false);
			$('#Investigator .btn').attr('disabled', true);
      $('#LocationId .btn').attr('disabled',false);
			$scope.allCasesActive = false;
			$scope.myCasesActive = true;
		} else {
			$btn.attr('disabled', false);
			$scope.allCasesActive = true;
			$scope.myCasesActive = false;			
		}
        $scope.currentPage = 1;
        $scope.rowsPerPage = 25;
         $scope.itemsPerPage = $scope.itemsPerPageOptions[0];
        $scope.updateAllCases();
    }
    if($rootScope.allCaseFilterSelected==='yes'){
               // $rootScope.loading = true;
                $scope.allCasesFilterData();
            
                $rootScope.allCaseDetailsFromFilters =[];
          
               // $scope.updateAllCases();

    }
    var params = $scope.updateAllCasesParams();

    if(casesService.isMyCasesSelected()){
    	$scope.allCasesActive = false;
	    $scope.myCasesActive = true;
	    // casesService.setMyCasesSelected(false);
        params.investigatorUId = [$rootScope.loggedAttId];
        console.log("Invetigator11111------>"+params.investigatorUId);
       
    }else {
	    $scope.allCasesActive = true;
	    $scope.myCasesActive = false;
    }
    //if($scope.myCasesActive = false){
    //    var params = $scope.updateAllCasesParams();
   // }
        console.log(params);
	var tableData =  allCasesFactory.getAllCasesData(params,$scope.currentPage-1,$scope.rowsPerPage),
		companyName = allCasesFactory.getCompanyDetails(),
		investigator = caseDetailFactory.getCaseOwners(),
    locationId = allCasesFactory.getLocationDetails();
	$q.all([tableData,companyName,investigator,locationId]).then(function(resultData){
		
		var data = resultData[0];
		$scope.prepareCasesTableData(data);
		if( data.casePage){
     	data= data.casePage.content;
        for( var i=0;i<data.length;i++){
	   		$(".rows-per-page label").text("Results per page");
	    }
		
		var _alertArray = [], _investigatorArray= [],_statusArray = [], _locationArray= [];	
        $.each(data,function(i,v)
        {
            _alertArray.push(v.alertType);
		});
        
		_alertArray=componentService.getUniqueArray(_alertArray);
        _statusArray = ['New','Open','Referred','Recycled','InProgress','Closed'];
	
		$scope.alertType =  [
  			/*{ name:'Select alert type' }*/
  		];	
	
		$.each(_alertArray,function(i,v){
			$scope.alertType.push({
				name:v
			});
		});
		    
        }
      	$scope.csv = $scope.getCSVServiceLink();
       
	    
		
		//company data generation
		$scope.companyName = [];
		
		$.each(resultData[1].data,function(i,v){		
			$scope.companyName.push(v.companyName);
		});
		
		$scope.Investigator=[
 			/*{ name:'Select investigator'}*/
 		];
		
		$scope.allCasesDropDown = [
		{
			'name' : "All Cases"
		}
		];	
	
	    var caseOwnersData = resultData[2];
		
	    for(var i=0;i<caseOwnersData.caseManagerList.length;i++){
	    	$scope.Investigator.push({'name':caseOwnersData.caseManagerList[i].attUserId}) ;
			$scope.allCasesDropDown.push({'name':caseOwnersData.caseManagerList[i].attUserId}) ;
		}
	  $scope.LocationId = [];

    $.each(resultData[3].data,function(i,v)
    {
      $scope.LocationId.push({name:v});
    });
	/*	$scope.table.selectedCasesDDown = {
			'name' : "All Cases"
		};*/
		
		$scope.statusArray = _statusArray;
		$scope.showForm = true;
		setTimeout(function(){
		if(casesService.isMyCasesSelected()){
			$('#filterCaseDisp .btn').attr('disabled', false);
			$('#alertType .btn').attr('disabled', false);
			$('#Investigator .btn').attr('disabled', true);
      $('#LocationId .btn').attr('disabled',false);
       		casesService.setMyCasesSelected(false);
            
        }
        $.each($scope.allcase.statusType,function(i,v){
                $("#allCases"+v).prop('checked', true);
            }); 
        $.each($scope.allcase.selectedFilterCaseDisp,function(i,v){
            $("a:contains('"+v+"') span").addClass("glyphicon glyphicon-ok");
           });
            $.each($scope.allcase.selectedAlert,function(i,v){
            $("a:contains('"+v+"') span").addClass("glyphicon glyphicon-ok");
           });
            $.each($scope.allcase.locationId,function(i,v){
            $("a:contains('"+v+"') span").addClass("glyphicon glyphicon-ok");
           });
            $.each($scope.allcase.selectedInvestigator,function(i,v){
            $("a:contains('"+v+"') span").addClass("glyphicon glyphicon-ok");
           });
            
            
            
        }, 1000);
		
	});

    if($rootScope.loggedUserName == undefined){
        $rootScope.loggedUserName='PRASOONA GOLI';
    }
    $scope.loggedFirstName=$rootScope.loggedUserName.split(' ')[0];
    $scope.loggedLastName =$rootScope.loggedUserName.split(' ')[1]; 

  	$scope.cancelAddNote = function(){
        $scope.addNotesMsg = '';
        $('#bulkclosenotes').val('');
        $scope.caseDispositionSelectedOption=$scope.CaseDispositionOptions[0];
    };

	$('#myModal2').on('hidden.bs.modal', function () {
        angular.element(this).find("div[data-toggle='dropdown']>button").text($scope.caseDispositionSelectedOption.name);
    });

  	$scope.bulkClose = function(){
    	$scope.bulkCloseArray = [];

    	for(var i=0;i<$scope.totalCases;i++){
            if($('#caseCheckbox'+i).prop('checked')){
                $scope.bulkCloseArray.push($('#caseCheckbox'+i).val());
            }
        }
       	 
        if($scope.caseDispositionSelectedOption.value === "Select upon case Closure"){
        	 $scope.closeDispositionPopup = true;   
        	return false;
        }
		 $scope.savebulkCloseInfo = {
            "name": $scope.loggedFirstName + ' ' + $scope.loggedLastName,
            "attUserId": $rootScope.loggedAttId,
            "content": $('#bulkclosenotes').val()
          }
        
        allCasesFactory.bulkCloseOfAllCasesInfo($scope.savebulkCloseInfo,$scope.bulkCloseArray,$scope.caseDispositionSelectedOption.value).then(function(data){

	        $scope.serErrorMsg = data.serviceResult.errorMessage;
            $('#myModal').modal('hide');
            $('#myModal2').modal('hide');
            
          	if(!data.serviceResult.success){
          		$scope.closeCasePopup = true;
      		
          		$scope.bulkcloseCaseIds=[];
          		$scope.bulkcloseCaseIds=data.details;
          		$scope.cancelAddNote();
          		
          		return false;
          	}
            $scope.currentPage = 1;
            $scope.rowsPerPage = 25;
             $scope.itemsPerPage = $scope.itemsPerPageOptions[0];

           $scope.updateAllCases();
	    });
	}

    $scope.closeCasePopupClose = function(){
    	$state.reload();
    	$scope.closeCasePopup = false;   
    }
    $scope.closeCasePopupOpen = function(){
      $scope.closeCasePopup = true;
    }    
    $scope.closeDispPopupClose = function(){
      $scope.closeDispositionPopup = false;   
	}
 
 	$scope.invokeUpdateAllCases = function(){
        
        $scope.currentPage = 1;
        $scope.rowsPerPage = 25;
        $scope.itemsPerPage = $scope.itemsPerPageOptions[0];
        
         //console.log("hello... 55555")
         /*$rootScope.allCaseDetailsFromFilters =
                    [{'caseId' : $scope.allcase.caseID,
                     'fromCreatedDateTime' : $scope.fromCreatedDateTime,
                     'toCreatedDateTime' : $scope.toCreatedDateTime,
                     'alertType' :  _.pluck($scope.allcase.selectedAlert, 'id'),
                     'investigatorId' : _.pluck($scope.allcase.selectedInvestigator, 'id'),
                     'caseDisposition' :  _.pluck($scope.allcase.selectedFilterCaseDisp , 'id'),
                     'suspectId' : $scope.allcase.suspectId,
                     'fromLatestAlertDate' : $scope.fromLatestAlertDate,
                     'toLatestAlertDate' : $scope.toLatestAlertDate,
                     'alertProbabilityMaximum' : $scope.allcase.alertMax,
                     'alertProbabilityMinimum' : $scope.allcase.alertMin,
                     'companyName' : $scope.allcase.selectedCompany,
                     'locationId' : _.pluck($scope.allcase.locationId, 'id'),
                     'statusType' : $scope.allcase.statusType
                    }];
                    */
        $scope.updateAllCases();
    }
 
	$scope.updateAllCases = function(){
        $(".hasDatepicker").hide();
		//$scope.addValue();
		$rootScope.loading = true; 		
		

		var params = $scope.updateAllCasesParams();
		
		if($scope.myCasesActive){
			
			params.investigatorUId = [$rootScope.loggedAttId];
		}
        console.log("Invetigator------>"+params.investigatorUId);
		$scope.csv = $scope.getCSVServiceLink();
		allCasesFactory.getAllCasesData(params,$scope.currentPage-1,$scope.rowsPerPage).then(function(data){
	       $scope.prepareCasesTableData(data);
		});
	
		$scope.bulkCloseArrayDuplicate=[];	
        
		$('#bulkCloseBtn').attr('disabled','disabled');
        $rootScope.allCaseFilterSelected = "yes";
	};
    $scope.resetOnlyFilters = function(){
        $scope.allcase.caseID = '';
    	$scope.allcase.resetField = '';
		$scope.allcase.selectedAlert = [];
		$scope.allcase.suspectId = '';
		$scope.allcase.alertMin = '';
		$scope.allcase.alertMax = '';
		$scope.allcase.selectedCompany = '';
		$scope.allcase.locationId = [];
		$scope.allcase.selectedInvestigator =[];
		/*$scope.table.selectedCasesDDown={
			'name' : "All Cases"
		};*/
		
		$scope.allcase.statusType = [];
		$scope.status = false;
		$scope.searchResult = [];
		
		$('#allCasesStatus').empty();
		$('#allCasesStatus').append($compile(' <div  ng-repeat = "data in statusArray"> '+
                         ' <div class="checkbox"> '+
                           ' <input type="checkbox" value="{{data}}" id="allCases{{data}}" ng-model="status" my-checkbox />'+
                          '	<label for = "allCases{{data}}" >{{data}}</label> '+'  </div> ' +
                      ' </div>')    ($scope));


		$scope.allcase.selectedFilterCaseDisp = [];
     	$scope.allcase.createdDateTime = {
        	'name' : '',
        	'value' : ''
    	};
    	$scope.allcase.latestAlertDateTime = {
        	'name' : '',
        	'value' : ''
      	};
        $scope.latestAlertDateTime =["",""];
        $scope.createdDateTime = ["",""];
        $rootScope.allCaseDetailsFromFilters = [];
        
    }
	$scope.resetFilter = function(){
		$scope.resetOnlyFilters();
		$scope.updateAllCases();
	}
	

	$scope.searchResult = [];

  $scope.alertTypeSettings = {
      displayProp: 'name', 
      idProp: 'name', 
      scrollableHeight: '200px',
      scrollable: true,
      showCheckAll : true,
      showUncheckAll : true,
      enableSearch : true,
      smartButtonMaxItems : 5
    }
  $scope.locationIdSettings = {
      displayProp: 'name', 
      idProp: 'name', 
      scrollableHeight: '200px',
      scrollable: true,
      showCheckAll : false,
      showUncheckAll : true,
      enableSearch : true,
      selectionLimit:5,
      smartButtonMaxItems : 5
    }
  
  $scope.allCasesSettings = {
      displayProp: 'name', 
      idProp: 'name', 
      scrollableHeight: '200px',
      scrollable: true,
      showCheckAll : false,
      showUncheckAll : true,
      enableSearch : true,
      smartButtonMaxItems : 5
    }
    $scope.alertTypeCustomText = {buttonDefaultText: 'Select alert type'};
    $scope.investigatorIDCustomText = {buttonDefaultText: 'Select investigator'}; 
    $scope.caseDispSettings = {
      displayProp: 'name', 
      idProp: 'value', 
      scrollableHeight: '200px',
      scrollable: true,
      showCheckAll : true,
      showUncheckAll : true,
      enableSearch : true,
      smartButtonMaxItems : 5
    }
    $scope.caseDispCustomText = {buttonDefaultText: 'Select upon case Closure'};
    $scope.locationIDCustomText = {buttonDefaultText: 'Search by Location ID'};
   
    $scope.allCasesCustomText = {buttonDefaultText: 'All Cases'};


    $scope.allCasesEventListeners = {
	    onItemSelect: onItemSelect,
        onItemDeselect: onItemDeselect,
        //onSelectAll: onSelectAll,
        onDeselectAll: onDeselectAll
    };
    // MultiSelect Drop down events
	function onItemSelect(property) {
        
		if(property.id === "All Cases"){
			$scope.allcase.selectedInvestigator=[];
		}
        $scope.updateAllCases();
    }
    function onItemDeselect(property) {
        $scope.updateAllCases();
    }
//    function onSelectAll(){
//        $scope.updateAllCases();
//    }
    function onDeselectAll() {
        $scope.allcase.selectedInvestigator=[];
        $scope.updateAllCases();
    }
   
    

    $scope.dispositionChange=function(dispositionValue){
      		$scope.caseDispositionSelectedOption=dispositionValue;
    }

    angular.element("#myModal2").draggable({
          handle: ".modal-header"
    });
	$scope.updateTableWithSorting = function(sortField,sortDirection) {
	    $rootScope.loading = true;
	   // $scope.addValue();

	        var params = $scope.updateAllCasesParams();
		    if ($scope.myCasesActive) {
		        params.investigatorUId = [$rootScope.loggedAttId];
		    }

		    $scope.bulkCloseArrayDuplicate = [];
		    $('#bulkCloseBtn').attr('disabled', 'disabled');
		    allCasesFactory.getAllCasesDataWithSorting(params, $scope.currentPage - 1, $scope.rowsPerPage,sortField,sortDirection).then(function(data) {
		        
                $scope.prepareCasesTableData(data);
		    });

		 
		};
    $scope.showMore = function(){
        
        
        $(".show-more-content").toggle(500);
        if($rootScope.showMoreContent){
            $rootScope.showMoreContent = false;
            $(".show-more-link a").html("Show more ...");
        }else{
            $rootScope.showMoreContent = true;
            
            $(".show-more-link a").html("Show less");
        }
        
    };

   $scope.prepareCasesTableData = function(data){
                 $rootScope.loading = false;
        if(data.casePage){
       		     $scope.totalPages = data.casePage.totalPages;
		        $scope.totalRows = data.casePage.totalElements;
		        var responseData = data.casePage.content;
		        $scope.totalCases = responseData.length;
        }else{
            $scope.totalCases = 0;
        }
		        var tableBody = [];

		        angular.forEach(responseData, function(v, i) {
		        	v.alertType = v.alertType.name;
		            v.status = v.caseStatusType.name;
                    if(v.status === "New"){
                        v.caseCheckBox = {
		                    'value': v.id,
		                    'html': $sce.trustAsHtml("<input type='checkbox' value= '" + v.id + "'' class='allCaseCheckbox' id=caseCheckbox" + i + " style='position : relative !important;' />")
		                }
                    }else if (v.status === "Closed" ||    ($scope.userEdit === "false" && v.investigatorId !== $rootScope.loggedAttId)) {
		                v.caseCheckBox = {
		                    'value': v.id,
		                    'html': $sce.trustAsHtml("<input type='checkbox' value= '" + v.id + "'' class='allCaseCheckbox ' id=caseCheckbox" + i + "  disabled style='position : relative !important;' />")
		                }
		            } else {
		                v.caseCheckBox = {
		                    'value': v.id,
		                    'html': $sce.trustAsHtml("<input type='checkbox' value= '" + v.id + "'' class='allCaseCheckbox' id=caseCheckbox" + i + " style='position : relative !important;' />")
		                }
		            }
		            v.id = {
		                'value': v.id,
		                'html': $sce.trustAsHtml('<a href="#/caseDetails/' + v.id + '">' + v.id + '</a>')


		            }
		            v.maxProbability = parseFloat($filter('number')(v.maxProbability * 100, 3));
				  	
				  	if(v.createdDateTime){
                        //console.log(v.createdDateTime);    
           		       v.createdDateTime = dateTimeFactory.changeToLocalDateFromDate(v.createdDateTime);
                        //v.createdDateTime = v.createdDateTime ? v.createdDateTime.substring(0,10).split("-").join("/") : "";
                    }
                     if(v.latestAlertDate){
                       v.latestAlertDate=v.latestAlertDate.substring(4,6)+'/'+v.latestAlertDate.substring(6,8)+'/'+v.latestAlertDate.substring(0,4);
                      }  
				  	this.push(v);
				}, tableBody);

		        $scope.tableData.tbody = tableBody;
		       
   };
    
    $scope.init();
//    $scope.$on("$destroy", function(){
//        debugger;
//        $rootScope.allCaseFilterSelected = "yes";
//    });
    
 }]);
