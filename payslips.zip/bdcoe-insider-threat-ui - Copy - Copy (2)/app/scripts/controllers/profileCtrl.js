angular.module('insiderApp')
.controller('profileCtrl', ['$scope','$rootScope','getServiceURI' ,function($scope,$rootScope,getServiceURI){


	$rootScope.route = [
    {
        "url" : "home",
        "name" : "Home"
    },
    {
        "url" : "admin",
        "name" : "Admin"
    }
    ];
    $scope.myDate=new Date();
    $scope.monthOptions = [{name:"Jan",value:0},{name:"Feb",value:1},{name:"Mar",value:2},{name:"Apr",value:3},{name:"May",value:4},{name:"Jun",value:5},{name:"Jul",value:6},{name:"Aug",value:7},{name:"Sep",value:8},{name:"Oct",value:9},{name:"Nov",value:10},{name:"Dec",value:11}];
    
    $scope.selectedMonth = $scope.monthOptions[$scope.myDate.getMonth()];
     $scope.csv = getServiceURI.build('insiderThreat', 'exportAllCases')+"/"+($scope.selectedMonth.value+1);
    	$scope.addNewContact = function(){
    		$scope.addNew = true;
    	}
    	$scope.cancelNewContact = function(){
    		$scope.addNew = false;
    	}
        $scope.$watch('selectedMonth', function(newValue){
         $scope.csv = getServiceURI.build('insiderThreat', 'exportAllCases')+"/"+(newValue.value+1);
        });
       

}]);



