 'use strict';

angular.module('insiderApp')
.controller('allAlertsCtrl', ['$scope','$rootScope','$http','allCasesFactory','allAlertsFactory','getServiceURI','dateTimeFactory','$filter','$sce','caseDetailFactory','$compile','topSummaryFactory','$state','$timeout', '$q',
  function ($scope,$rootScope,$http,allCasesFactory, allAlertsFactory,getServiceURI,dateTimeFactory,$filter,$sce,caseDetailFactory,$compile,topSummaryFactory,$state,$timeout, $q) {
 
  console.log($rootScope.allAlerts);
 
    $scope.newCase = {};
    $rootScope.routedFromCreateNewCase = 'no';
    $rootScope.routedFromAllCases='no';
    $rootScope.routedFromAllAlerts = 'yes';
      $rootScope.fromGraph = "no";
   

    $scope.newCase.selectedSuspectId = '';
    $scope.newCase.selectedDate = [];
    $scope.newCase.selectedDate = {
        	'name' : '',
        	'value' : ''
    };
     $scope.newCase.alertType = '';
    $scope.eventsRecords=0;
    $scope.bulkCloseArrayDuplicate=[];
    $('#bulkCloseBtn').attr('disabled','disabled');
    $scope.showTableHeader = true;
    $scope.hideRowNumbers  = false;
    $scope.currentPage = 1;
    $scope.rowsPerPage = 25;
    $scope.itemsPerPageOptions = [{ name:'25'},{ name:'40' },{ name:'60' }];
    
    $scope.sortField = "";
    $scope.sortDirec = "";
     
      $scope.newCase.selectedSiteId = [];
      $scope.newCase.companyName = [];
    $scope.setSortConditions = function(sortField,sortDirection){
      //console.log('setting the sort conditions in allCasesController to :',sortField,'::',sortDirection);
      $scope.sortField = sortField;
      $scope.sortDirec = sortDirection;

    }
    $scope.setCurrentPageWhenSorting = function(pageNumber){
     // console.log('setting current page to bcoz unequla sorting columns',pageNumber);
      $scope.currentPage =pageNumber;
    }
      $scope.onPageChange = function(page){
      $scope.currentPage = page;
      $scope.updateTableWithSorting($scope.sortField,$scope.sortDirec);
    }
      $scope.getRowCount = function(i){
      var total = $scope.rowsPerPage,
      currentPage = $scope.currentPage;
      i += currentPage > 1 ? (currentPage * total) - total + 1 : 1;
      i = i>$scope.totalRows?$scope.totalRows:i;
      return i;
    };

     $scope.onRowsPerPageChange = function (page ) {
      $scope.currentPage =1;
      $scope.rowsPerPage = page.name;
      $scope.createCase();
    }
             
    $rootScope.route = [
    {
            "url" : "home",
            "name" : "Home"
    },
    {
            "url" : "alerts",
            "name" : "All Alerts" 
    }
    ];
    
     $scope.caseStatus  = [];
 $scope.alertTypeSettings = {
      displayProp: 'name', 
      idProp: 'name', 
      scrollableHeight: '200px',
      scrollable: true,
      showCheckAll : false,
      showUncheckAll : true,
      enableSearch : true,
      selectionLimit:5,
      smartButtonMaxItems : 5
    }    

  $scope.init=function()
  {
      topSummaryFactory.checkBasicUserInUPM().then(function(data){
        if(data.upmCheck == "false")
        {
            $state.go('error',{'id':""});
        }
        });
       topSummaryFactory.getUserPermissions().then(function(data){
           $scope.permissions = data.componentPermissionMap;
           $scope.userCanAdd = $scope.permissions.IT_CASE_MGT.add;
            if(!$scope.permissions.IT_CASE_MGT.view){
                $state.go('error',{'id':""});
        }
       });
      
       if(!_.isEmpty($rootScope.allAlerts) && $rootScope.allAlerts != undefined && $.inArray($rootScope.lastPageLedger.lastPage, ["alertDetails", "eventDetails"]) > -1){           
           if($rootScope.routedFromAlertDetails == "yes"  || $rootScope.routedFromCaseDetails == "yes"){
                $scope.newCase.companyName= $rootScope.allAlerts.companyName;
                $scope.newCase.selectedDate.name = $rootScope.allAlerts.selectedDate;         
                $scope.newCase.selectedSuspectId = ($rootScope.allAlerts.selectedSuspectId != undefined)?$rootScope.allAlerts.selectedSuspectId.toUpperCase(): "";
                $scope.newCase.min = $rootScope.allAlerts.min;
                $scope.newCase.max = $rootScope.allAlerts.max;
                $scope.newCase.selectedSiteId = $rootScope.allAlerts.selectedSiteId;
               $scope.createCase();
               $rootScope.routedFromAlertDetails = "no";               
               $rootScope.routedFromCaseDetails = "no";               
           }
      }else{
          $rootScope.allAlerts = {};
      }
      
     dateTimeFactory.lastPageLedger("allAlerts") ;
  };
  $scope.checkExport = function(event){
      console.log("Before clikcing------------------------>");
      console.log($scope.totalRecords > 300000);
      console.log($("#selectedAlertsList").val().length);
      
      
      if($scope.totalRecords > 300000 && $("#selectedAlertsList").val().length == 0){
          console.log("In th codition------------>")
        event.preventDefault();
        $("#downloadCSV").removeAttr('href')  
        $('#myModal7').modal('show');     
      }
  }
  dateTimeFactory.lastPageLedger("allAlerts");
  $scope.getCSVServiceLink = function(){
 
 
      $scope.newCaseDate=[];
      if( $scope.newCase.selectedDate.name.length){
            $scope.newCaseDate = dateTimeFactory.getDateRangesFromRawDates($scope.newCase.selectedDate.name);
        }else{
            $scope.newCaseDate = dateTimeFactory.getDateRanges($scope.newCase.selectedDate.value);
      }
      if($scope.newCase.selectedDate.name.length == 0){
            $scope.newCaseDate = ["",""];
      }
      if($scope.newCaseDate[0] !== "" &&($scope.newCaseDate[1] === undefined ||$scope.newCaseDate[1] === "") )
      {
          $scope.newCaseDate[1]=$scope.newCaseDate[0];
      }
      var minAnomalyProbability= $scope.newCase.min ? $scope.newCase.min : "";
      var maxAnomalyProbability= $scope.newCase.max ? $scope.newCase.max : "";   
      
      var alertIds = $("#selectedAlertsList").val();
        console.log("alertIds....."+alertIds)
        if(alertIds==undefined){
            alertIds="";
        }
      var link = getServiceURI.build('insiderThreat', 'exportAllAlertsPageData')+ '/' +$rootScope.loggedAttId+'/'+'?&suspectId='+$scope.newCase.selectedSuspectId.toUpperCase()+'&dateFrom='+$scope.newCaseDate[0]+'&dateTo='+$scope.newCaseDate[1]+'&minAnomalyProbability='+minAnomalyProbability+'&maxAnomalyProbability='+maxAnomalyProbability+"&siteId="+_.pluck($scope.newCase.selectedSiteId, 'id')+"&alertStatusType="+camelCase($scope.newCase.alertType)+"&companyName="+encodeURIComponent(_.pluck($scope.newCase.companyName, 'id'))+"&alertIdsList=";
      
      console.log("****",link);
      return link;
    };
  
  
    $scope.tableData = {};
    $scope.itemsPerPage ={};
    $scope.itemsPerPage = $scope.itemsPerPageOptions[0];
     console.log($rootScope.lastPageLedger);
        $scope.locationIDCustomText = {buttonDefaultText: 'Search by Location ID'};
      $scope.companyNameCustomText = {buttonDefaultText: 'Search by Company Name'};
         $scope.locationSiteId = [];
      $scope.companyName = [];
    var locationId = allCasesFactory.getLocationDetails();
      var companyName = allCasesFactory.getCompanyDetails()
      $q.all([locationId, companyName]).then(function(resultData){
           $.each(resultData[0].data,function(i,v)
            {
                $scope.locationSiteId.push({name:v});
            });
          console.log(resultData[1].data)
           $.each(resultData[1].data,function(i,v)
            {
                $scope.companyName.push({name:v.companyName});
            });
      });
      
  $scope.createCase=function() {
  $(".hasDatepicker").hide();  
      console.log($scope.newCase.selectedDate.name);
  $scope.currentPage = 1;
    if($scope.newCase.selectedDate.name=="" || $scope.newCase.selectedDate.name==undefined ){    
       $('#myModal5').modal('show');   
        $("#daterange").css("border-color", "#f00");
    }else{
  $("#daterange").removeAttr("style");
      $rootScope.loading = true;

      $scope.newCaseDate=[];
      if( $scope.newCase.selectedDate.name.length){
            $scope.newCaseDate = dateTimeFactory.getDateRangesFromRawDates($scope.newCase.selectedDate.name);
        }else{
            $scope.newCaseDate = dateTimeFactory.getDateRanges($scope.newCase.selectedDate.value);
      }
      if($scope.newCase.selectedDate.name.length == 0){
            $scope.newCaseDate = ["",""];
      }
       if($scope.newCaseDate[0] !== "" &&($scope.newCaseDate[1] === undefined ||$scope.newCaseDate[1] === "") )
        {
          $scope.newCaseDate[1]=$scope.newCaseDate[0];
        }

   
      $scope.totalRecords;
     $scope.tableData.headers = {          
      'alertId' : '',
      'caseId' : 'CASE ID',
      'id' : 'ALERT ID',          
      'anomalyProbability' : 'ALERT PROBABILITY',      
      'userId' : 'SUSPECT UID',
      'date' : 'DATE OF ACCESS',
      'agentCompany' : 'COMPANY NAME',
      'siteId': 'LOCATION SITE ID',
      'alertStatusType': 'STATUS',
      'alertDisposition': 'DISPOSITION',
      'investigatorId' : 'INVESTIGATOR UID',
      'accountsAccessed' : 'ACCOUNTS ACCESSED',     
      'countOfCTNAccessed' : '# OF CTNS ACCESSED',
      'accountsNotedBySuspectId' : 'ACCOUNTS NOTED BY SUSPECT',
      'percentageNotedBySuspectId' : 'PERCENTAGE NOTED BY SUSPECT',
      'averageNumberOfBAN' : 'AVERAGE # OF BAN',
      'averageNumberOfCTN' : 'AVERAGE # OF CTNS',
      'mobility' : 'MOBILITY',
      'clarifyNoMemoCount' : 'CLARIFY NO MEMO COUNT',
      'telegenceNoMemoCount' : 'TELEGENCE NO MEMO COUNT',
      'countOfFraudEvents' : 'COUNT OF FRAUD EVENTS'     
    };
      
        
        $rootScope.allAlerts.selectedDate =  $scope.newCase.selectedDate.name;
         $rootScope.allAlerts.companyName =  $scope.newCase.companyName;
         $rootScope.allAlerts.selectedSuspectId = $scope.newCase.selectedSuspectId.toUpperCase();
        $rootScope.allAlerts.min = $scope.newCase.min;
        $rootScope.allAlerts.max = $scope.newCase.max;
         $rootScope.allAlerts.selectedSiteId = $scope.newCase.selectedSiteId;
      var alertsArray = [];
       $scope.newCaseInfo = {
            "suspectId": $scope.newCase.selectedSuspectId.toUpperCase(),
            "dateFrom": $scope.newCaseDate[0],
            "dateTo": $scope.newCaseDate[1],
            "siteId": _.pluck($scope.newCase.selectedSiteId, 'id'),
            "companyName": _.pluck($scope.newCase.companyName, 'id'),
            "alertStatusType" : camelCase($scope.newCase.alertType),
            //New code
            "minAnomalyProbability":$scope.newCase.min ? $scope.newCase.min : "",
            "maxAnomalyProbability":$scope.newCase.max ? $scope.newCase.max : "",           
           
      }
       allAlertsFactory.getAllAlertsByFilters($scope.newCaseInfo,$scope.currentPage-1,$scope.rowsPerPage).then(function(data){
       // $scope.totalRecords=data.dataList.length;
        $scope.someThingWrong = false;
        $scope.totalPages = data.totalPages;
        $scope.totalRecords = data.totalRecords;
        $scope.alertsSearchResults = data.caseSummaries;
        data.dataList = data.caseSummaries;
        if(data.caseSummaries){
          $scope.totalRecords1=data.caseSummaries.length;
          $scope.eventsRecords= $scope.totalRecords1;
        }
        else{
          if(!data.serviceResult.success){
            $scope.totalRecords1=0;
            $scope.eventsRecords= $scope.totalRecords1;
          }
          
        }
        $scope.csv = $scope.getCSVServiceLink();
       // $("#downloadCSV").attr("href", $scope.csv);
        $scope.bulkCloseArrayDuplicate=[];
        $('#bulkCloseBtn').attr('disabled','disabled');
        $.each(data.dataList,function(i,v)
        {
            
          v.alertId ={
            'value': data.dataList[i].id,
            'html': $sce.trustAsHtml("<input type='checkbox' value= '"+ data.dataList[i].id+"' id=caseCheckbox"+i+"  class='createCaseCheckBox' style='position : relative !important;' onClick='appendAlertIdsinAlertsPage()' />")
          }
          
           if(v.caseId !== null){
               var vid = data.dataList[i].id;
              v.alertId ={
                'value': data.dataList[i].id,
                'html': $sce.trustAsHtml("<input type='checkbox' value= '"+ vid+"' id=caseCheckbox"+i+" class='createCaseCheckBox disableRow' style='position : relative !important;' onClick='appendAlertIdsinAlertsPage()'/>")
              }
              
              v.id ={
                'value': vid,
                'html': $sce.trustAsHtml('<a style="position : relative !important;text-decoration:underline" href="#/alertDetails/'+vid+'/'+data.dataList[i].caseId+'" >'+vid+'</a>')
             };
                  v.caseId ={
                'value': data.dataList[i].caseId,
                'html': $sce.trustAsHtml('<a style="position : relative !important;text-decoration:underline" href="#/caseDetails/'+data.dataList[i].caseId+'" >'+data.dataList[i].caseId+'</a>')
             };
             //  console.log(data.dataList[i].id)
             
           
           }else{
               var suspectIdVal = $scope.newCase.selectedSuspectId.toUpperCase() || '';
              v.id ={
                'value': data.dataList[i].id,
                'html': $sce.trustAsHtml('<a style="position : relative !important;text-decoration:underline" href="#/eventDetails/'+data.dataList[i].id+'/'+ data.dataList[i].caseId+'/'+suspectIdVal+'" >'+data.dataList[i].id+'</a>')
             };
           }
          data.dataList[i].anomalyProbability=parseFloat($filter('number')(data.dataList[i].anomalyProbability * 100 , 3));

              data.dataList[i].accountsAccessed=data.dataList[i].accountsAccessed.toString(); 
              data.dataList[i].countOfCTNAccessed=data.dataList[i].countOfCTNAccessed.toString(); 
              data.dataList[i].accountsNotedBySuspectId=data.dataList[i].accountsNotedBySuspectId.toString();
              data.dataList[i].percentageNotedBySuspectId=data.dataList[i].percentageNotedBySuspectId.toString();
         
              data.dataList[i].date=data.dataList[i].date.substring(4,6)+'/'+data.dataList[i].date.substring(6,8)+'/'+data.dataList[i].date.substring(0,4);

              if(data.dataList[i].alertDisposition)
              {
                 data.dataList[i].alertDisposition=data.dataList[i].alertDisposition;
              }   
            
        });
         $scope.tableData.tbody = data.dataList;
           $rootScope.loading = false;
             $timeout(function() {
             $("input.disableRow").parents("tr.ng-scope").find("td").css("background","#f2f2f2");
             appendAlertIdsinAlertsPage();
             $rootScope.loading = false;
         },1000);
         }, function(err) {
           $scope.someThingWrong = true;
           $rootScope.loading = false;
             return;         
        });
    }
    }
    $scope.closeCasePopupClose = function(){
      $scope.closeCasePopup = false;
      $scope.openCaseStatusPopup = false;
      $scope.closeCaseStatusPopup = false;
      $("input:checkbox").prop("checked",false);
      $scope.caseStatus  = [];
      
    }
     $scope.closeCasePopupCloseRefresh = function(){      
      $scope.createCase();
      $scope.closeCasePopup = false;
      $scope.openCaseStatusPopup = false;
      $scope.closeCaseStatusPopup = false;
      $("input:checkbox").prop("checked",false);
      $scope.caseStatus  = [];
    }
    
    function camelCase(word){
             return word.charAt(0).toUpperCase() + word.slice(1) || '';
     }

     $scope.updateTableWithSorting = function(sortField,sortDirection) {
      $rootScope.loading = true;


      $scope.newCaseDate=[];
      if( $scope.newCase.selectedDate.name.length){
            $scope.newCaseDate = dateTimeFactory.getDateRangesFromRawDates($scope.newCase.selectedDate.name);
        }else{
            $scope.newCaseDate = dateTimeFactory.getDateRanges($scope.newCase.selectedDate.value);
      }
      if($scope.newCase.selectedDate.name.length == 0){
            $scope.newCaseDate = ["",""];
      }
       if($scope.newCaseDate[0] !== "" &&($scope.newCaseDate[1] === undefined ||$scope.newCaseDate[1] === "") )
        {
          $scope.newCaseDate[1]=$scope.newCaseDate[0];
        }

        
        var alertsArray = [];
       $scope.newCaseInfo = {
            "suspectId": $scope.newCase.selectedSuspectId.toUpperCase(),
            "dateFrom": $scope.newCaseDate[0],
            "dateTo": $scope.newCaseDate[1],
            "siteId":_.pluck($scope.newCase.selectedSiteId, 'id'),
            "companyName": _.pluck($scope.newCase.companyName, 'id'),
           "alertStatusType" : camelCase($scope.newCase.alertType),
            //New code
            "minAnomalyProbability":$scope.newCase.min ? $scope.newCase.min : "",
            "maxAnomalyProbability":$scope.newCase.max ? $scope.newCase.max : ""            
      }
      
      allAlertsFactory.creatNewCaseWithSorting($scope.newCaseInfo,$scope.currentPage-1,$scope.rowsPerPage,sortField,sortDirection).then(function(data){
        
         $scope.totalPages = data.totalPages;
        $scope.totalRecords = data.totalRecords;
          data.dataList = data.caseSummaries;
       $scope.alertsSearchResults = data.caseSummaries;
        if(data.dataList){
          $scope.totalRecords1=data.dataList.length;
          $scope.eventsRecords= $scope.totalRecords1;
        }
        else{
          if(!data.serviceResult.success){
            $scope.totalRecords1=0;
            $scope.eventsRecords= $scope.totalRecords1;
          }
          
        }
        $scope.bulkCloseArrayDuplicate=[];   
        $('#bulkCloseBtn').attr('disabled','disabled');
        $.each(data.dataList,function(i,v)
        {


          v.alertId ={
            'value': data.dataList[i].id,
            'html': $sce.trustAsHtml("<input type='checkbox' value= '"+ data.dataList[i].id+"' id=caseCheckbox"+i+"  class='createCaseCheckBox' style='position : relative !important;' onClick='appendAlertIdsinAlertsPage()'/>")
          };
          if(v.caseId !== null){
              console.log(v);
              v.alertId ={
                'value': data.dataList[i].id,
                'html': $sce.trustAsHtml("<input type='checkbox' value= '"+ data.dataList[i].id+"' id=caseCheckbox"+i+" class='createCaseCheckBox disableRow' style='position : relative !important;' onClick='appendAlertIdsinAlertsPage()'/>")
              }
              v.id ={
                'value': data.dataList[i].id,
                'html': $sce.trustAsHtml('<a style="position : relative !important;text-decoration:underline" href="#/alertDetails/'+data.dataList[i].id+'/'+ data.dataList[i].caseId+'" >'+data.dataList[i].id+'</a>')
             };
                   v.caseId ={
                'value': data.dataList[i].caseId,
                'html': $sce.trustAsHtml('<a style="position : relative !important;text-decoration:underline" href="#/caseDetails/'+data.dataList[i].caseId+'" >'+data.dataList[i].caseId+'</a>')
             };
           }else{
               var suspectIdVal = $scope.newCase.selectedSuspectId.toUpperCase() || '';
              v.id ={
                'value': data.dataList[i].id,
                'html': $sce.trustAsHtml('<a style="position : relative !important;text-decoration:underline" href="#/eventDetails/'+data.dataList[i].id+'/'+ data.dataList[i].caseId+'/'+ suspectIdVal +'" >'+data.dataList[i].id+'</a>')
             };
         
           }
          data.dataList[i].anomalyProbability=parseFloat($filter('number')(data.dataList[i].anomalyProbability * 100 , 3));

              data.dataList[i].accountsAccessed=data.dataList[i].accountsAccessed.toString(); 
              data.dataList[i].countOfCTNAccessed=data.dataList[i].countOfCTNAccessed.toString(); 
              data.dataList[i].accountsNotedBySuspectId=data.dataList[i].accountsNotedBySuspectId.toString();
              data.dataList[i].percentageNotedBySuspectId=data.dataList[i].percentageNotedBySuspectId.toString();
         
              data.dataList[i].date=data.dataList[i].date.substring(4,6)+'/'+data.dataList[i].date.substring(6,8)+'/'+data.dataList[i].date.substring(0,4);

              if(data.dataList[i].alertDisposition)
              {
                 data.dataList[i].alertDisposition=data.dataList[i].alertDisposition;
              }   
            
        });
        $scope.tableData.tbody = data.dataList;
        $rootScope.loading = false;
      $timeout(function() {
            $("input.disableRow").parents("tr.ng-scope").find("td").css("background","#f2f2f2");
            appendAlertIdsinAlertsPage();
             $rootScope.loading = false;
         },1000);
         }, function(err) {
           $scope.someThingWrong = true;
           $rootScope.loading = false;
             return;         
        });


    };

    $scope.addAlertsToCreateACase=function()
    {

      $scope.addAlertsArray = [];
       $rootScope.loading = true; 
        var canAddAlerts = true;
        for(var i=0;i<$scope.totalRecords;i++){
        if($('#caseCheckbox'+i).prop('checked')){
             $.each($scope.alertsSearchResults,function(j,v)
            {
             if(v.alertId.value === $('#caseCheckbox'+i).val())
             {
                 
                if(v.caseId!= null){
                    $('#myModal4 .modal-body').html("Selected alerts are already assigned to the case "); 
                    $('#myModal4').modal('show');
                    canAddAlerts = false;
                }    
             }   
            });
            
          $scope.addAlertsArray.push($('#caseCheckbox'+i).val());
        }
      };
        
        if(!canAddAlerts){
            $rootScope.loading = false; 
            return false;
        }
       if($scope.newCaseDate[0] !== "" &&($scope.newCaseDate[1] === undefined ||$scope.newCaseDate[1] === "") )
        {
          $scope.newCaseDate[1]=$scope.newCaseDate[0];
        }


      $scope.newCaseInfo = {
            "suspectId": $scope.newCase.selectedSuspectId.toUpperCase(),
            "startDate": $scope.newCaseDate[0],
            "endDate": $scope.newCaseDate[1],
           "siteId": _.pluck($scope.newCase.selectedSiteId, 'id'),
            "companyName":_.pluck($scope.newCase.companyName, 'id'),
            "alertStatusType" : camelCase($scope.newCase.alertType),
            //New code          
           "minAnomalyProbability":$scope.newCase.min ? $scope.newCase.min : "",
            "maxAnomalyProbability":$scope.newCase.max ? $scope.newCase.max : "",                    
           //New code
            
            "alertIds": $scope.addAlertsArray
           
      }
       function extractCaseIds(data){
           if(data == "" || data === undefined) return "";                     
           var caseIdClosed = data.split(':')[1].replace("[","").replace("]","").split(",");
           var caseDetailsClosed = [];
           var caseIdsClosed = [];                
           $.each(caseIdClosed, function(k, v){
               v = v.trim().split("_");
                caseDetailsClosed.push({suspId: v[0], alertId: v[0].concat("_", v[1]), caseId: v[v.length-1]});                  
                })
           return caseDetailsClosed;
        }   
        
        function formatCaseData(data){
              var newCaseAlerts = [];
             if(data.newAlertsCaseRecycled != null){              
                   newCaseAlerts.push({"message": data.newAlertsCaseRecycled.split(':')[0].replace("Case ID",""), "ids": extractCaseIds(data.newAlertsCaseRecycled), "showAlertID": true});               
             } 
             if(data.newCaseNewAlerts != null){
                   newCaseAlerts.push({"message": data.newCaseNewAlerts.split(':')[0].replace("Case ID",""), "ids": extractCaseIds(data.newCaseNewAlerts), "showAlertID": true});

              }
             if(data.existingCaseNewAlerts != null){
                 newCaseAlerts.push({"message": data.existingCaseNewAlerts.split(':')[0].replace("Case ID",""), "ids": extractCaseIds(data.existingCaseNewAlerts), "showAlertID": true});
              }

             if(data.existingCaseExistingAlerts != null){
                  newCaseAlerts.push({"message": data.existingCaseExistingAlerts.split(':')[0].replace("Case ID",""), "ids": extractCaseIds(data.existingCaseExistingAlerts), "showAlertID": true});
             }

             if(data.caseAlreadyClosed != null){                          
                  newCaseAlerts.push({"message": data.caseAlreadyClosed.split(':')[0].replace("caseId",""), "ids": extractCaseIds(data.caseAlreadyClosed), "showAlertID": false});
             }
            return newCaseAlerts;
        }

        $scope.alreadyClosedFlag = false;
      console.log("new case info****************",$scope.newCaseInfo);
      allAlertsFactory.creatNewCase($scope.newCaseInfo).then(function(data){
         
        $rootScope.loading = false; 
        $scope.caseCreationData=data.caseAlreadyClosed;
        
        $rootScope.routedFromAllAlerts = 'yes' ;
          $scope.caseCreationIDs = [];
       if(data.caseAlreadyClosed != null && (data.caseAlreadyClosed).toLowerCase().indexOf("closed")!== -1){
             $scope.openCaseStatusPopup = true;
              angular.forEach(data.caseIdList, function(v, k){
             var res = v.split("_");
              $scope.newCaseAlerts = [] ;
              $scope.newCaseAlerts = formatCaseData(data);
             $scope.caseCreationIDs.push({suspId: res[0], alertId: res[0].concat("_", res[1]), caseId: res[res.length-1]});
             $scope.caseStatus.push(res[0]+"_recycled");
                   return false;
         })
              $scope.alreadyClosedFlag = true;
          $scope.newCaseInfo.caseStatus = $scope.caseStatus;            
                 // $('#myModal2').modal('show');                
          }else{
               
              $scope.newCaseAlerts = [] ;
              $scope.newCaseAlerts = formatCaseData(data);
              $scope.closeCasePopup=true;
                return false;
        }
        
              if(data.value != "")
                $scope.caseCreationID=data.value.split(':')[1].trim();
      }, function(err) {
           $scope.someThingWrong = true;
           $rootScope.loading = false;
             return;         
        });
        
      $scope.caseStatusOptions=function(){
          console.log($scope.caseStatus[0]);
          $scope.newCaseInfo.caseStatus = $scope.caseStatus;
          $('#caseCreateButton').removeAttr("disabled");
          console.log($scope.newCaseInfo.caseStatus)
      }
      $scope.createCaseWithOptions = function(){
          $scope.openCaseStatusPopup = false;
          $rootScope.loading = true; 
          allAlertsFactory.creatNewCase($scope.newCaseInfo).then(function(data){
              if($scope.newCaseAlerts === undefined) $scope.newCaseAlerts = [];              
              $scope.newCaseAlertsData = formatCaseData(data); 
              $scope.newCaseAlerts = _.filter($scope.newCaseAlerts, function(item){
                  return item.message.indexOf("closed") === -1; 
              });
              $scope.newCaseAlerts = $scope.newCaseAlerts.concat($scope.newCaseAlertsData);
              
              $rootScope.routedFromAllAlerts = 'yes' ;          
              $rootScope.loading = false;
              $scope.closeCaseStatusPopup = true ; 
         }, function(err) {
           $scope.someThingWrong = true;
           $rootScope.loading = false;
             return;         
        });
      }

      console.log("new case info after case creation****************",$scope.newCaseInfo);
      //end of new code

        $scope.bulkCloseArrayDuplicate=[];
        $('#bulkCloseBtn').attr('disabled','disabled');

      /*  allAlertsFactory.getEventDetailsData($scope.newCase.selectedSuspectId,$scope.newCaseDate[0],$scope.newCaseDate[1]).then(function(data){
      
        $scope.totalRecords=data.dataList.length;
        $scope.bulkCloseArrayDuplicate=[];
        $('#bulkCloseBtn').attr('disabled','disabled');
        $.each(data.dataList,function(i,v)
        {
          v.caseId ={
            'value': data.dataList[i].id,
            'html': $sce.trustAsHtml("<input type='checkbox' value= '"+ data.dataList[i].id+"' id=caseCheckbox"+i+"  class='allCaseCheckbox' style='position : relative !important;' />")
          };
        });
         $scope.tableData.tbody = data.dataList;

      });
*/


    }
    window.appendAlertIdsinAlertsPage = function(){ 

    var alertids = [];    
    $(".createCaseCheckBox").each(function( index ) {    
        if($(this).is(":checked")){   
            alertids.push($(this).val());   
        }   
    });     
     var downloadLink = $scope.csv; 
    //var downloadLink = $("#downloadCSV").attr("href");  
    $scope.csv =   downloadLink;
    var sortlink = (downloadLink && downloadLink.indexOf("&sort") > -1) ? "&sort="+downloadLink.split("&sort=")[1] : "";
    console.log("sortin-----"+sortlink);
    if(downloadLink && downloadLink.indexOf("&alertIdsList") > -1 ){    
     var splitLink = downloadLink.split("&alertIdsList");   
        downloadLink = splitLink[0];    
    }   
        
    if(alertids.length){            
      downloadLink = downloadLink +'&alertIdsList='+alertids.toString();    
      $("#selectedAlertsList").val(alertids.toString())   
    }else{    
      downloadLink = downloadLink +'&alertIdsList=';    
      $("#selectedAlertsList").val('');       
    }   
        
     downloadLink = downloadLink + sortlink; 
    $scope.csv =   downloadLink;        
    //$("#downloadCSV").attr("href",downloadLink);    
    console.log("downloadLink"+downloadLink);   
 }
    
    $scope.init();


     

}]);


 