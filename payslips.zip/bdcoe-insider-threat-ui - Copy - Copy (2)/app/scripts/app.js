 'use strict';

/**
 * @ngdoc overview
 * @name insiderApp
 * @description
 * # insiderApp
 *
 * Main module of the application.
 */
var insider = angular.module('insiderApp', [
 
 'config',
 'ngAnimate',
 'ngCookies',
 'ngResource',
 'ngRoute',
 'ngSanitize',
 'ngTouch',
 'ui.router',
 'ui.bootstrap',
 'ui.hub',
 'smart-table',
 'ui.hub.header',
 'angularjs-dropdown-multiselect',
 'underscore'
]);
    
insider.run(['$window', '$rootScope', '$location', '$state', 'matchMedia', 'SessionService',
  function ($window, $rootScope, $location,  $state, matchMedia, SessionService) {

           $rootScope.$on('$stateChangeSuccess',
                function (event, toState, toParams, fromState, fromParams) {
                   /* var path = $location.path();
                  console.log('path is:',path);
                  if(path.search('error') > 0){
                    $rootScope.errorFlag =  true;
                    console.log('in error $rootScope.errorFlag  is:',$rootScope.errorFlag);
                  } else {
                    console.log('not error page');
                    $rootScope.errorFlag = false;
                  }
                  //if($location.path())
                    
                    console.log('making erorFlag to falg:',$rootScope.errorFlag );*/
                
                    $rootScope.homeLink = '#/';
                    
                    $('html,body').animate({
                       
                        scrollTop: 0
                    }, {
                        duration: 1000,
                        easing: 'swing'
                    });

                });
            $rootScope.$on('$stateChangeError', 
                function(event, toState, toParams, fromState, fromParams, rejection){                                    
                  
               
                    var rejectionMsg = rejection.message;                   
                    if(rejection.id ){
                          $state.go('error', {
                            id : rejection.id
                        });   
                    }
                    if(rejectionMsg){
                      if (rejectionMsg === 'logged out') {
                        buildUrl();                       
                      } else if (rejectionMsg === 'not logged in') {                        
                        buildUrl();
                      }  else if (rejectionMsg === 'attUID not present in route') {
                        if (SessionService.getUserATTUID()) {                           
                          $state.go('overview');
                        } else {                           
                          $state.go('error', {id: 1});
                        }
                      } else {
                        $state.go('error', {
                          id: rejectionMsg
                        });   
                      }
                    } else {
                       $state.go('error');          
                    }
                
                    function buildUrl(){

                          var currentUrl = $location.$$absUrl;

                        var hostName = $location.$$host;
                            currentUrl = escape(currentUrl);
                            currentUrl = currentUrl.replace('+', '%2B');
                            currentUrl = currentUrl.replace(':', '%3A');
                            currentUrl = currentUrl.replace('%20', '+');
                            currentUrl = currentUrl.replace('*', '%2A');
                            currentUrl = currentUrl.replace('/', '%2F');
                            currentUrl = currentUrl.replace('@', '%40');
                             //console.log(currentUrl);
                           // if(hostName.indexOf("stage") != -1 || hostName.indexOf("web") != -1){
                               window.location.href = 'https://www.e-access.att.com/empsvcs/hrpinmgt/pagLogin/?'
                                    +'retURL='+currentUrl+'&sysName=insiderThreat';

                            /*}else{

                                window.location.href = 'https://webtest.csp.att.com/empsvcs/hrpinmgt/pagLogin/?'
                                    +'retURL='+currentUrl+'&sysName=insiderThreat';
                            }*/
                  }

            
          });
           
          
  }
]); 


insider.factory('headerInjector', [ function() {  
    var headerInjector = {
        request: function(config) {
           
                config.headers['cache-control'] = 'no-cache';
                config.headers['Pragma'] = 'no-cache';
            
            return config;
        }
    };
    return headerInjector;
}]);



insider.config(['$stateProvider', '$urlRouterProvider','$httpProvider', function($stateProvider, $urlRouterProvider,$httpProvider) {
   // $urlRouterProvider.otherwise('/home');

 $httpProvider.interceptors.push('headerInjector');
     $urlRouterProvider.otherwise('/');    
    //we need to change this to .otherwise({redirectTo: '/error'}); to show error page
    
    var permittedResolved = ['SessionService', '$q', '$cookies','$rootScope', function (SessionService, $q, $cookies,$rootScope) {
            var defer = $q.defer();
          /*  console.log("$cookies::::::::",$cookies.get('attESHr'));
            console.log("isAuthenticatedCSP ::::::::::::: ",SessionService.getLegacyUIDs('cingularCUID'));*/
             $rootScope.loggedAttId = SessionService.getLegacyUIDs('cingularCUID');
    
    
             $rootScope.loggedUserName = SessionService.getUsername();
            // if ($cookies.get('attESHr') && SessionService.isAuthenticatedCSP()) {
            if (SessionService.isAuthenticatedCSP()) {
                defer.resolve({'message':'logged in'});
            } else {
                /*if(true)
                  defer.resolve({'message':'logged in'});
                else*/
                  
                defer.reject({'message':'not logged in'});
            }

            return defer.promise;
       // }
      }];

    $stateProvider

     .state('error', {
            url: '/error/:id',
            templateUrl: 'views/error.html',
            controller: 'ErrorCtrl'
        })
 
     
        .state('home', {
            url: '/',
        
         views: {
                '@': {
                     templateUrl: 'views/templates/Home.html',

                     controller: 'homeCtrl',
                     resolve: {
                        //permitted: permittedResolved,
                       topSummaryJson: ['topSummaryFactory', function (topSummaryFactory) {
                          return topSummaryFactory.getTopSummaryData();
                            
                        }],
                    }

                },
              'topSummary@home': {
                    templateUrl: 'views/templates/topSummary.html'
                },
              'worldMap@home': {
                    templateUrl: 'views/templates/worldMap.html'
                },
              'allPriorityAlerts@home': {
                    templateUrl: 'views/templates/allPriorityAlerts.html'
                },
             'mostRecentBookMarks@home': {
                    templateUrl: 'views/templates/mostRecentBookMarks.html'
                }
           }
        })

        .state('caseDetails',{
        
          url: '/caseDetails/:caseId',
           views: {
                '@': {
                     controller: 'caseDetailCtrl',
                     templateUrl: 'views/templates/caseDetailsHome.html' ,
                    resolve: {
                      //permitted: permittedResolved,
                        
                    }
                     
                },
              'loadTemplate@caseDetails': {
                  templateUrl: 'views/templates/caseDetails.html' 
                     
                }
           
            }
        })


         .state('alertDetails', {
          url: '/alertDetails/:alertId/:caseId',
        
         views: {
                '@': {
                     templateUrl: 'views/templates/alertDetails.html',
                      controller: 'alertDetailsCtrl' ,
                    resolve: {
                     //permitted: permittedResolved
                    }
                }
         }
        })


         .state('eventDetails', {
          url: '/eventDetails/:alertId/:caseId/:suspectId',

          views: {
                '@': {
                     templateUrl: 'views/templates/eventDetails.html',

                     controller : 'eventDetailsCtrl',
                     
                    resolve: {
                     //permitted: permittedResolved
                    }
                },
              }
            })
       
        
        .state('allCases', {
          url: '/allCases',
        
         views: {
                '@': {
                  templateUrl: 'views/templates/AllCases.html',
                  controller: 'allCasesCtrl',
                  resolve: {
                    //permitted: permittedResolved
                  }
                },
              }
            })
        .state('alerts', {
          url: '/alerts',
          views: {
                '@': {
                        templateUrl: 'views/templates/alerts.html',
                        controller:'allAlertsCtrl',
                    resolve: {
                   //permitted: permittedResolved
                    }
                     }
                }
        })

        .state('createNewCase', {
          url: '/createNewCase',
        
         views: {
                '@': {
                  templateUrl: 'views/templates/CreateNewCase.html',
                  controller: 'createNewCaseCtrl',
                  resolve: {
                       //permitted: permittedResolved
                  }
                },
              }
            })
 
     .state('search', {
          url: '/search/:searchValue',
          views: {
                '@': {
                        templateUrl: 'views/templates/employeeSearchResults.html',
                        controller: 'searchCtrl' ,
                    resolve: {
                   //permitted: permittedResolved
                    }
                     }
                }
        })


    .state('caseDetailReport', {
          url: '/caseDetailReport',
          views: {
                '@': {
                        templateUrl: 'views/templates/caseDetailsReport.html',
                        controller:'caseDetailsReportCtrl',
                    resolve: {
                   //permitted: permittedResolved
                    }
                     }
                }
        })
    
     .state('dataScientistReport', {
          url: '/dataScientistReport',
          views: {
                '@': {
                        templateUrl: 'views/templates/dataScientistReport.html',
                        controller:'dataScientistReportCtrl',
                    resolve: {
                   //permitted: permittedResolved
                    }
                     }
                }
        })
     .state('disposition', {
          url: '/disposition',
          views: {
                '@': {
                        templateUrl: 'views/templates/disposition.html',
                        controller:'dispositionCtrl',
                    resolve: {
                   //permitted: permittedResolved
                    }
                     }
                }
        })
      .state('incidentResponse', {
          url: '/incidentResponse',
          views: {
                '@': {
                        templateUrl: 'views/templates/incidentResponse.html',
                        controller:'incidentCtrl',
                    resolve: {
                   //permitted: permittedResolved
                    }
                     }
                }
        })
    .state('rules', {
          url: '/rules',
          views: {
                '@': {
                        templateUrl: 'views/templates/rules.html',
                        controller:'rulesCtrl',
                    resolve: {
                   //permitted: permittedResolved
                    }
                     }
                }
        })



    }]);

 insider.controller('headerCtrl', ['$scope','$rootScope','$http',function ($scope,$rootScope, $http) {
    $scope.isShow = false;
    $rootScope.topSummary = 'views/templates/topSummary.html';
    $rootScope.worldMap = 'views/templates/worldMap.html' ;
  }]);
  
 