"use strict";

 angular.module("config", [])

.constant("ENV", {
  "name": "local",
  "debug": true,
  "services": {
    "uri": {
      "insiderThreat": "/insider-threat-server",
      "qPresence": "https://presence.q.att.com"
    },
    "endpoints": {
      "insiderThreat": {
        "getTopSummaryProbData": "/services/getUnAssignedCases",
        "getPriorityData": "/services/getAllPriorityAlerts",
        "getAlertDetails": "/services/getAlertPage",
        "allCasesData": "/services/getCasesByFilters",
        "getCaseSummary": "/services/getCaseDetailByFilters",
        "getAlertDetailsEventsData": "/services/retrieveAlertDetailsUsingFilters",
        "exportCasesData": "/services/exportCasesData",
        "deleteCaseIds": "/services/deleteCaseIdsNew",
        "closeCaseAlerts": "/services/closeCaseAlerts",
        "getCaseDetailData": "/services/getAlertDetailsByFilters",
        "exportAlertDetails": "/services/exportAlertDetails",
        "exportCaseDetails": "/services/exportCaseDetails",
        "caseNotesData": "/services/getCaseNotes",
        "saveNotesDataDetails": "/services/updateCaseNotes",
        "getCaseManagers": "/services/getCaseManagers",
        "updateCaseDetails": "/services/updateCaseDetails",
        "allCompanyData": "/services/getCompanyDetails",
        "getalertBanDetails": "/services/getMarketCodes",
        "getCaseHistorySummary": "/services/getCaseHistorySummary",
        "activitylogVisited": "/services/activityLogVisited",
        "exportAllCases": "/services/exportAllCases",
        "exportNotesDetails": "/services/exportNotesDetails",
        "getDailySummary": "/services/getDailySummary",
        "addNewContact": "/services/createIncidentContacts",
        "getContact": "/services/getAllIncidentContacts",
        "getRules": "/services/getRules",
        "editRules": "/services/updateByRuleId",
        "deleteIncidentContacts": "/services/deleteIncidentContacts",
        "createManualCaseNew": "/services/createManualCase",
        "updateIncidentContacts": "/services/updateIncidentContacts",
        "exportActivityLog": "/services/exportActivityLog",
        "updateByRuleId": "/services/updateByRuleId",
        "checkCaseIdIsPresent": "/services/checkCaseIdIsPresent",
        "autoAssignCase": "/services/autoAssignCase",
        "checkThreshold": "/services/checkThreshold",
        "checkUserInUPM": "/services/checkUserInUPM",
        "getAllRuleId": "/services/getAllRuleId",
        "checkBasicUserInUPM": "/services/checkUserInUPMForHomePage",
        "checkAlertIdInSummary": "/services/checkAlertIdInSummary",
        "exportDataScientistReport": "/services/exportDataScientistReport",
        "getRuleHistorySummary": "/services/getSettingsHistoryWithRules",
        "exportManualCaseData": "/services/exportManualCaseData",
        "getLocationDetails": "/services/getLocationSiteIds",
        "getDisposition": "/services/getDisposition",
        "createDisposition": "/services/createDisposition",
        "removeDisposition": "/services/removeDisposition",
        "updateDisposition": "/services/updateDisposition",
        "getSettingsHistory": "/services/getSettingsHistoryWithDisposition",
        "getAllDisposition": "/services/getAllDisposition",
        "getUserPermissions": "/services/getUserPermissions",
        "getAllAlertsByFilters": "/services/getAllAlertsByFilters",
        "exportAllAlertsPageData": "/services/exportAllAlertsPageData",
        "allAlertsCaseCreation": "/services/allAlertsCaseCreation",
        "addAlertToCaseFromCaseDetails": "/services/addAlertToCaseFromCaseDetails"
      },
      "qPresence": {
        "presence": "/presence"
      }
    }
  }
})

;