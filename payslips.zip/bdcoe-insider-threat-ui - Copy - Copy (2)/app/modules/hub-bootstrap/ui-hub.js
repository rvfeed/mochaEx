'use strict';

//TODO: Need to create a single build hub boostrap file to get included into project index page. Right now you have to include all the scripts
//TODO: Create a bower build
//TODO: Create a Yeoman build 

/**

*/

angular.module('ui.hub', [
	'ui.hub.filters',
	'ui.hub.services',
	'ui.hub.filter',
	'ui.hub.search',
	'ui.hub.dynamicTable',
	'ui.hub.breadcrumb',
	'ui.hub.navDrawer',
	'ui.hub.matchMedia',
	'ui.hub.header',
	'ui.hub.pagination',
	'ui.hub.authentication']
);