'use strict';

angular.module('ui.hub.authentication')
.service('UserPermissionsService', ['AuthenticateUserService', 'SessionService', '$location', '$q',
	function(AuthenticateUserService, SessionService, $location, $q) {

		function doesUserHaveRole(permittedRole){
			var hasRole = false,
				userRoles = SessionService.getUserRole();

			if (!angular.isArray(permittedRole)) {
				permittedRole = [permittedRole];
			}

			angular.forEach(userRoles, function(role){
				if(permittedRole.indexOf(role) !== -1){
					hasRole = true;
				}
			});

			return hasRole;
		}

		this.isPermitted = function(permittedRole){
			var permitted = false;

			if(AuthenticateUserService.isAuthenticated()){
				permitted = doesUserHaveRole(permittedRole);
			} else {
				//TODO: use $boardcast for login				
				$location.path('/');
			}

			return permitted;
		};

		//TODO: need to create USER_ROLES constant
		this.isAdmin = function(){
			return doesUserHaveRole('admin');
		};

		this.isSuperAdmin = function(){
			return doesUserHaveRole('super');
		};
	}
]);
