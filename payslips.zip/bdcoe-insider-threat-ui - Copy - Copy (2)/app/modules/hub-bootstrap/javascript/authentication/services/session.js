'use strict';

angular.module('ui.hub.authentication')
.factory('SessionService', ['$cookieStore', 'ENV', '$http', '$q',
	function($cookieStore, ENV, $http, $q) {

		function getCookie(value){

			var userData = $cookieStore.get('hub-user') || undefined;

			if(value && userData){
				userData = userData[value];
			}

			return userData || false;
		}

		return {
			getUser: function(){
				return getCookie();
			},

			getUserUID: function(){
				return getCookie('uid');
			},

			getUsername: function(){
				var username;
				
				if(getCookie('firstname') && getCookie('lastname')){
					username = getCookie('firstname') + ' ' + getCookie('lastname');
				} else {
					username = false;
				}
				return username;
			},

			getFirstname: function(){
				return getCookie('firstname');
			},

			getLastname: function(){
				return getCookie('lastname');
			},

			getUserRole: function(){
				return getCookie('roles');
			},

			getEmail: function(){
				return getCookie('email');
			},

			isInternal: function(){
				//converting string "false" || "true" into a boolean value
				return typeof getCookie('internal') === 'string' ? JSON.parse(getCookie('internal').toLowerCase()) : getCookie('internal');
			},

			create: function (userData) {
				$cookieStore.put('hub-user', userData);
			},

			destroy: function () {
				$cookieStore.remove('hub-user');
			}
		};
	}
]);