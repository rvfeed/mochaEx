'use strict';

angular.module('ui.hub.authentication')
.factory('AuthenticateUserService', ['$rootScope', '$cookieStore', '$location', '$http', 'SessionService', 'ENV', '$q', '$window', 'getServiceURI',
	function($rootScope, $cookieStore, $location, $http, SessionService, ENV, $q, $window, getServiceURI) {

		return {
			logout : function(){
				SessionService.destroy();

				//Only external users can logout
				//Redirect to the TGuard logout page after clearing CIP login cookie
				$window.location.href = $window.location.protocol + '//' + $window.location.host + '/pkmslogout';
			},

			isAuthenticated : function(){
				return !!SessionService.getUser();
			},

			isAuthorized : function(fakedHubUserData){
				//TODO: need real user service
				var authorizationService = getServiceURI.build('kpi', 'isAdmin'),
					defer = $q.defer();


				if($location.host() === 'localhost'){
					if($location.port() === 9000){
						authorizationService = 'json/is-admin.json';
					}
				}

				$http({
					method: 'GET',
					url: authorizationService,
					params: {
						attUID: fakedHubUserData.uid
					}
				}).then(function(data){
					console.log(data);
					if(data){
						//TODO: Need to use real hub authorize service when setup
						fakedHubUserData.roles = data.data === 'true' ? ['admin'] : ['basic'];

						SessionService.create(fakedHubUserData);
						defer.resolve(true);
					} else {
						//HACK: To reload the page so that CSP login page will show up instead of running CIP code
						// hopefully this can get removed / updated in the future
						$window.location.reload();
						defer.reject(false);
					}
				}, function(failedReason){
					defer.reject('login failed' + failedReason);
				});

				return defer.promise;
			}
		};
	}
]);
