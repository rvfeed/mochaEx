'use strict';

angular.module('ui.hub.authentication')
.controller('LogoutCtrl', ['$scope', 'AuthenticateUserService',
	function($scope, AuthenticateUserService) {
	
		AuthenticateUserService.logout();
		
	}
]);

