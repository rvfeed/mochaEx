'use strict';

//TODO: Need to add in documention

angular.module('ui.hub.navDrawer', [])

.controller('NavDrawerController', ['$scope', '$attrs', 'navDrawerConfig',
	function ($scope, $attrs, navDrawerConfig) {

		var self = this,
			btnClose = null,
			btnOpen = null,
			parentContainer = null,
			navDropdowns = null;

		self.init = function (settings) {
			var settings = angular.extend(navDrawerConfig, settings);

			parentContainer = $attrs.$$element.parent();
			navDropdowns = angular.element('.nav-drawer-dropdown');
		};

		self.toggleDrawer = function(toggleBoolean){
			if(parentContainer.hasClass('nav-drawer-open')){
				angular.forEach(navDropdowns, function(dropdown){
					$(dropdown).removeClass('opened');
				});

				parentContainer.removeClass('nav-drawer-dropdown-open');
			}

			parentContainer.toggleClass('nav-drawer-open');
		};

		self.dropdownToggle = function(dropdownLink){
			var dropdownContent = angular.element('#' + $(dropdownLink).attr('dropdown-id'));

			dropdownContent.toggleClass('opened');
			parentContainer.toggleClass('nav-drawer-dropdown-open');
		};
	}
])


.directive('navDrawer', ['navDrawerConfig', 
	function (navDrawerConfig) {
		return {
			scope: {
				closeBtnText: '@',
				homeLink: '=?',
				isOpened: '=?'
			},
			restrict:'EA',
			transclude: true,
			controller:'NavDrawerController',
			templateUrl: 'modules/hub-bootstrap/templates/nav-drawer/nav-drawer.html',
			link: function(scope, element, attrs, NavDrawerController) {

				scope.btnCloseClass = navDrawerConfig.btnCloseClass;
				scope.closeBtnCopy = scope.closeBtnText || 'close';
				scope.homeLink = scope.homeLink || '/';

				scope.toggleDrawer = function(){
					NavDrawerController.toggleDrawer();
				};

				scope.$watch('isOpened', function(newValue, oldValue){
					if (newValue !== oldValue) { 
						NavDrawerController.toggleDrawer();
					}
				});

				NavDrawerController.init();

			}
		};
	}
])

.directive('navLink', [ 
	function () {
		return {
			require: '^navDrawer',
			scope: {
				isDropdown: '=?'
			},
			restrict:'EA',
			transclude: true,
			replace: true,
			templateUrl: 'modules/hub-bootstrap/templates/nav-drawer/nav-link.html',
			link: function(scope, element, attrs, NavDrawerController) {
				if(scope.isDropdown){
					scope.dropdownOpen = function(evt){
						if(evt.originalEvent.target.tagName === 'A'){
							NavDrawerController.dropdownToggle(evt.currentTarget);
						}
					};
				}
			}
		};
	}
])

.constant('navDrawerConfig', {
  broadcastName: 'navDrawer'
});