'use strict';

/**

@param {updates=} use this attribute to update the any of the breadcrumbs parameters to your liking

<breadcrumb updates="breadcrumbUpdates"></breadcrumb>

This directives default is to use the $location.path() to create the breadcrumbs. If you need to update the
display name of one of the crumbs to something more user friendly or change the route you can use the update
attribute.

The keys of the update array are also based of the $location.path(). If you are using parameters inside your route it will
use the parameter name instead of its value that is returned from $location.path().

This example is based off of this route

/accounts/:accountId/users/:userId

breadcrumb parameters available to update are

{
	displayName : 'new name'
	route : '#/'
}

updates = {};

updates.accountId = {
	displayName : 'general motors'
};
updates.users = { 
	route : '#/newroute'
};

$scope.breadcrumbUpdates = updates;
}
*/



angular.module('ui.hub.breadcrumb', [])

.controller('BreadCrumbController', ['$scope', '$route', '$location',
	function ($scope, $route, $location) {

	//using 2 path variables to have an un altered array path
	var locationPathArray = {},
		breadcrumbOrder = {};

	this.buildBreadcrumb = function(){
		locationPathArray = $location.path().split('/'),
		breadcrumbOrder = $location.path().split('/');

		//remove the first item in the array because it is a blank position
		locationPathArray.shift();
		breadcrumbOrder.shift();

		var breadcrumbArray = {},
			pathParams = $route.current.pathParams;

		for(var i=0; i < breadcrumbOrder.length; i++){
			var crumbData = {
				isVisible : true,
				displayName : breadcrumbOrder[i],
				route : buildRoute(i)
			};

			//naming the individual breadcrumb object based off the parameter name
			//because the parameter name is static but the parameter itself will change
			for(var param in pathParams){
				if(breadcrumbOrder[i] === pathParams[param]){
					breadcrumbOrder[i] = param;
				}
			}

			if($scope.updates !== undefined){
				for(var key in $scope.updates){
					if(key === breadcrumbOrder[i]){
						for(var item in $scope.updates[key]){
							crumbData[item] = $scope.updates[key][item];
						}
					}
				}
			}

			breadcrumbArray[breadcrumbOrder[i]] = crumbData;
		}

		return breadcrumbArray;
	};

	this.getOrder = function(){
		return breadcrumbOrder;
	}

	function buildRoute(key){
		var crumbRoute = '#';

		for(var i=0; i < (key + 1); i++){
			crumbRoute += '/' + locationPathArray[i];
		}

		return crumbRoute;
	}

	return this;

}])


.directive('breadcrumb', function () {
	return {
		scope: {
			showHomeLink: '=?',
			homeLink: '=?',
			homeLinkText: '=?',
			updates: '=?'
		},
		restrict:'EA',
		controller:'BreadCrumbController',
		templateUrl: 'modules/hub-bootstrap/templates/breadcrumb/breadcrumb.html',
		link: function(scope, element, attrs, breadCrumbController) {

			scope.homeLink = scope.homeLink || '/';
			scope.homeLinkText = scope.homeLinkText || 'home';

			scope.$watch('updates', function(){
				init();
			}, true);

			scope.$on('$routeChangeStart', function(next, current) { 
				//init();
			});

			function init(){
				scope.breadcrumb = breadCrumbController.buildBreadcrumb();
				scope.order = breadCrumbController.getOrder();
			}

			init();
		}
	};
});
