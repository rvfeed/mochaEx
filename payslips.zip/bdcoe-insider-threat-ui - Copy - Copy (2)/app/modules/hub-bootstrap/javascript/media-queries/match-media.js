'use strict';

//TODO: Need to add in documention

angular.module('ui.hub.matchMedia', [])

.provider('matchMedia', function() {

	this.mediaQueries = {
		phone: 'only screen and (min-width : 320px) and (max-width : 767px)',
		phoneLandscape: 'only screen and (min-width : 321px)',
		phonePortrait: 'only screen and (max-width : 320px)',

		phoneRatio2: 'only screen and (min-width : 320px) and (max-width : 767px) and (-webkit-min-pixel-ratio : 2)',
		phoneRatio2Landscape: 'only screen and (min-width : 320px) and (max-width : 767px) and (orientation : landscape) and (-webkit-min-pixel-ratio : 2)',
		phoneRatio2Portrait: 'only screen and (min-width : 320px) and (max-width : 767px) and (orientation : portrait) and (-webkit-min-pixel-ratio : 2)',

		tablet: 'only screen and (min-width : 768px) and (max-width : 1024px)',
		tabletLandscape: 'only screen and (min-width : 768px) and (max-width : 1024px) and (orientation : landscape)',
		tabletPortrait: 'only screen and (min-width : 768px) and (max-width : 1024px) and (orientation : portrait)',

		tabletRatio2: 'only screen and (min-width : 768px) and (max-width : 1024px) and (-webkit-min-pixel-ratio : 2)',
		tabletRatio2Landscape: 'only screen and (min-width : 768px) and (max-width : 1024px) and (orientation : landscape) and (-webkit-min-pixel-ratio : 2)',
		tabletRatio2Portrait: 'only screen and (min-width : 768px) and (max-width : 1024px) and (orientation : portrait) and (-webkit-min-pixel-ratio : 2)',

		desktop: 'only screen and (min-width : 1025px)',
		desktopLg: 'only screen and (min-width : 1919px)',

		//TODO: create real tv media query
		tv: 'only screen and (min-width : 1920px)'
	};

	this.setMediaQueries = function(mediaQueries){
		this.mediaQueries = angular.extend(this.mediaQueries, mediaQueries);
	};

	this.$get = function(){
		var mediaQueries = this.mediaQueries,
			isListening = this.isListening;

		return {
			isDevice: function(device, callback){
				var matchMediaResults = window.matchMedia(mediaQueries[device]);

				matchMediaResults.device = device;

				if(typeof callback === 'function'){
					matchMediaResults.addListener(callback);
    			callback(matchMediaResults);
				} else {
					return matchMediaResults;
				}
			}
		}
	};

});