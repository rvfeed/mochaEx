'use strict';

/**

@param {filters=} : a json obejct with all the section and filters
@param {getCheckedFilters=} : pass a function to get the checked filters within an object
@param {submitSearch=} : pass a function that will be used when the user submits the search. The search value will be passed as the parameter.
@param {searchValue=} : inital search value
@param {searchTotal=} : inital search results total

<hub-search 
	filters="filterList"
	get-checked-filters="myFunction(checkedFilters)"
	submit-search="submitSearch(searchValue)"
	search-value="searchValue"
	search-total="searchTotal">
	
	<li hub-search-list ng-repeat="result in searchResults">
		<!-- add search results html -->
	</li>

</hub-search>


*/



angular.module('ui.hub.search', [])

.controller('SearchController', ['$scope', '$route', '$location',
	function ($scope, $route, $location) {

		var self = this;



	}
])


.directive('hubSearch', [ 
	function () {
		return {
			scope: {
				filters: '=',
				getCheckedFilters: '&',
				submitSearch: '&',
				searchValue: '=',
				searchTotal: '='
			},
			restrict:'EA',
			transclude: true,
			controller:'SearchController',
			templateUrl: 'modules/hub-bootstrap/templates/search/search.html',
			link: function(scope, element, attrs, SearchController) {

			}
		};
	}
])

.directive('hubSearchList', [ 
	function () {
		return {
			scope: {},
			restrict:'EA',
			transclude: true,
			templateUrl: 'modules/hub-bootstrap/templates/search/search-list.html',
			link: function(scope, element, attrs, SearchController) {
				
			}
		};
	}
]);
