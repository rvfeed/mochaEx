'use strict';

/**

@param {filters=} : a json obejct with all the section and filters
@param {getCheckedFilters=} : pass a function to get the checked filters within an object

<hub-filter 
	filters="filterList"
	get-checked-filters="myFunction(checkedFilters)"
	></hub-filter>

$scope.filterList = [
  {
    'name' : 'enablers',
    'opened' : 'true',
    'filters' : [
      {
        'name' : 'application',
        'filters' : [
          { 'name' : 'business logic' },
          { 'name' : 'data' },
          { 'name' : 'presentation' }
        ]
      },
      {
        'name' : 'insights'
      }
    ]
  },
  {
    'name' : 'section two',
    'filters' : [
      {
        'name' : 'application',
        'filters' : [
          { 'name' : 'business logic' },
          { 'name' : 'data' },
          { 'name' : 'presentation' }
        ]
      },
      {
        'name' : 'insights'
      },
      {
        'name' : 'networks'
      }
    ]
  }
];

JSON key 'opened' is used to have the section opened on page load. Sections are closed by default

*/



angular.module('ui.hub.filter', [])

.controller('FilterController', ['$scope', '$route', '$location',
	function ($scope, $route, $location) {

		var self = this;



	}
])


.directive('hubFilter', ['$filter', 
	function ($filter) {
		return {
			scope: {
				filters: '=',
				getCheckedFilters: '&'
			},
			restrict:'EA',
			controller:'FilterController',
			templateUrl: 'modules/hub-bootstrap/templates/filter/filter.html',
			link: function(scope, element, attrs, FilterController) {
				scope.filterChecked = {};

				if(!attrs.filters){
					console.log('filters attribute needed');
				} else {
					scope.$watch('filterChecked', function(newValue, oldValue){
						scope.getCheckedFilters({checkedFilters:newValue});
					}, true);

					scope.$watch('filters', function(newValue, oldValue){
						if(newValue){
							for(var i = 0; i < newValue.length; i++){
								newValue[i].keyName = $filter('lowerCamelCase')(newValue[i].name);

								for(var x = 0; x < newValue[i].filters.length; x++){
									newValue[i].filters[x].keyName = $filter('lowerCamelCase')(newValue[i].filters[x].name);

									if(newValue[i].filters[x].filters){
										for(var s = 0; s < newValue[i].filters[x].filters.length; s++){
											newValue[i].filters[x].filters[s].keyName = $filter('lowerCamelCase')(newValue[i].filters[x].filters[s].name);
										}
									}
								}
							}
						}
					}, true);

				}

			}
		};
	}
]);
