'use strict';

//TODO: Need to add in documention
//TOOD: Used css classes to style dropdowns
//TODO: Add in hub search service when it is ready

angular.module('ui.hub.header', [])

.controller('HeaderController', ['$scope', '$attrs', '$timeout', 'headerConfig', 'matchMedia',
	function ($scope, $attrs, $timeout, headerConfig, matchMedia) {

	var self = this,
		parentContainer = undefined,
		navMainContainer = undefined,
		openedDropdown = undefined;

	this.init = function (settings) {
		var settings = angular.extend(headerConfig, settings);

		parentContainer = $attrs.$$element.parent();
		navMainContainer = angular.element('.nav-main', parentContainer);

		matchMedia.isDevice('tv', function(results){
			var mouseenterTimeout = undefined,
				isCursorOffDropdown = false;

			if(results.matches){
				navMainContainer.bind('mouseleave', function(e){
					isCursorOffDropdown = true;

					mouseenterTimeout = $timeout(function(){
						self.dropdownClose(openedDropdown);
					}, 1200);
				});

				navMainContainer.bind('mouseenter', function(){
					if(isCursorOffDropdown){
						$timeout.cancel(mouseenterTimeout);
						isCursorOffDropdown = false;
					}
				});
			} else {
				angular.element('.nav-dropdown-content', navMainContainer).removeAttr('style');
				navMainContainer.removeAttr('style');
				
				navMainContainer.unbind('mouseleave');
				navMainContainer.unbind('mouseenter');
			}
		});
	};

	this.dropdownOpen = function(dropdownLink){
		if(matchMedia.isDevice('tv').matches){
			var dropdownLink = $(dropdownLink).parent(), 
				dropdownContent = $('.nav-dropdown-content', dropdownLink),
				dropdownHeight = dropdownContent.outerHeight() + 32;

			if(!$(dropdownLink).hasClass('active')){
				self.dropdownClose(openedDropdown);

				$(dropdownLink).addClass('active');
				navMainContainer.css({'bottom': dropdownHeight, 'box-shadow': '0px -900px 0px 900px rgba(0, 0, 0, 0.7)'});
				dropdownContent.show();

				openedDropdown = dropdownLink;
			} else {
				self.dropdownClose(openedDropdown);
			}
		}
	};

	this.dropdownClose = function(dropdown){
		if(dropdown){
			var dropdownContent = angular.element('.nav-dropdown-content', dropdown),
				dropdownHeight = dropdownContent.height();

			$(dropdown).removeClass('active');
			navMainContainer.css({'bottom': '32px', 'box-shadow': 'none'});
			dropdownContent.hide();
			openedDropdown = undefined;
		}
	};

}])


.directive('hubHeader', ['headerConfig', '$log',
	function (headerConfig, $log) {
		return {
			scope: {
				hubTitle: '@',
				userName: '=?',
				homeLink: '=?',
				adminLink: '=?',
				showNavDrawer: '=?',
				navDrawerCallback: '&',
				searchCallback: '&',
				showSearch: '=?',
				breadcrumbUpdates: '=?',
				lastUpdated: '=?'
			},
			restrict:'EA',
			transclude: true,
			controller:'HeaderController',
			templateUrl: 'modules/hub-bootstrap/templates/header/header.html',
			link: function(scope, element, attrs, HeaderController) {

				scope.showUtilityBar = attrs.breadcrumbUpdates || attrs.lastUpdated ? true : false;
				scope.showSearch = scope.showSearch || true;
				scope.homeLink = scope.homeLink || '/';

				scope.submitSearch = function(){
					if(this.searchValue){
						scope.searchCallback({
							value: this.searchValue || null 
						});

						document.getElementById('form-header-search').reset();
					} else {
						$log.info('please enter a valid search term');
					}
				};

				if(scope.showUtilityBar){
					angular.element('body').addClass('is-utility-bar');
				}

				HeaderController.init();
			}
		};
	}
])

.directive('headerNavLink', [ 
	function () {
		return {
			require: '^hubHeader',
			scope: {
				isDropdown: '=?'
			},
			restrict:'EA',
			transclude: true,
			replace: true,
			templateUrl: 'modules/hub-bootstrap/templates/header/nav-link.html',
			link: function(scope, element, attrs, HeaderController) {

				if(scope.isDropdown){
					var aTag = element.children()[0];

					$(aTag).on('click', function(evt){
						HeaderController.dropdownOpen(evt.currentTarget);
					});
				}

			}
		};
	}
])

.constant('headerConfig', {
  broadcastName: 'header'
});
