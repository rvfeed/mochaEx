'use strict';

/**

*/



angular.module('ui.hub.pagination', [])

.controller('PaginationController', ['$scope', '$route', '$location', '$rootScope',
	function ($scope, $route, $location, $rootScope) {

		var self = this;

		$scope.changePage = function(page){
			$scope.currentPage = page;

			//TODO: pass currentpage out to page controller even when nested inside 2 directives
			$rootScope.$broadcast('paginationBroadcast', page);
			self.init();
		};

		$scope.previousPage = function(){
			var page = $scope.currentPage <= 1 ? $scope.currentPage : $scope.currentPage - 1;
			$scope.changePage(page);
		};

		$scope.nextPage = function(){
			var page = $scope.currentPage >= $scope.totalPages ? $scope.currentPage : $scope.currentPage + 1;
			$scope.changePage(page);
		};

		this.init = function(){
			if(!isNaN($scope.totalPages) && $scope.totalPages > 0){
				var startAt = ((Math.ceil($scope.currentPage / $scope.displayCount) - 1) * $scope.displayCount) + 1;
				
				$scope.totalPagesArray = [];

				for(var i=startAt; i <= $scope.totalPages; i++){
					$scope.totalPagesArray.push({
						number: i,
						isActive: $scope.currentPage === i
					});
				}
			} else {

			}
		};


		return this;
	}
])


.directive('hubPagination', ['paginationConfig',
	function (paginationConfig) {
		return {
			scope: {
				totalPages: '=',
				currentPage: '=',
				displayCount: '=?'
			},
			restrict:'EA',
			controller:'PaginationController',
			templateUrl: 'modules/hub-bootstrap/templates/pagination/pagination.html',
			link: function(scope, element, attrs, paginationController) {

				scope.displayCount = scope.displayCount || paginationConfig.displayCount;

				if(!scope.currentPage){	
					return false;
				}

				scope.$watch('totalPages', function(newValue, oldValue){
					if(oldValue != newValue){
						paginationController.init(newValue);
					}
				}, true);

				paginationController.init();
			}
		};
	}
])

.constant('paginationConfig', {
  itemsPerPage: 10,
  displayCount: 5
});
