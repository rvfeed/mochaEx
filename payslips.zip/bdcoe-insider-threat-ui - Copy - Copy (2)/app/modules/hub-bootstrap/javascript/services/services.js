'use strict';

angular.module('ui.hub.services', []);