'use strict';

/**

TODO: add documentation

*/


angular.module('ui.hub.filters', [])

.filter('startFrom', [
	function () {
		return function (input, start) {
			if (!input || input.length === 0) {
				return;
			}

			start = +start; //parse to int
			return input.slice(start);
		};
	}
])

.filter('noSpaces', [
	function () {
		return function (value) {
			return (!value) ? '' : value.replace(/ /g, '');
		};
	}
])

.filter('lowerCamelCase', [
	function () {
		return function (value, splitOn) {
			var splitOn = splitOn || ' ',
				arrayString = value.split(splitOn),
				string = '';

			arrayString.forEach(function(value, i){
				string += i != 0 ? value.charAt(0).toUpperCase() + value.slice(1) : value;
			});
				
			return string;
		};
	}
])

.filter('upperCamelCase', [
	function () {
		return function (value, splitOn) {
			var splitOn = splitOn || ' ', 
				arrayString = value.split(splitOn),
				string = '';

			arrayString.forEach(function(value, i){
				string += value.charAt(0).toUpperCase() + value.slice(1);
			});
				
			return string;
		};
	}
]);